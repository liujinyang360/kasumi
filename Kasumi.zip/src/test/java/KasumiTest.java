import com.alibaba.fastjson.JSON;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.gson.JsonObject;
import com.kasumi.core.purchase.PurchaseManager;
import com.kasumi.utils.firebase.*;
import com.kasumi.utils.tool.OkHttpUtils;
import com.kasumi.utils.tool.Tools;
import okhttp3.*;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class KasumiTest {


    private static final String FIREBASE_API_URL = "https://fcm.googleapis.com/v1/projects/merge2d/messages:send";

    private static final String ACCESS_TOKEN = "your_access_token_here";

    private static GoogleCredential credentials = null;

    @Test
    public void testKasumi(){
        // 准备要发送的消息
//        try {
//
//            for (int i = 0; i < 1; i++) {
//
//                JsonObject notification = new JsonObject();
//                notification.addProperty("title", "测试通知" +i);
//                notification.addProperty("body", "这是通过HttpClient发送的Firebase推送消息");
//
//
//                String token = "ec7oVC8sakhcoZ-m6UvZmC:APAbFXBB7QQwEr78wJut2KacjoMIO8wlOnK6OLj2UevS6aMj8znRCi5x3rVW5Re8Ske4-p_uFAqyQ3gZCvX9kR7e8l1CVFPH3CK-eME_08CKYByw7apxJs1t1VN1qTfzgJEJoivXVE";
//
//
//                JsonObject message = new JsonObject();
//                JsonObject messageBody = new JsonObject();
//                messageBody.add("notification", notification);
//                messageBody.addProperty("token", token);  // 替换为你的设备令牌
//                message.add("message", messageBody);
//
//                // 创建 HttpClient 实例
//                HttpClient client = HttpClient.newHttpClient();
//
//                // 构建 HttpRequest
//                HttpRequest request = HttpRequest.newBuilder()
//                        .uri(URI.create(FIREBASE_API_URL))
//                        .header("Authorization", "Bearer " + getAccessToken())  // 使用 Bearer Token 进行身份验证
//                        .header("Content-Type", "application/json; UTF-8")
//                        .POST(HttpRequest.BodyPublishers.ofString(message.toString(), StandardCharsets.UTF_8))
//                        .build();
//
//                // 发送请求并获取响应
//                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//
//                // 打印响应
//                System.out.println("Response code: " + response.statusCode());
//                System.out.println("Response body: " + response.body());
//                System.out.println("response: " + JSON.toJSONString(response));
//            }
//            }catch(IOException | InterruptedException e){
//                e.printStackTrace();
//            }
    }


    private OkHttpClient client = new OkHttpClient();
    @Test
    public  void OkhttpClientTest(){
//        try {
//
//            for (int i = 0; i < 1; i++) {
//
//                JsonObject notification = new JsonObject();
//                notification.addProperty("title", "测试通知" +i);
//                notification.addProperty("body", "这是通过HttpClient发送的Firebase推送消息");
//
//
//                JsonObject message = new JsonObject();
////                for(var value : list){
//                    JsonObject messageBody = new JsonObject();
//                    messageBody.add("notification", notification);
//                    messageBody.addProperty("token", "dIOy1VWhBU2AvDmpiTUDr6:APA91bGnUEE1cSb3vq27-HANdfMwaOKI42e0X4F3f7moHiHDzi1ApPFKLmCgZakqiHWpYX-Dso4Tfu_plelaX2OmIantyI5ERKeR6DoR4XY8y3nwj5zG9pzhIsabpxkH66PMezub0ZpX");  // 替换为你的设备令牌
//                    message.add("message", messageBody);
////                }
//
//                // 构建 HTTP 请求
//                RequestBody requestBody = RequestBody.create(
//                        message.toString(),
//                        MediaType.parse("application/json; charset=utf-8")
//                );
//
//                Request request = new Request.Builder()
//                        .url(FIREBASE_API_URL)
//                        .post(requestBody)
//                        .addHeader("Authorization", "Bearer " + getAccessToken())
//                        .addHeader("Content-Type", "application/json")
//                        .build();
//
//                // 发送请求并获取响应
//                try (Response response = client.newCall(request).execute()) {
//                    Protocol protocol = response.protocol();
//                    System.out.println("Protocol: " + protocol);
//                    if (response.isSuccessful()) {
//                        System.out.println("推送成功，响应：" + response.body().string());
//                    } else {
//                        System.out.println("推送失败，错误代码：" + response.code() + "，错误信息：" + response.body().string());
//                    }
//                }
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
    }



    @Test
    public void FirebaseTest3(){
//        var info = new FirebasePushInfo() {
//            @Override
//            public void afterPushComplete() throws Exception {
//
//            }
//        };
//
//        var group = new FirebaseGroup(1,info);
//        var unit = new FirebaseUnit("cDn-47u7pEwNrfLXvb8WS8:APA91bFRO7ZhTL4G_0f4N56jweXTX-pF9N-L3jtREyMP23NDix73Qnrgci-cMZ70BF9P60-NbL22n6STYvZ7Y3N7aQxm_0SvKpqEpSivfcnaorj7m1DzE3k","test","test1");
//        var result = new FirebaseResult(group,unit);
//        FirebaseManager.pushSingle(unit);
//        try {
//            Thread.sleep(10000);
//        }catch (Exception e){
//
//        }

    }

    public static String getAccessToken() throws IOException {

        String SERVICE_ACCOUNT_JSON = """
                {
                  "type": "service_account",
                  "project_id": "merge2d",
                  "private_key_id": "b7e356664ffac74af4399f606930e9cb4b5024e0",
                  "private_key": "-----BEGIN PRIVATE KEY-----\\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDn6GZ98PbORDxW\\nZq5CxcyxRCz0nZikOn3H+yQXuQzHtA6RvkBkQ5WKTHoBtf+o821QAj1LevdANlCG\\nIcqA+hEcRu2fYJbKGouevVXP58JIAr1fdXmvV+qEwQaWCr4Rrbp8BvA7osPRXeQu\\n2ncthOoHp1odlR8OQqI4D8UeOG8RhtTA1dAzi9BFCjObkT0rfVa2OdvibjKROH3J\\neNFgK9ofb4QbdxdSOoqWM7S420orJIplJeyLKWF3Nn9jQ2dR755cAleDVvcjLkHg\\nBKJvfhDO3+GL0osQYnblQClcTYMyPqWH/Is7lXBGWCqU3fmF4CBhFkOOM8AwFU4u\\n5jGSzdT1AgMBAAECggEAAYz4DU1gY/86CBeganIBQ7yf3rVxt2edB6T95mcoE8Nk\\nPSsnrlzGvZMBSPs/QidRpKdJzPZp5gPNlJIXzn0POdVTIcKgZdYpntp6MefOHcmU\\nw7RE9xsfp3v0EjnI54UQfos1kxpNQ88U68Rra/LVVqLiPRb4FAcVDT0jNEbGypbp\\nyZ3Y8N0lLTljWuwIMym9+P5WNuIYcsWSRBGp0wI+APx56QCpWjPNAGsXGA/Mqb+w\\n+V6Y/JnZ1yLTGRkg4fOa8VTMAua2YHVLmpxPSbSko/Y64t2jSf9FOvfCsJhxQeth\\nqiZcG8KPcWr7GfXXUCtlhPVoCbNiAgaWF8I9qp9xYQKBgQD7o15BmwMTD2GoA/KI\\nkauCehplPfj2A+DPimNS1R7AMrTGTct63HZGMUT9r9bSzCEjcVyNEiNCXxkFhqZo\\nJALfPPOioS1t3+l+doCF2ZRjeMzgWDW8BpRZXYW8OBRH7InVqfoPmimo1ZUl822E\\n9mmAyEg6gZe9d1xViUFIQRCdFQKBgQDr7XrRKlwGbNdj2kDENafE0+lVupoZNfWx\\nAToCCS6GBaZPX8f1YFbZfGHeRfsxx4G6dzO2rDCYTPFwii0OOIXV0NpXsMYBqrhm\\ns8NqDpfDopuh1mU5vBvUmWe+AnrgmjyQ99sUqHA8/ujrJvCHnF6GsT+CwSePVmh+\\n5OoGcS0QYQKBgQDncwkEAMbgJhqlhhPzB0EgPpy+mDTAWyrQ2bGng3zIPRtG9lD9\\nDX//6dtSFwTZWIX2apM88fzaVEvYaFPwn4bAu/g/kk4NrJDAD9EAy/KPV5Hhm2C5\\nM7gJRlr2lwIYcXkJvFDTPvGoZ+LKSE9op5i8qfq9TWs7Cmk0B42zHp1gTQKBgQCT\\nA2qSyDiL8GrPWAMfwOeIKRyvRRYdO5ib8c250wrgjMizkVXCu4OjBnTd0vHSdSWL\\nkhfxbp7haKDSpeepguMy92/3ULox87XwmXfdsLY1PDCKylRNg8A73FPe/SCgsLup\\nAinMV6GJALcXQS6E8pWcjPqsebwy/38iA3cpCIEyQQKBgQDRkr7Zdb9Gzl4VwTDl\\nhE4fwJf8np9LpkQnqAa5W8wNwKGEaPFFz7Cd2QkmNqSKT4zRX3+Z/Ha5PC8wub0e\\nINPDUWgnuJ5M4Spup9zGQiBPX2dsZMSGitdwV5VN5W4u2T32Pgync832iL8pw4th\\nJYwQE/IzXQjqrNQNr1fj+UB3Cw==\\n-----END PRIVATE KEY-----\\n",
                  "client_email": "firebase-adminsdk-g3oj2@merge2d.iam.gserviceaccount.com",
                  "client_id": "111792603931416770865",
                  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                  "token_uri": "https://oauth2.googleapis.com/token",
                  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-g3oj2%40merge2d.iam.gserviceaccount.com"
                }
                """;
        ByteArrayInputStream serviceAccountStream = new ByteArrayInputStream(SERVICE_ACCOUNT_JSON.getBytes(StandardCharsets.UTF_8));
        if(credentials == null ){
            try {
                credentials = GoogleCredential

                        .fromStream(serviceAccountStream)
                        .createScoped(List.of("https://www.googleapis.com/auth/firebase.messaging"));

                credentials.refreshToken();

                System.out.println("过期时间 ：" + credentials.getExpiresInSeconds());

            }catch (IOException e){
                e.printStackTrace();
            }
        }
        String tokenValue = credentials.getAccessToken();
        System.out.println("tokenValue : " +tokenValue);

        return tokenValue;
    }




}
