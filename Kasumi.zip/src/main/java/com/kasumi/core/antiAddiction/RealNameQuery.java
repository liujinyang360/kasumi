package com.kasumi.core.antiAddiction;

import com.alibaba.fastjson.JSONObject;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.HttpResult;
import com.kasumi.modules.player.IGamePlayer;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;

public class RealNameQuery <T extends IGamePlayer> extends HttpResult {
    private final T player;
    private AntiHandler<T> handler;
    private static final Logger log = LoggerFactory.getLogger(RealNameQuery.class);

    protected RealNameQuery(T player, AntiHandler handler) {
        this.player = player;
        this.handler = handler;
    }

    public T getPlayer() {
        return player;
    }


    /**
     * 出现异常时候的执行方法
     * @param ex
     */
    protected void doException(Throwable ex){
        exception(ex);
    }

    /**
     * 成功返回时候的执行方法
     * @param response
     */
    protected void doSuccess(HttpResponse<String> response){
        success(response.body(),response.statusCode());
    }

    /**
     * {
     * "errcode":0,
     * "errmsg":"ok",
     * "data":{
     * "result":{
     * "status":0,
     * "pi":"1fffbjzos82bs9cnyj1dna7d6d29zg4esnh99u"
     * }
     * }
     * }
     * @param body
     * @param code
     */
    public void success(String body, int code){
        try{
            if (body == null || body.isEmpty()) {
                log.info("real name query response is null");
                handler.realNameQueryFail(player, BaseMessageCode.Server_Error,code);
                return;
            }
            log.info("real name query response body = {}", body);
            JSONObject object = JSONObject.parseObject(body);
            int errCode = object.getIntValue("errcode");
            if (errCode == 0) {
                // 成功
                JSONObject result = object.getJSONObject("data").getJSONObject("result");
                int status = result.getIntValue("status");
                String pi = result.getString("pi");
                handler.realNameQuery(player, pi, status);
                log.info("real name query success,playerId = {},status = {}", player.getId(),status);
            } else {
                // 失败
                log.error("real name query failed, playerId = {}, errCode = {}, errMsg = {}", player.getId(),errCode, object.getString("errmsg"));
                handler.realNameQueryFail(player,BaseMessageCode.AndiAddictionError,errCode);
            }
        }
        catch (Exception e) {
            log.error("real name query  processing response body: {}", body, e);
            handler.realNameQueryFail(player,BaseMessageCode.Server_Error,BaseMessageCode.Server_Error);
        }
    }


    public void exception(Throwable ex) {
        log.info("check failed....");
        ex.printStackTrace();
        handler.realNameQueryFail(player, BaseMessageCode.Server_Error, BaseMessageCode.Server_Error);
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}