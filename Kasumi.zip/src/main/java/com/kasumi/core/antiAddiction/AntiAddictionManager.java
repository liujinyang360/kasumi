package com.kasumi.core.antiAddiction;

import com.alibaba.fastjson.JSON;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.OkHttpUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class AntiAddictionManager {

    private static final Logger log = LoggerFactory.getLogger(AntiAddictionManager.class);

    private static boolean AntiAddictionEnable = false; // 是否开启防沉迷
    private static boolean waitToApproved = true;       // 是否等待审核（做个假的实名认证）
    /**
     * 实名认证接口
     */
    private static String RealNameCheckAPI = "https://api.wlc.nppa.gov.cn/idcard/authentication/check";
    /**
     * 实名认证查询接口
     */
    private static String RealNameQueryAPI = "http://api2.wlc.nppa.gov.cn/idcard/authentication/query?ai=%accountId%";
    /**
     * 行为（游玩多长时间） 上报接口
     */
    private static String BehaviorCollectAPI = "http://api2.wlc.nppa.gov.cn/behavior/collection/loginout";

    private static String APPID = "fdc6688637bc468e9aea874654cbead2";
    private static String bizId = "1101999999";
    private static String SECRET_KEY = "b4c932250dbe59ff53b15ee993a9feb5";

    private static final String AES_ALGORITHM = "AES/ECB/PKCS5Padding";

    public static final int RealNameCheckStatusSuccess = 0; // 实名认证成功
    public static final int RealNameCheckStatusProcessing = 1; // 实名认证中
    public static final int RealNameCheckStatusFail = 2; // 实名认证失败

    public static final int RealNameProcessingWaitTime = 48 * 3600; //可等待48小时

    private static final ZoneId ZONE_ID = ZoneId.of("Asia/Shanghai");
    private static final List<String> HOLIDAYS = new ArrayList<>();
    private static int MINOR_AGE = 18; // 法定成年年龄

    public static int MINOR_Second = 60 * 60; // 未成年人每天允许的游戏时间(秒)
    public static int MINOR_Guest_Time = 60 * 10; //游客时间
    public static int MINOR_HOURStart = 15; // 未成年人每天允许的游戏时间（小时）
    public static int MINOR_HOUREnd = 21; // 未成年人每天允许的游戏时间（小时）
    public static int MINOR_Pay_MinAge = 8; // 未成年人最小的充值岁数
    public static float MiNOR_Pay_8_16_single = 50f; // 未成年人8-16岁单次不得超过的充值金额
    public static float MINOR_Pay_8_16_monthly = 200f; // 未成年人8-16岁每月不得超过的充值金额
    public static float MINOR_Pay_16_18_single = 100f; // 未成年人16-18岁单次不得超过的充值金额
    public static float MINOR_Pay_16_18_monthly = 400f; // 未成年人16-18岁每月不得超过的充值金额

    public static int MinAge = 8; // 最小年龄

    public static final int CollectMaxSize = 128; // 每次上报的最大数据量


    public static void initAntiProps(Properties antiProps) throws Exception {
        setAntiAddictionEnable(Integer.parseInt(antiProps.getProperty("anti.AddictionEnable", "0")) == 1);
        RealNameCheckAPI = antiProps.getProperty("anti.Addi.realNameCheck.url", RealNameCheckAPI);
        RealNameQueryAPI = antiProps.getProperty("anti.Addi.realNameQuery.url", RealNameQueryAPI);
        BehaviorCollectAPI = antiProps.getProperty("anti.Addi.loginOut.url", BehaviorCollectAPI);
        waitToApproved = Integer.parseInt(antiProps.getProperty("anti.Addiction.waitToApproved", "1")) == 1;

        APPID = antiProps.getProperty("anti.Addi.appId", APPID);
        bizId = antiProps.getProperty("anti.Addi.bizId", bizId);
        SECRET_KEY = antiProps.getProperty("anti.Addi.secretKey", SECRET_KEY);

        System.out.println("是否启动防沉迷 " + isAntiAddictionEnable());
    }

    public static void initAntiAddictionConfig(){

    }


    public static <T extends IGamePlayer> void realNameCheckFake(final T player,AntiHandler handler,String realName,String idNum,String ai) {
        try {
            String pi = UserUniqueIdByIDCard.generateUserUniqueIdByIDCard(idNum);
            handler.realNameCheckSuccess(player, realName, idNum,ai, pi, RealNameCheckStatusSuccess);
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public static <T extends IGamePlayer> void realNameCheck(final T player,AntiHandler handler,String realName,String idNum,String ai) {
        System.out.println("anti-addiction check for player: " + player.getId());
        if(waitToApproved){
            log.info(" waitToApproved is true, skip realNameCheck");
            realNameCheckFake(player, handler, realName, idNum,ai);
            return;
        }

        try{
            long timestamps = System.currentTimeMillis();
            // 1. 原始数据
//            String json = "{\"ai\":\""+player.getId()+"\",\"name\":\"某一一\",\"idNum\":\"110000190101010001\"}";
            String json = "{\"ai\":\""+ai+"\",\"name\":\""+realName+"\",\"idNum\":\""+idNum+"\"}";
            // 2. AES 加密 & Base64 编码
            String encryptedData = RealNameEncryptDemo.encryptRequestBody(json, SECRET_KEY);
            System.out.println("加密后的data字段值：\n" + encryptedData);

            // 3. 构造请求体
            String requestBody = "{\"data\":\"" + encryptedData + "\"}";

            // 4. 拼接签名字符串
            String stringToSign = SECRET_KEY
                    + "appId" + APPID
                    + "bizId" + bizId
                    + "timestamps" + timestamps
                    + requestBody;

            // 5. 计算 SHA256 签名
            String sign = RealNameEncryptDemo.sha256Hex(stringToSign);

            HashMap<String,String> headerMap = new HashMap<>();
            headerMap.put("Content-Type", "application/json;charset=utf-8");
            headerMap.put("appId", APPID);
            headerMap.put("bizId", bizId);
            headerMap.put("timestamps", timestamps+"");
            headerMap.put("sign", sign);

            RealNameCheck realNameAuth = new RealNameCheck(player, handler,realName, idNum,ai) ;
            OkHttpUtils.doJsonRequest(RealNameCheckAPI, requestBody, "post", headerMap, realNameAuth);
        }catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static <T extends IGamePlayer> void realNameQuery(final T player,AntiHandler handler){
        try{
            long timestamps = System.currentTimeMillis();
            String url = RealNameQueryAPI.replace("%accountId%", player.getId() +"");
            HashMap<String,String> headerMap = new HashMap<>();
            headerMap.put("appId", APPID);
            headerMap.put("bizId", bizId);
            headerMap.put("timestamps", System.currentTimeMillis()+"");
            String stringToSign = SECRET_KEY+"ai"+player.getId()
                    +"appId"+APPID
                    +"bizId"+bizId
                    +"timestamps"+timestamps;
            String sign = RealNameEncryptDemo.sha256Hex(stringToSign);
            headerMap.put("sign", sign);

            RealNameQuery realNameQuery = new RealNameQuery(player, handler);
            OkHttpUtils.doHttpRequest(url, null,"get",headerMap, realNameQuery);

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loginout(List<AntiCollectionData> collectList,int times){
        if(waitToApproved){
            log.info(" waitToApproved is true, skip loginout");
            return;
        }

        try{
            long timestamps = System.currentTimeMillis();
            HashMap<String,List<AntiCollectionData>> dataMap = new LinkedHashMap<>();
            dataMap.put("collections", collectList);
            String json = JSON.toJSONString(dataMap);

            // 2. AES 加密 & Base64 编码
            String encryptedData = RealNameEncryptDemo.encryptRequestBody(json, SECRET_KEY);
            System.out.println("加密后的data字段值：\n" + encryptedData);

            // 3. 构造请求体
            String requestBody = "{\"data\":\"" + encryptedData + "\"}";

            // 4. 拼接签名字符串
            String stringToSign = SECRET_KEY
                    + "appId" + APPID
                    + "bizId" + bizId
                    + "timestamps" + timestamps
                    + requestBody;

            // 5. 计算 SHA256 签名
            String sign = RealNameEncryptDemo.sha256Hex(stringToSign);

            HashMap<String,String> headerMap = new HashMap<>();
            headerMap.put("Content-Type", "application/json;charset=utf-8");
            headerMap.put("appId", APPID);
            headerMap.put("bizId", bizId);
            headerMap.put("timestamps", timestamps+"");
            headerMap.put("sign", sign);

            UserLoginOutCollection userLoginOutCollection = new UserLoginOutCollection(collectList, times) ;

            OkHttpUtils.doJsonRequest(BehaviorCollectAPI, requestBody, "post", headerMap, userLoginOutCollection);

        }catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 检查未成年人是否在允许的时间段内玩游戏
     * @return true: 允许， false: 不允许
     */
    public static boolean isMinorAllowed() {
        if(!isAntiAddictionEnable()) {
            return true; // 如果防沉迷未启用，则允许
        }

        ZonedDateTime now = ZonedDateTime.now(ZONE_ID);
        LocalDate today = now.toLocalDate();
        LocalTime time = now.toLocalTime();

        // 允许游戏时间段：20:00 <= 当前时间 < 21:00
        LocalTime start = LocalTime.of(MINOR_HOURStart, 0);
        LocalTime end = LocalTime.of(MINOR_HOUREnd, 0);
        boolean inTimeRange = !time.isBefore(start) && time.isBefore(end);

        if(!inTimeRange){
            return false;
        }

        // 判断是否为周五、六、日
        DayOfWeek dayOfWeek = today.getDayOfWeek();
        boolean isWeekend = dayOfWeek == DayOfWeek.FRIDAY
                || dayOfWeek == DayOfWeek.SATURDAY
                || dayOfWeek == DayOfWeek.SUNDAY;

        // 判断是否是法定节假日
        String todayStr = today.format(DateTimeFormatter.ISO_LOCAL_DATE);
        boolean isHoliday = HOLIDAYS.contains(todayStr);

        return inTimeRange && (isWeekend || isHoliday);
    }

    /**
     * 是否可以玩游戏
     * @param age
     * @param playTimeInSeconds
     * @return
     */
    public static boolean canPlay(int age, int playTimeInSeconds) {
        int canPlayType = canPlayerCode(age, playTimeInSeconds);
        if(canPlayType == BaseMessageCode.OK){
            return true;
        }
        return false;
    }

    public static int canPlayerCode(int age, int playTimeInSeconds){
        if(!isAntiAddictionEnable()){
            return BaseMessageCode.OK;
        }
        if(age < MinAge){
            return BaseMessageCode.RealName_TooYoung;
        }
        if (age < MINOR_AGE) {
            // 未成年人
            if (playTimeInSeconds > MINOR_Second) {
                return BaseMessageCode.RealName_TimeLimit; // 超过未成年人允许的游戏时间
            }
            boolean allow = isMinorAllowed(); // 检查是否在允许的时间段内
            return allow ? BaseMessageCode.OK : BaseMessageCode.RealName_TimeLimit;
        } else {
            // 成年人
            return BaseMessageCode.OK; // 成年人没有时间限制
        }
    }

    /**
     * 单次充值金额上限
     * @param age
     * @return
     */
    public static float getMaxSinglePayAmount(int age) {
        if(!isAntiAddictionEnable()){
            return Integer.MAX_VALUE;
        }

        if (age < MINOR_Pay_MinAge) {
            return 0; // 未成年人最小充值年龄
        } else if (age < 16) {
            return MiNOR_Pay_8_16_single; // 8-16岁未成年人单次充值上限
        } else if (age < 18) {
            return MINOR_Pay_16_18_single; // 16-18岁未成年人单次充值上限
        } else {
            return Integer.MAX_VALUE; // 成年人没有限制
        }
    }


    /**
     * 每月充值上限
     * @param age
     * @return
     */
    public static float getMaxMonthlyPayAmount(int age) {
        if(!isAntiAddictionEnable()){
            return Integer.MAX_VALUE;
        }
        if (age < MINOR_Pay_MinAge) {
            return 0; // 未成年人最小充值年龄
        } else if (age < 16) {
            return MINOR_Pay_8_16_monthly; // 8-16岁未成年人每月充值上限
        } else if (age < 18) {
            return MINOR_Pay_16_18_monthly; // 16-18岁未成年人每月充值上限
        } else {
            return Integer.MAX_VALUE; // 成年人没有限制
        }
    }

    public static void addHolidays(List<String> holidays){
        if(holidays == null ){
            return;
        }
        HOLIDAYS.addAll(holidays);
    }

    public static String getAPPID() {
        return APPID;
    }

    public static void setAPPID(String APPID) {
        AntiAddictionManager.APPID = APPID;
    }

    public static String getBizId() {
        return bizId;
    }

    public static void setBizId(String bizId) {
        AntiAddictionManager.bizId = bizId;
    }

    public static String getSecretKey() {
        return SECRET_KEY;
    }

    public static void setSecretKey(String secretKey) {
        SECRET_KEY = secretKey;
    }

    public static boolean isAntiAddictionEnable() {
        return AntiAddictionEnable;
    }

    public static void setAntiAddictionEnable(boolean antiAddictionEnable) {
        AntiAddictionEnable = antiAddictionEnable;
    }

    public static void setMinorAge(int minorAge) {
        MINOR_AGE = minorAge;
    }

    public static void setMINOR_Second(int MINOR_Second) {
        AntiAddictionManager.MINOR_Second = MINOR_Second;
    }

    public static void setMINOR_Guest_Time(int MINOR_Guest_Time) {
        AntiAddictionManager.MINOR_Guest_Time = MINOR_Guest_Time;
    }

    public static void setMINOR_HOURStart(int MINOR_HOURStart) {
        AntiAddictionManager.MINOR_HOURStart = MINOR_HOURStart;
    }

    public static void setMINOR_HOUREnd(int MINOR_HOUREnd) {
        AntiAddictionManager.MINOR_HOUREnd = MINOR_HOUREnd;
    }

    public static void setMINOR_Pay_MinAge(int MINOR_Pay_MinAge) {
        AntiAddictionManager.MINOR_Pay_MinAge = MINOR_Pay_MinAge;
    }

    public static void setMiNOR_Pay_8_16_single(float miNOR_Pay_8_16_single) {
        MiNOR_Pay_8_16_single = miNOR_Pay_8_16_single;
    }

    public static void setMINOR_Pay_8_16_monthly(float MINOR_Pay_8_16_monthly) {
        AntiAddictionManager.MINOR_Pay_8_16_monthly = MINOR_Pay_8_16_monthly;
    }

    public static void setMINOR_Pay_16_18_single(float MINOR_Pay_16_18_single) {
        AntiAddictionManager.MINOR_Pay_16_18_single = MINOR_Pay_16_18_single;
    }

    public static void setMINOR_Pay_16_18_monthly(float MINOR_Pay_16_18_monthly) {
        AntiAddictionManager.MINOR_Pay_16_18_monthly = MINOR_Pay_16_18_monthly;
    }
}
