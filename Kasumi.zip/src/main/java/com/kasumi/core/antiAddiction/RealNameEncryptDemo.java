package com.kasumi.core.antiAddiction;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

public class RealNameEncryptDemo {

    // AES 密钥（16 字节）
    private static final String SECRET_KEY = "b4c932250dbe59ff53b15ee993a9feb5";
    private static final String AES_ALGORITHM = "AES/GCM/NoPadding";

    private static final int GCM_TAG_LENGTH = 128; // bits
    private static final int GCM_IV_LENGTH = 12; // 12 bytes (96 bits)

    public static void main(String[] args) throws Exception {
        // 1. 原始数据
        String json = "{\"ai\":\"100000000000000001\",\"name\":\"某一一\",\"idNum\":\"110000190101010001\"}";

        // 接口认证参数
        String appId = "fdc6688637bc468e9aea874654cbead2";
        String bizId = "1101999999";
        String timestamps = "1705975788903";

        // 2. AES 加密 & Base64 编码
        String encryptedData = encryptRequestBody(json, SECRET_KEY);
        System.out.println("加密后的data字段值：\n" + encryptedData);

        encryptedData = "kGuV06piX8av9vsZGofHI1viPrHG/IpjsGGu75DYmRyQx6UEvPXrKkAdwWs3SmzEQ5GctOK/N5x5J4Yykw61plWqIL/PytfMZfcnqM43+HmW04agmLU6TJ1ydUnirDl8xGiofmrLLg==";
        // 3. 构造请求体
        String requestBody = "{\"data\":\"" + encryptedData + "\"}";

        // 4. 拼接签名字符串
        String stringToSign = SECRET_KEY
                + "appId" + appId
                + "bizId" + bizId
                + "timestamps" + timestamps
                + requestBody;

        // 5. 计算 SHA256 签名
        String sign = sha256Hex(stringToSign);
        System.out.println("签名 sign = " + sign);

        Map<String, String> headers = new HashMap<>();
        headers.put("appId", appId);
        headers.put("bizId", bizId);
        headers.put("timestamps", timestamps);

        sign = generateSignature(headers, requestBody, SECRET_KEY);
        System.out.println("生成的签名: " + sign);

    }


//    public static String aesEncryptToBase64(String data, String key) throws Exception {
//        byte[] hexStr = hexToBytes(key);
//        SecretKeySpec skeySpec = new SecretKeySpec(hexStr, "AES");
//        // encoding format needs thought
//        byte[] clearTextbytes = data.getBytes("UTF-8");
//        final SecureRandom secureKeyRandomness = SecureRandom.getInstanceStrong();
//        final KeyGenerator AES_keyInstance = KeyGenerator.getInstance("AES");
//        AES_keyInstance.init(128, secureKeyRandomness);
//        final Cipher AES_cipherInstance = Cipher.getInstance("AES/GCM/NoPadding");
//        AES_cipherInstance.init(Cipher.ENCRYPT_MODE, skeySpec);
//        byte[] encryptedText = AES_cipherInstance.doFinal(clearTextbytes);
//        byte[] iv = AES_cipherInstance.getIV();
//        byte[] message = new byte[12 + clearTextbytes.length + 16];
//        System.arraycopy(iv, 0, message, 0, 12);
//        System.arraycopy(encryptedText, 0, message, 12, encryptedText.length);
//        return Base64.getEncoder().encodeToString(message);
//    }

    /**
     * 这个比较简单，好用
     * @param text
     * @return
     * @throws Exception
     */
    public static String sha256Hex(String text) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b); // 转为16进制
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }


    public static String encryptRequestBody(String json, String secretKey) throws Exception {
        byte[] keyBytes = hexToBytes(secretKey);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

        // 随机 IV
        byte[] iv = new byte[GCM_IV_LENGTH];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        GCMParameterSpec gcmSpec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, gcmSpec);

        byte[] cipherText = cipher.doFinal(json.getBytes(StandardCharsets.UTF_8));

        // 拼接 IV + CipherText
        byte[] finalBytes = new byte[iv.length + cipherText.length];
        System.arraycopy(iv, 0, finalBytes, 0, iv.length);
        System.arraycopy(cipherText, 0, finalBytes, iv.length, cipherText.length);

        return Base64.getEncoder().encodeToString(finalBytes);
    }

    // ========== 2. 生成 SHA256 签名 ==========
    public static String generateSignature(Map<String, String> headersWithoutSign, String requestBodyJson, String secretKey) throws Exception {
        // 字典序排序
        List<String> keys = new ArrayList<>(headersWithoutSign.keySet());
        Collections.sort(keys);

        // 拼接 key1value1key2value2...
        StringBuilder sb = new StringBuilder();
        sb.append(secretKey);
        for (String key : keys) {
            sb.append(key).append(headersWithoutSign.get(key));
        }
        sb.append(requestBodyJson);

        // 计算 SHA256
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(sb.toString().getBytes(StandardCharsets.UTF_8));

        // 转为 Hex 小写字符串
        StringBuilder hex = new StringBuilder();
        for (byte b : hash) {
            String h = Integer.toHexString(0xff & b);
            if (h.length() == 1) hex.append('0');
            hex.append(h);
        }
        return hex.toString();
    }

    // ========== 工具方法：hex 字符串转 byte[] ==========
    public static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] out = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            out[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return out;
    }

}
