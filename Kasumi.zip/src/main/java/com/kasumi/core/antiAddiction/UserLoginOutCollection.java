package com.kasumi.core.antiAddiction;

import com.alibaba.fastjson.JSONObject;
import com.kasumi.modules.HttpResult;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.List;

public class UserLoginOutCollection extends HttpResult {
    private List<AntiCollectionData> list;
    private int times;
    private static final Logger log = LoggerFactory.getLogger(UserLoginOutCollection.class);

    protected UserLoginOutCollection(List<AntiCollectionData> list,int times) {
        this.list = list;
    }

    /**
     * 出现异常时候的执行方法
     * @param ex
     */
    protected void doException(Throwable ex){
        exception(ex);
    }

    /**
     * 成功返回时候的执行方法
     * @param response
     */
    protected void doSuccess(HttpResponse<String> response){
        success(response.body(),response.statusCode());
    }

    /**
     * {
     * "errcode":0,
     * "errmsg":"ok",
     *  "data":""
     * }
     * @param body
     * @param code
     */
    public void success(String body, int code){
        try{
            if (body == null || body.isEmpty()) {
                log.info("loginOut report response is null");
                return;
            }
            log.info("loginOut report response body = {}", body);
            JSONObject object = JSONObject.parseObject(body);
            int errCode = object.getIntValue("errcode");
            if (errCode != 0) {
                // 失败
                doWhenErr();
            }
        }
        catch (Exception e) {
            log.error("loginOut report processing response body: {}", body, e);
            doWhenErr();
        }
    }


    /**
     * 出现异常时候的执行方法
     * @param
     */
    public void doWhenErr(){
        log.info("loginOut report failed....");
        if(times < 2){
            AntiAddictionManager.loginout(list, times + 1);
        }
    }


    public void exception(Throwable ex) {
        log.info("check failed....");
        ex.printStackTrace();
        doWhenErr();
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}