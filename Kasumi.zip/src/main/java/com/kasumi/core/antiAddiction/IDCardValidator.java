package com.kasumi.core.antiAddiction;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class IDCardValidator {

    // 加权因子
    private static final int[] WEIGHTS = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};
    // 校验码映射
    private static final char[] CHECK_CODES = {'1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'};

    public static boolean isValidIDCard(String idCard) {
        if (idCard == null || idCard.length() != 18) {
            return false;
        }

        String upperIdCard = idCard.toUpperCase();

        // 前17位必须是数字
        String first17 = upperIdCard.substring(0, 17);
        if (!first17.matches("\\d{17}")) {
            return false;
        }

        // 出生日期校验
        String birthDateStr = upperIdCard.substring(6, 14);
        if (!isValidDate(birthDateStr)) {
            return false;
        }

        // 计算校验码
        char expectedCheckCode = calculateCheckCode(first17);
        char actualCheckCode = upperIdCard.charAt(17);

        return expectedCheckCode == actualCheckCode;
    }

    // 校验日期是否合法，格式为 yyyyMMdd
    private static boolean isValidDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        sdf.setLenient(false); // 不允许宽松解析
        try {
            sdf.parse(dateStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // 根据前17位计算校验码
    private static char calculateCheckCode(String first17) {
        int sum = 0;
        for (int i = 0; i < 17; i++) {
            int digit = first17.charAt(i) - '0';
            sum += digit * WEIGHTS[i];
        }
        int mod = sum % 11;
        return CHECK_CODES[mod];
    }

    /**
     * 根据出生日期字符串计算年龄
     * @param birthDateStr 出生日期字符串，格式yyyyMMdd
     * @return 年龄（整数岁）
     * @throws ParseException 格式不正确抛异常
     */
    public static int calculateAge(String birthDateStr) {
        int age = 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            sdf.setLenient(false);
            Date birthDate = sdf.parse(birthDateStr);

            Calendar birthCal = Calendar.getInstance();
            birthCal.setTime(birthDate);

            Calendar todayCal = Calendar.getInstance();

            age = todayCal.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR);

            // 如果当前月日还没到出生月日，年龄减1
            int todayMonth = todayCal.get(Calendar.MONTH);
            int birthMonth = birthCal.get(Calendar.MONTH);

            if (todayMonth < birthMonth) {
                age--;
            } else if (todayMonth == birthMonth) {
                int todayDay = todayCal.get(Calendar.DAY_OF_MONTH);
                int birthDay = birthCal.get(Calendar.DAY_OF_MONTH);
                if (todayDay < birthDay) {
                    age--;
                }
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return age;
    }

    public static int getAgeFromIDCard(String idCard){
        try{
            String birthDateStr = idCard.substring(6, 14);
            return calculateAge(birthDateStr);
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    // 测试
    public static void main(String[] args) {
        String validID = "11010519491231002X";
        String invalidID = "110105194912310021";

        System.out.println(validID + " 是否有效？" + isValidIDCard(validID));
        System.out.println(invalidID + " 是否有效？" + isValidIDCard(invalidID));
        System.out.println(calculateAge("19850715"));
    }

}
