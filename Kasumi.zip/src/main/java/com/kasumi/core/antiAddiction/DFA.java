package com.kasumi.core.antiAddiction;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DFA {    
	
	private static List<String> arrt = new ArrayList<String>();  
    private static Node rootNode = new Node(); 
        
    private static ArrayList<String> searchWord(String content) {  
    	int a = 0;    
        char[] chars = content.toCharArray();    
        Node node = rootNode;
        StringBuffer word = new StringBuffer();
        ArrayList<String> words = new ArrayList<String>();  
        while(a < chars.length) {    
            node = findNode(node,chars[a]);    
            if(node == null) {    
                node = rootNode;    
                a = a - word.length();    
                word.setLength(0);    
            } else if(node.flag == 1) {    
                word.append(chars[a]);  
                words.add(word.toString());    
                a = a - word.length() + 1;    
                word.setLength(0);    
                node = rootNode;    
            } else {    
                word.append(chars[a]);    
            }             
            a++;    
        }   
        node = null;
        word = null;
        chars = null;
        return words;
    }
      
    
    public static String getDFAStr(String content){
//    	content = content.toLowerCase();
    	ArrayList<String> list = searchWord(content);  
    	for(int i = 0;i<list.size();i++){
    		String src = list.get(i);
    		StringBuffer sb = new StringBuffer();
    		for(int j = 0;j<src.length();j++){
    			sb.append("*");
    		}
    		content =  content.replace(src, sb.toString());    		
    		sb = null;
    	}
    	list.clear();
    	list = null;
    	return content;
    }
    
    public static boolean hasKeyWords(String content){
		int a = 0;
		char[] chars = content.toLowerCase().toCharArray();
		Node node = rootNode;
		StringBuffer word = new StringBuffer();
		try {
			while (a < chars.length) {
				node = findNode(node, chars[a]);
				if (node == null) {
					node = rootNode;
					a = a - word.length();
					word.setLength(0);
				} else if (node.flag == 1) {
					return true;
				} else {
					word.append(chars[a]);
				}
				a++;
			}
			return false;
		} finally {
			node = null;
			word = null;
			chars = null;
		}
    }
    
//    public synchronized static void initial(InputStream in) throws Exception{
//		Workbook wb = Workbook.getWorkbook(in);
//		Sheet sheet = wb.getSheet(1);
//		int rows = sheet.getRows();
//		for (int i = 1; i < rows; i++) {
//			arrt.add(sheet.getCell(0, i).getContents().trim());
//		}
//		rootNode = new Node();
//		createTree();
//		arrt.clear();
//    }

	public synchronized static void initial(String dictFilePath) throws Exception{
		int count = 0;
		try (BufferedReader br = new BufferedReader(new FileReader(dictFilePath))) {
			String line;
			while ((line = br.readLine()) != null) {
				arrt.add(line.trim().toLowerCase());
				count ++;
			}
		}
		rootNode = new Node();
		createTree();
		arrt.clear();
		System.out.println("敏感词数量: " + count);
	}
        
    private static void createTree() {    
        for(String str : arrt) {    
            char[] chars = str.toCharArray();    
            if(chars.length > 0) {
                insertNode(rootNode, chars, 0);    
            }
        }    
    }    
        
    private static void insertNode(Node node, char[] cs, int index) {    
        Node n = findNode(node, cs[index]);    
        if(n == null) {    
            n = new Node();
            node.nodes.put(cs[index],n);    
        }
        
		if (index == (cs.length - 1)) {
			n.flag = 1;
		}
                
        index++;    
		if (index < cs.length) {
			insertNode(n, cs, index);
		}
    }    
        
    private static Node findNode(Node node, char c) {    
        HashMap<Character,Node> nodes = node.nodes;         
        return nodes.get(c);    
    }    
        
    private static class Node {
        public int flag; //1：表示终结，0：延续            
        public HashMap<Character,Node> nodes = new HashMap<Character,Node>();              
        public Node() {            
            this.flag = 0;    
        } 
    }    
 
    
    public static void main(String[] args){
    	try{
	    	InputStream in = DFA.class.getResourceAsStream("zk.txt");
	    	BufferedReader reader = new BufferedReader(new InputStreamReader(in));
	    	
	    	BufferedWriter writer = new BufferedWriter(new FileWriter("d:/zkn.txt", true));
	    	
	    	String line = null;
	    	while((line = reader.readLine()) != null){
	    		String[] tmp = line.split("、");
	    		for(int i = 0;i<tmp.length;i++){
	    			writer.write(tmp[i]);
	    			writer.newLine();
	    		}
	    	}
	    	writer.flush();
	    	writer.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
}  