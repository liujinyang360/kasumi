package com.kasumi.core.antiAddiction;

public class AntiCollectionData {

    public static final int BT_login = 1;
    public static final int BT_logout = 0;

    public static final int CT_Verified = 0; // 已验证
    public static final int CT_Guest = 2;   // 游客

    private int no;
    private String si;
    private int bt;
    private long ot;
    private int ct;
    private String di;
    private String pi;

    public AntiCollectionData() {
    }

    public AntiCollectionData(int no, String si, int bt, long ot, int ct, String di, String pi) {
        this.no = no;
        this.si = si;
        this.bt = bt;
        this.ot = ot;
        this.ct = ct;
        this.di = di;
        this.pi = pi;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getSi() {
        return si;
    }

    public void setSi(String si) {
        this.si = si;
    }

    public int getBt() {
        return bt;
    }

    public void setBt(int bt) {
        this.bt = bt;
    }

    public long getOt() {
        return ot;
    }

    public void setOt(long ot) {
        this.ot = ot;
    }

    public int getCt() {
        return ct;
    }

    public void setCt(int ct) {
        this.ct = ct;
    }

    public String getDi() {
        return di;
    }

    public void setDi(String di) {
        this.di = di;
    }

    public String getPi() {
        return pi;
    }

    public void setPi(String pi) {
        this.pi = pi;
    }
}
