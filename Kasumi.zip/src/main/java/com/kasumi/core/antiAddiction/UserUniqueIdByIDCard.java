package com.kasumi.core.antiAddiction;

import org.apache.hc.core5.http.ParseException;

import java.text.SimpleDateFormat;
import java.util.Random;

public class UserUniqueIdByIDCard {

    // 26进制字符集，0-9 + a-p，共26个字符
    private static final char[] BASE26_CHARS = {
            '0','1','2','3','4','5','6','7','8','9',
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p'
    };

    // 简单身份证出生日期提取与校验（不做校验码，只验证长度和日期格式）
    public static String extractBirthDateFromIDCard(String idCard) throws Exception {
        if (idCard == null || idCard.length() != 18) {
            throw new IllegalArgumentException("身份证号码长度必须是18位");
        }
        String birthDate = idCard.substring(6, 14);
        // 校验日期格式是否正确
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        sdf.setLenient(false);
        sdf.parse(birthDate);  // 不合法会抛异常
        return birthDate;
    }

    // 生日转换为26进制6位字符串
    public static String encodeBirthDateToBase26(String birthDate) {
        long dateNum = Long.parseLong(birthDate);
        char[] result = new char[6];
        for (int i = 5; i >= 0; i--) {
            int remainder = (int)(dateNum % 26);
            result[i] = BASE26_CHARS[remainder];
            dateNum /= 26;
        }
        return new String(result);
    }

    // 生成32位随机16进制字符串
    protected static String generateUserCode32() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(32);
        for (int i = 0; i < 32; i++) {
            int n = random.nextInt(16);
            sb.append(Integer.toHexString(n));
        }
        return sb.toString();
    }

    // 根据身份证号生成38位用户唯一标识
    public static String generateUserUniqueIdByIDCard(String idCard) {
        try {
            String birthDate = extractBirthDateFromIDCard(idCard);
            String birthPart = encodeBirthDateToBase26(birthDate);
            String userCodePart = generateUserCode32();
            return birthPart + userCodePart;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    // 测试示例
    public static void main(String[] args) {
        String testID = "110105199001012345"; // 示例身份证号，出生日期1990-01-01
        try {
            String uniqueId = generateUserUniqueIdByIDCard(testID);
            System.out.println("身份证号: " + testID);
            System.out.println("用户唯一标识: " + uniqueId);
            System.out.println("生日部分(26进制6位): " + uniqueId.substring(0,6));
            System.out.println("用户编码部分(32位): " + uniqueId.substring(6));
            System.out.println("岁数: "+IDCardValidator.getAgeFromIDCard(testID));
        } catch (Exception e) {
            System.err.println("错误: " + e.getMessage());
        }
    }

}
