package com.kasumi.core.antiAddiction;

import com.kasumi.modules.player.IGamePlayer;

public interface AntiHandler<T extends IGamePlayer> {
    /**
     * 实名认证
     * @param player 玩家
     */
    void realNameCheckFail(T player, int code, int sysCode);


    /**
     * 需要处理status == 1的情况，也就是说
     * @param player
     * @param realName
     * @param idNum
     */
    void realNameCheckSuccess(T player, String realName, String idNum,String ai,String pi,int status);

    void realNameQuery(T player,String pi,int status);

    void realNameQueryFail(T player, int code, int sysCode);

}
