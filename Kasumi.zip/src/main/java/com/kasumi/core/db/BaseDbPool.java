package com.kasumi.core.db;

import com.alibaba.druid.filter.Filter;
import com.alibaba.druid.filter.stat.StatFilter;
import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.kasumi.utils.tool.Tools;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class BaseDbPool {
    private boolean isInited = false;
    private final ConcurrentHashMap<String,DruidDataSource> dataSourceMap = new ConcurrentHashMap<>();
    @SuppressWarnings("unchecked")
    public synchronized  boolean init(InputStream in,boolean openStat) {
        if (isInited) {
            return true;
        }
        try {
            SAXBuilder sb = new SAXBuilder();
            Document doc = sb.build(in);
            Element root = doc.getRootElement();
            List<Element> poolList = root.getChildren("pool");
            for (Element poolElement : poolList) {
                String name = poolElement.getAttributeValue("name");
                var dds = (DruidDataSource) DruidDataSourceFactory.createDataSource(getPropertiesMap(poolElement));
                dds.setName(name);

                if(openStat) {
                    List<Filter> filters = new ArrayList<>();
                    filters.add(statFilter());
                    dds.setProxyFilters(filters);
                }

                dataSourceMap.put(name,dds);
            }
            isInited = true;
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private Filter statFilter() {
        StatFilter filter = new StatFilter();
        filter.setSlowSqlMillis(1000L);
        filter.setLogSlowSql(true);
        filter.setMergeSql(true);
        return filter;
    }

    private HashMap<String, String> getPropertiesMap(Element element) throws Exception {
        List<Element> list = element.getChildren("property");
        HashMap<String, String> map = new HashMap<>(list.size());
        for (Element propertyElement : list) {
            map.put(propertyElement.getAttributeValue("name"), propertyElement.getAttributeValue("value"));
        }
        return map;
    }

    public boolean init(String fileName,boolean openStat) {
        boolean b = false;
        try {
            InputStream in = Tools.getInputStreamByFilePath(fileName);
            b = init(in,openStat);
            in.close();
        }catch(Exception e) {
            e.printStackTrace();
        }
        return b;
    }

    public Connection getConnection(String ddsName){
        try {
            var dds = dataSourceMap.get(ddsName);
            return dds == null ? null : dds.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
