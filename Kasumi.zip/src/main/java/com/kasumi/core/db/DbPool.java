package com.kasumi.core.db;

import java.sql.Connection;

public class DbPool  {

    private static BaseDbPool instance;

    public static boolean initPool(String fileName){
        instance = new BaseDbPool();
        return instance.init(fileName,false);
    }

    public static boolean initPool(String fileName,boolean openStat){
        instance = new BaseDbPool();
        return instance.init(fileName,openStat);
    }

    public static Connection getConnection(){
        return instance.getConnection("game");
    }

    public static Connection getLogConnection(){
        return instance.getConnection("log");
    }

    public static Connection getReadOnlyConnect() {
        return instance.getConnection("readonly");
    }

    public static Connection getConnectionByName(String name){
        return instance.getConnection(name);
    }

    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
