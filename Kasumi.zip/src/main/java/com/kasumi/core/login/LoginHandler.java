package com.kasumi.core.login;

import com.kasumi.conf.CommConstants;
import com.kasumi.core.Server;
import com.kasumi.core.playercenter.GamePlayerCenter;
import com.kasumi.imp.DefaultMessage;
import com.kasumi.io.ClientChannel;
import com.kasumi.io.packet.BasePacketId;
import com.kasumi.io.packet.WritePacket;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.Tools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public interface LoginHandler<T extends IGamePlayer> {

    Logger log = LoggerFactory.getLogger(LoginHandler.class);

    /**
     * 通知服踢掉老玩家
     *
     * @param serverId 服务器id
     * @param userId   用户id
     */
    default void askKickReLogin(int serverId, int userId, String  deviceCodes, GamePlayerCenter center,BaseLoginManager loginManager) {
        WritePacket packet = new WritePacket(BasePacketId.GameRequestKickOff);
        packet.writeInt(userId);
        packet.writeUtfStr(deviceCodes);

        /*DefaultMessage message =  DefaultMessage.CallBackMessage(Tools.getServerTag(CommConstants.SERVER_TYPE_GAME,serverId)).addListener(new Callback() {
            @Override
            public void doSuccess(Message message) {
                    int playerId = message.readInt();
                    log.info("do wait back playerId = {}", playerId);
                    //等待登录
                    loginManager.doWaitBack(playerId);
            }

            @Override
            public void doTimeout() {
                center.removeWaitAndClose(userId);
            }
        }).timeout(5000);*/
        DefaultMessage message = new DefaultMessage(Tools.getServerTag(CommConstants.SERVER_TYPE_GAME, serverId));
        message.writePacket(packet);
        Server.instance().pipeline().sendMessage(message);
    }

    /**
     * 是否被封设备
     *
     * @param deviceCode 设备号
     * @return 设备是否被封
     */
    boolean hasBan(String deviceCode);

    /**
     * 是否被封账号
     *
     * @param userId 用户id
     * @return 账号是否被封
     */
    boolean hasBan(int userId);

    /**
     * 是否因为防沉迷被封禁
     * @param player
     * @return
     */
    int antiAddictionCode(T player);

    /**
     * 登录主逻辑
     *
     * @param player 玩家对象
     * @return 登录逻辑
     */
    int login(T player);

    /**
     * 登录错误
     *
     * @param channel 登录通道
     * @param reason  错误原因
     */
    void loginError(ClientChannel channel, int reason);

    /**
     * 写玩家信息
     *
     * @param player 玩家对象
     */
    void writePlayerInfo(T player);

    /**
     * 根据老玩家对象重新初始化一个新玩家
     *
     * @param oldPlayer 旧的玩家对象
     * @return 新的玩家对象
     */
    T reInitPlayer(T oldPlayer);

    /**
     * 初始化玩家
     *
     * @param player 玩家对象
     * @return 操作结果
     */
    int initPlayer(T player);


    /**
     * 用户被封账号的处理
     *
     * @param player  玩家对象
     * @param channel 玩家连接
     */
    void doUserBeBan(T player, ClientChannel channel);

    void doUserBeBanByAntiAddiction(T player, ClientChannel channel,int addictionCode);
}
