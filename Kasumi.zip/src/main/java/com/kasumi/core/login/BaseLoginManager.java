package com.kasumi.core.login;

import com.kasumi.core.Server;
import com.kasumi.core.playercenter.GamePlayerCenter;
import com.kasumi.core.playercenter.WaitEnterInfo;
import com.kasumi.io.ClientChannel;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.ThreadPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BaseLoginManager<T extends IGamePlayer> {
    /**
     * 普通方式
     */
    public static final int Login_Comm = 1;
    /**
     * 等待模式
     */
    public static final int Login_Wait = 2;

    public abstract GamePlayerCenter<T> gameCenter();

    public abstract LoginHandler<T> loginHandler();

    private static final Logger log = LoggerFactory.getLogger(BaseLoginManager.class);

    public void doWaitBack(int playerId) {
        var info = gameCenter().removeWaitLoginInfo(playerId);
        if (info == null || (info.getClientChannel() != null && info.getClientChannel().isClosed())) {
            return;
        }
        asyncLogin(info.getPlayer(), info.getClientChannel(), Login_Wait);
    }


    public void asyncCommonLogin(final T player, final ClientChannel channel) {
        asyncLogin(player, channel, Login_Comm);
    }

    public void asyncWaitLogin(final T player, final ClientChannel channel) {
        asyncLogin(player, channel, Login_Wait);
    }

    public void asyncLogin(final T player, final ClientChannel channel, final int loginType) {
        ThreadPool.supplyAsync(() -> loginHandler().login(player))
                .thenAccept(result -> {
                            try {
                                //查询或注册数据成功
                                if (result == 1) {
                                    log.info("login from database success,loginType = {},channel = {}", loginType,channel);
                                    //如果是正常登陆
                                    if (loginType == Login_Comm) {
                                        //清空等待
                                        gameCenter().removeWaitAndClose(player.getId());
                                        //检测是否被封号
                                        if (loginHandler().hasBan(player.getId())) {
                                            try {
                                                loginHandler().doUserBeBan(player, channel);
                                                log.info("playerId = {} is ban", player.getId());
                                                return;
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            log.info("player be ban");
                                            return;
                                        }

                                        //查询是否在别的服务器上
                                        int severId = Server.instance().getRedisController().getUserGameServerId(player.getId());

                                        //在别处登录
                                        if (severId > 0) {
                                            log.info("find login info,drop old ,serverId " + severId);
                                            WaitEnterInfo waitInfo = new WaitEnterInfo(player,channel);

                                            //添加等待信息
                                            gameCenter().addWaitLoginMap(player.getId(), waitInfo);

                                            //向用户当前在线的服写数据迫使旧用户下线
                                            loginHandler().askKickReLogin(severId, player.getId(), player.getDeviceCode(),gameCenter(),this);
                                            return;
                                        }
                                    }

                                    log.info("BaseLogin init,add serverId, playerId = {}, channel = {}",player.getId(),channel);
                                    int initResult = loginHandler().initPlayer(player);
                                    log.info("BaseLogin init end,playerId = {}, channel = {}",player.getId(),channel);
                                    if (initResult != 1) {
                                        loginHandler().loginError(channel, initResult);
                                        log.info("init player error ,code is {} , player id = {}", initResult,player.getId());
                                        return;
                                    }

                                    //在这整个方法里，就有可能存在另外一个账号没有被销毁
                                    gameCenter().doForceRemoveBeforeAddPlayer(player);

                                    //添加到系统管理类
                                    gameCenter().addPlayer(player, channel);
                                    player.setClientChannel(channel);
                                    loginHandler().writePlayerInfo(player);
                                } else {
                                    loginHandler().loginError(channel, result);
                                    log.info("loginError ,code is {}", result);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                );
    }
}
