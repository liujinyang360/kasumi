package com.kasumi.core.redis;

import com.kasumi.core.purchase.OrderInfo;

public interface RedisController {

     int saveOrder(OrderInfo info);

     String getOrder(long orderId);

     void removeOrder(long orderId);

     boolean addLogin(int playerId, String loginStr);

     void delLogin(int playerId);

     void insertBattlePlayer(int userId,int type, int serverId);

     String getSystemValue(String key);

     int getUserGameServerId(int playerId);

     int preemptSingleMatch(String tag);

     int preemptSingleSp(String tag);
}
