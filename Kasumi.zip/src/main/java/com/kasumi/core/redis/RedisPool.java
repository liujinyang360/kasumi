package com.kasumi.core.redis;

import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import redis.clients.jedis.Jedis;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;


    /*
    <?xml version="1.0" encoding="utf-8"?>
    <root>
        <redis name="game">
	        <server host="127.0.0.1" port="7000" pwd="pool-test-redis"/>
	        <config MaxIdle="50" MaxTotal="50" MinIdle="4" timeout="10000"/>
	    </redis>
	    <redis name="other">
	        <server host="127.0.0.1" port="7000" pwd="pool-test-redis"/>
	        <config MaxIdle="50" MaxTotal="50" MinIdle="4" timeout="10000"/>
	    </redis>
    </root>
     */

public class RedisPool {

    private static final String DEFAULT_POOL_NAME = "game";

    private static HashMap<String, BaseRedisPool> poolMap = new HashMap<>();

    public static void init(InputStream in, ScheduledThreadPoolExecutor executor) throws Exception {
        List<Element> children = new SAXBuilder().build(in).getRootElement().getChildren("redis");
        for(Element element : children){
            BaseRedisPool pool = new BaseRedisPool();
            pool.init(element,executor);
            poolMap.put(pool.getName(),pool);
        }

        boolean hasDefaultPool = false;

        for(var it = poolMap.keySet().iterator();it.hasNext();){
            if(it.next().equals(DEFAULT_POOL_NAME)) {
                hasDefaultPool = true;
                break;
            }
        }
        if(!hasDefaultPool){
            throw new Exception("Configs need default pool "+DEFAULT_POOL_NAME);
        }
    }
    public static Jedis getJedisByName(String name){
        return poolMap.get(name).getJedis();
    }

    public static Jedis getJedisByName(String name,int db){
        return poolMap.get(name).getJedis(db);
    }

    public static Jedis getJedis (){
        return poolMap.get(DEFAULT_POOL_NAME).getJedis();
    }

    public static Jedis getJedis (int db){
        return poolMap.get(DEFAULT_POOL_NAME).getJedis(db);
    }

    public static void close(Jedis jedis) {
        if (jedis != null) {
            jedis.close();
        }
    }
}
