package com.kasumi.core.tencent;

import com.alibaba.fastjson.JSON;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

public class TencentSmsParas {
    private HashSet<String> PhoneNumberSet = new HashSet<>();
    private String TemplateId;
    private String SmsSdkAppId;
    private String SignName = "";
    private LinkedHashSet<String> TemplateParamSet = new LinkedHashSet<>();

    public TencentSmsParas(HashSet<String> phoneNumberSet, String templateId, String smsSdkAppId,
                           LinkedHashSet<String> templateParamSet,String signName) {
        PhoneNumberSet = phoneNumberSet;
        TemplateId = templateId;
        SmsSdkAppId = smsSdkAppId;
        TemplateParamSet = templateParamSet;
        this.SignName = signName;
    }


    public String createParas() {
        LinkedHashMap<String, Object> map = new LinkedHashMap<>();
        map.put("PhoneNumberSet", PhoneNumberSet);
        map.put("TemplateId", TemplateId);
        map.put("SmsSdkAppId", SmsSdkAppId);
        map.put("SignName", SignName);
        map.put("TemplateParamSet", TemplateParamSet);
        return JSON.toJSONString(map);
    }
}
