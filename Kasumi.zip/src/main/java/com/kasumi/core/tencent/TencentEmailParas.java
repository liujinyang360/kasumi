package com.kasumi.core.tencent;

import com.alibaba.fastjson.JSON;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class TencentEmailParas {

    private String FromEmailAddress;
    private String ReplyToAddresses = "";
    private ArrayList<String> Destination = new ArrayList<>();
    private LinkedHashMap<String,Object> Template = new LinkedHashMap<>();
    private String Subject;
    private LinkedHashMap<String,String> paraMap = new LinkedHashMap<>();

    public TencentEmailParas(String sendAddress,int templateId,String subject){
        this.Destination.add(sendAddress);
        this.Template.put("TemplateID",templateId);
        this.Subject = subject;
    }

    public void setFromEmailAddress(String fromEmailAddress) {
        FromEmailAddress = fromEmailAddress;
    }

    public void setReplyToAddresses(String replyToAddresses) {
        ReplyToAddresses = replyToAddresses;
    }

    public void addTemplateData(String key,String value){
        paraMap.put(key,value);
    }

    public String createParas(){
        this.Template.put("TemplateData", JSON.toJSONString(paraMap) );
        LinkedHashMap<String,Object> map = new LinkedHashMap<>();
        map.put("FromEmailAddress",FromEmailAddress);
        map.put("ReplyToAddresses",ReplyToAddresses);
        map.put("Destination",Destination);
        map.put("Template",Template);
        map.put("Subject",Subject);
        return JSON.toJSONString(map);
    }
}
