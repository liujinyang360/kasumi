package com.kasumi.core.tencent;


import com.kasumi.modules.HttpResult;
import com.kasumi.utils.tool.HttpUtils;
import com.kasumi.utils.tool.OkHttpUtils;
import com.kasumi.utils.tool.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;


public class TencentMailManager {
    private static String url;
    private static String subject;
    private static int templateId;
    private static String fromEmailAddress;
    private static String version;
    private static String region;


    private static final Logger log = LoggerFactory.getLogger(TencentMailManager.class);

    public static void initMailProps(Properties mailProps) throws Exception {
        url = mailProps.getProperty("mail.url");
        subject = mailProps.getProperty("mail.subject");
        templateId = Integer.parseInt(mailProps.getProperty("mail.templateId"));
        fromEmailAddress = mailProps.getProperty("mail.fromEmailAddress");
        version = mailProps.getProperty("mail.version");
        region = mailProps.getProperty("mail.region");

        String secret_id = mailProps.getProperty("mail.secretId");
        TencentAuthorization.setSecretId(secret_id);
        String secret_key = mailProps.getProperty("mail.secretKey");
        TencentAuthorization.setSecretKey(secret_key);
        System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
    }

    public static void sendMail(String userAddress, String content, HttpResult httpResult) {
        String timestamp = String.valueOf(Time.getCurrentSeconds());
        try {
            TencentEmailParas tp = new TencentEmailParas(userAddress, templateId, subject);
            tp.addTemplateData("code", content);
            tp.setFromEmailAddress(fromEmailAddress);

            String params = tp.createParas();

            Map<String, String> headers = new HashMap<>();
            headers.put("Authorization", TencentAuthorization.makeAuthorization(timestamp, params));
            headers.put("Content-Type", "application/json; charset=utf-8");

            headers.put("X-TC-Action", "SendEmail");
            headers.put("X-TC-Version", version);
            headers.put("X-TC-Timestamp", timestamp);
            headers.put("X-TC-Region", region);
            //HttpUtils.post(url, params,  headers, httpResult);
            OkHttpUtils.doHttpRequest(url, params, "post", headers, httpResult);
            log.info("send mail finished ....");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
