package com.kasumi.core.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kasumi.conf.CommProperties;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.HttpResult;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.MD5;
import com.kasumi.utils.tool.OkHttpCallback;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;

/**
 * 非消耗品恢复
 */

public class IosNonExpendPurchase<T extends IGamePlayer> extends HttpResult {

    private T player;
    private long orderId;
    private String token;
    private String fullToken;
    private IosNonExpendableHandler handler;
    private int times;
    private String md5Token;

    private static final Logger log = LoggerFactory.getLogger(IosNonExpendPurchase.class);

    public IosNonExpendPurchase(T player, long orderId, String token, String fullToken, IosNonExpendableHandler handler, int times) {
        this.player = player;
        this.orderId = orderId;
        this.token = token;
        this.fullToken = fullToken;
        this.handler = handler;
        this.times = times;
        this.md5Token = MD5.md5s(this.fullToken);
    }

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    @Override
    public void doException(Throwable ex) {
        exception(ex);
    }

    public void exception(Throwable ex) {
        ex.printStackTrace();
        handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error,orderId,"",0,this.md5Token);
        log.error("IosNonExpendPurchase auth exception,user is {},order is {}",player.getId(),1);
    }

    public void success(String body, int code) {
        try {
            log.info("IosNonExpendPurchase auth is {}",body);
            if (code == 200) {
                JSONObject obj = JSON.parseObject(body);
                String status = obj.getString("status");

                if("21007".equals(status)){
                    if(times <= 1){
                        log.info(" verify status is 21007");
                        PurchaseManager.doIosNonExpendOrderId(player,orderId,fullToken,handler,times + 1);
                        return;
                    }
                }

                if ("0".equals(status)) {
                    var receipt = obj.getJSONObject("receipt");
                    String productId = receipt.getString("product_id");

                    if(!IosSpecialManager.isNonExpendableItem(productId)){
                        log.info("No NonExpend order");
                        handler.writeTransactionVerify(player, BaseMessageCode.No_NonExpendOrder,orderId,productId,0, this.md5Token);
                        return;
                    }

                    //根据orderId获取的未验证订单
                    var tmpInfo = handler.getOrderFromRedisByOrderId(orderId);
                    //根据userId以及productId获取的未验证订单
                    if(tmpInfo == null){
                        tmpInfo = handler.getOrderFromDbByProduceId(player.getId(),productId);
                    }

                    //根据productId从Redis获取订单
                    if(tmpInfo == null) {
                        tmpInfo = handler.getOrderFromRedis(productId);
                    }
                    //从数据库中获取订单
                    if(tmpInfo == null){
                        tmpInfo = handler.getOrderFromDbByProduceId(-1,productId);
                    }

                    if(tmpInfo == null){
                        handler.writeTransactionVerify(player, BaseMessageCode.Order_Not_Exist,orderId,productId,0, this.md5Token);
                    }else{

                        if(tmpInfo.isVerify()){
                            handler.transActionSuccess(player,tmpInfo, CommProperties.OrderVerify_Success_IosNonExpend,true, this.md5Token);
                        }else {
                            if(orderId == 1) {
                                tmpInfo.setMissOrder(true);
                            }
                            tmpInfo.setPurchaseData(body);
                            tmpInfo.setPurchaseToken(this.fullToken);
                            handler.transActionSuccess(this.player, tmpInfo, CommProperties.OrderVerify_Success_IosNonExpend,false, this.md5Token);
                        }
                    }
                } else {
                    log.error("IosNonExpendPurchase auth Token_Error,user is {}",player.getId());
                    handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Token_Error,orderId,"",0, this.md5Token);
                }
            } else {
                handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error,orderId,"",0, this.md5Token);
                log.error("IosNonExpendPurchase error response is {},user is {},token is {}",code,this.player.getId(),this.token);
            }
        }catch(Exception e){
            log.error("IosNonExpendPurchase auth exception,user is {}",player.getId());
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error,orderId,"",0, this.md5Token);
            e.printStackTrace();
        }finally {
            handler.removeCheckOrder(player,orderId,this.md5Token);
        }
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}
