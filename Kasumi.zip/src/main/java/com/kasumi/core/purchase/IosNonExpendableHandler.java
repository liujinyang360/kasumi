package com.kasumi.core.purchase;


import com.kasumi.modules.player.IGamePlayer;

public interface IosNonExpendableHandler<T extends IGamePlayer> {

    OrderInfo getOrderFromRedisByOrderId(long orderId);

    /**
     * 从角色中获取订单
     * @param orderId 订单ID
     * @return 订单
     */
    OrderInfo getOrderFromDb(long orderId);

    /**
     * 从Redis中获取一个订单
     * @param productId 商品ID
     * @return 订单
     */
    OrderInfo getOrderFromRedis(String productId);

    /**
     * 从数据库中获取一个订单
     * @param userId
     * @param produceId
     * @return
     */
    OrderInfo getOrderFromDbByProduceId(int userId,String produceId);

    /**
     * 发送订单验证结果
     * @param player 玩家
     * @param result 结果
     * @param orderId 订单id
     * @param productId 商品id
     * @param purchaseType 交易类型
     */
    void writeTransactionVerify(T player, int result, long orderId, String productId, int purchaseType,String md5Token);

    /**
     * 交易成功后的处理
     * @param player 玩家
     * @param info 订单
     * @param purchaseType 交易类型
     */
    void transActionSuccess(T player, OrderInfo info, int purchaseType,boolean hasVerify,String md5Token);

    /***
     * 恢复非消耗品订单ID 删除
     */
    void  removeCheckOrder(T player,long orderId,String md5Token);
}
