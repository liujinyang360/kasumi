package com.kasumi.core.purchase;



import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.kasumi.conf.CommProperties;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;



public class PurchaseManager {
    /**
     * google验证返回格式
     * {
     *   "kind": "androidpublisher#productPurchase", //代表androidpublisher服务中的inappPurchase对象
     *   "purchaseTimeMillis": long, //购买产品的时间，自纪元（1970年1月1日）以来的毫秒数。
     *   "purchaseState": integer, //订单的购买状态; 0:购买 1:取消 2:挂起(待支付)
     *   "consumptionState": integer, //inapp消费状态。0:未消费 1:已消费
     *   "developerPayload": string,//开发人员指定的字符串，包含有关订单的补充信息。
     *   "orderId": string, //与购买inapp产品相关联的订单ID。
     *   "purchaseType": integer, //购买inapp产品的类型。仅当未使用标准应用内结算流程进行此购买时，才会设置此字段。可能的值是：0. 测试（即从许可证测试帐户购买）1. 促销（即使用促销代码购买）2. 奖励（即观看视频广告而非付费）
     *   "acknowledgementState": //inapp产品的确认状态。0:待确认 1:已确认
     *
     *   {
     *  "kind": "androidpublisher#productPurchase",
     *  "purchaseTimeMillis": "1579562981614",
     *  "purchaseState": 0,
     *  "consumptionState": 0,
     *  "developerPayload": "144002",
     *  "orderId": "GPA.3315-6429-0191-69633",
     *  "acknowledgementState": 1
     * }
     * }
     *
     * IOS返回格式
     *  {
     *  "receipt":
     *  {
     *  "original_purchase_date_pst":"2015-06-22 20:56:34 America/Los_Angeles",//购买时间,太平洋标准时间
     *  "purchase_date_ms":"1435031794826",//购买时间毫秒
     *  "unique_identifier":"5bcc5503dbcc886d10d09bef079dc9ab08ac11bb",//唯一标识符
     *  "original_transaction_id":"1000000160390314",//原始交易ID
     *  "bvrs":"1.0",//iPhone程序的版本号
     *  "transaction_id":"1000000160390314",//交易的标识
     *  "quantity":"1",//购买商品的数量
     *  "unique_vendor_identifier":"AEEC55C0-FA41-426A-B9FC-324128342652",//开发商交易ID
     *  "item_id":"1008526677",//App Store用来标识程序的字符串
     *  "product_id":"cosmosbox.strikehero.gems60",//商品的标识
     *  "purchase_date":"2015-06-23 03:56:34 Etc/GMT",//购买时间
     *  "original_purchase_date":"2015-06-23 03:56:34 Etc/GMT",//原始购买时间
     *  "purchase_date_pst":"2015-06-22 20:56:34 America/Los_Angeles",//太平洋标准时间
     *  "bid":"com.cosmosbox.StrikeHero",//iPhone程序的bundle标识
     *  "original_purchase_date_ms":"1435031794826"//毫秒
     *  },
     * "status":0//状态码,0为成功
     * }
     */

    private static List<String> SCOPED = Arrays.asList( "https://www.googleapis.com/auth/androidpublisher");
    private static String androidPacketName = "com.sports.real.golf.rival.online";
    private static String iosPacketName = "com.sports.real.golf.rival.online";
    private static String googleUrl = "https://www.googleapis.com/androidpublisher/v3/applications/"+ androidPacketName +"/purchases/products/%pid%/tokens/%token%?access_token=%acc%";
    private static String googleAuthFile = "configs/mlegend.json";
    private static GoogleToken googleToken = null;
    private static String IOS_VERIFY_RECEIPT_SANDBOX_URL = "https://sandbox.itunes.apple.com/verifyReceipt";
    private static String IOS_VERIFY_RECEIPT_URL = "https://buy.itunes.apple.com/verifyReceipt";
    private static boolean IOS_TEST_PAY = false;
    private static final HashMap<String,String> IOS_HEADER_MAP = new HashMap<>(1);

    //是否验证google订单,通常用于google鉴权文件出问题的时候
    private static boolean checkGooglePurchase = true;

    private static final Logger log = LoggerFactory.getLogger(PurchaseManager.class);

    static{
        IOS_HEADER_MAP.put("Content-Type","application/json");
    }

    public static void setSCOPED(List<String> SCOPED) {
        PurchaseManager.SCOPED = SCOPED;
    }

    public static void setGoogleAuthFile(String googleAuthFile) {
        PurchaseManager.googleAuthFile = googleAuthFile;
    }

    public static void setIosPacketName(String iosPacketName) {
        PurchaseManager.iosPacketName = iosPacketName;
    }

    public static void setAndroidPacketName(String androidPacketName) {
        PurchaseManager.androidPacketName = androidPacketName;
    }

    public static void setGoogleUrl(String googleUrl) {
        PurchaseManager.googleUrl = googleUrl;
    }

    public static void setGoogleToken(GoogleToken googleToken) {
        PurchaseManager.googleToken = googleToken;
    }

    public static void setIosVerifyReceiptSandboxUrl(String iosVerifyReceiptSandboxUrl) {
        IOS_VERIFY_RECEIPT_SANDBOX_URL = iosVerifyReceiptSandboxUrl;
    }

    public static void setIosVerifyReceiptUrl(String iosVerifyReceiptUrl) {
        IOS_VERIFY_RECEIPT_URL = iosVerifyReceiptUrl;
    }

    public static void setIosTestPay(boolean iosTestPay) {
        IOS_TEST_PAY = iosTestPay;
    }

    public static String getPacketName(int osType){
        return osType == CommProperties.Os_Android ?  androidPacketName : iosPacketName;
    }

    public synchronized static String getAccessToken(int tokenIndex) {
        int now = Time.getCurrentSeconds();
        if (googleToken == null || now > (googleToken.gainTime + googleToken.expireTime - 300)) {
            try {
                googleToken = new GoogleToken();
                String[] authFiles = googleAuthFile.split(";");
                for (String path : authFiles) {
                    GoogleCredential credential = GoogleCredential
                            .fromStream(Tools.getInputStreamByFilePath(path))
                            .createScoped(SCOPED);

                    // 刷新token
                    credential.refreshToken();

                    if (googleToken.tokens == null) {
                        googleToken.tokens = new ArrayList<>();
                        googleToken.gainTime = now;
                        googleToken.expireTime = credential.getExpiresInSeconds().intValue();
                    }
                    googleToken.tokens.add(credential.getAccessToken());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (googleToken == null || googleToken.tokens == null || googleToken.tokens.isEmpty()) {
            return null;
        }
        return tokenIndex >= googleToken.tokens.size() ? null : googleToken.tokens.get(tokenIndex);
    }


    public static <T extends IGamePlayer> void doGoogleAuth(final T player, OrderInfo info, OrderHandler handler, int tokenIndex, int retryTimes){
        final String accessToken = getAccessToken(tokenIndex);
        //没有成功获取token
        if(accessToken == null){
            log.error("get access token failed ");
            handler.writeTransactionVerify(player, BaseMessageCode.Server_Error,info.getOrderId(),"",0);
            return;
        }
        log.info("google verify,user is {}",player.getId());

        if(!checkGooglePurchase){
            int purchaseType = CommProperties.Purchase_Success_Type;
            info.setPurchaseType(purchaseType);
            handler.transActionSuccess(player,info,purchaseType);
            return;
        }

        GooglePurchase gp = new GooglePurchase(player,info,handler, tokenIndex,retryTimes);
        String productId = info.getProductId();
        String token = info.getPurchaseToken();

        String url = googleUrl.replace("%pid%",productId).replace("%token%",token).replace("%acc%",accessToken);
        //HttpUtils.get(url,null, gp);
        OkHttpUtils.doHttpRequest(url, null, "get", null, gp);
    }

    public static <T extends IGamePlayer> void doIosAuth(final T player, OrderInfo info, OrderHandler handler,int times, int retryTimes){
        log.info("ios verify,user is {}",player.getId());
        String deCode = new String( Base64.decode(info.getPurchaseToken()));

        IosPurchase ip= new IosPurchase(player,info, handler,times, retryTimes);
        String url = getIosUrl(times);

        //HttpUtils.post(url, deCode,IOS_HEADER_MAP, ip);
        OkHttpUtils.doHttpRequest(url, deCode, "post", IOS_HEADER_MAP, ip);
    }


    public static<T extends IGamePlayer> void doIosMissOrderAuth(final T player,String token,OrderHandler handler,int times){
        log.info("ios verify,user is {}",player.getId());

        String deCode = new String(Base64.decode(token));
        IosMissOrderIdPurchase ip= new IosMissOrderIdPurchase(player,deCode,token,handler,times);
        String url = getIosUrl(times);

        //HttpUtils.post(url,deCode,IOS_HEADER_MAP, ip);
        OkHttpUtils.doHttpRequest(url, deCode, "post", IOS_HEADER_MAP, ip);
    }


    public static<T extends IGamePlayer> void doAndroidMissOrderAuth(final T player,String token,OrderHandler handler,int times , String productId){
        final String accessToken = getAccessToken(0);
        //没有成功获取token
        if(accessToken == null){
            log.error("get access token failed ");
            handler.writeTransactionVerify(player, BaseMessageCode.Server_Error,1,"",0);
            return;
        }
        log.info("AndroidMissOrder verify,user is {}",player.getId());

//        if(!checkGooglePurchase){
//            int purchaseType = CommProperties.Purchase_Success_Type;
//            info.setPurchaseType(purchaseType);
//            handler.transActionSuccess(player,info,purchaseType);
//            return;
//        }

        AndriodMissOrderIdPurchase gp = new AndriodMissOrderIdPurchase(player,token,handler,times,productId);
        String url = googleUrl.replace("%pid%",productId).replace("%token%",token).replace("%acc%",accessToken);
        //HttpUtils.get(url,null, gp);
        OkHttpUtils.doHttpRequest(url, null, "get", null, gp);
    }




    public static String getIosUrl(int times) {
        if (IOS_TEST_PAY) {
            return IOS_VERIFY_RECEIPT_SANDBOX_URL;
        }
        String url = IOS_VERIFY_RECEIPT_SANDBOX_URL;
        if(times <= 1){
            url = IOS_VERIFY_RECEIPT_URL;
        }
        return url;
    }

    /**
     * iso提审-orderId丢失
     * 官方文档：Verify your receipt first with the production URL; then verify with the sandbox URL if you receive a 21007 status code.
     * 先验证正式地址，再验证沙箱地址
     * @param player
     * @param token
     * @param handler
     * @param <T>
     */
    public static<T extends IGamePlayer> void doIosAuditMissOrderId(final T player,String token,OrderHandler handler, int times){
        log.info("ios MissAudit verify,user is {}",player.getId());

        String deCode = new String(Base64.decode(token));
        IosAuditMissIdPurchase iamp = new IosAuditMissIdPurchase(player,deCode,token,handler,times);

        String url = getIosUrl(times);

        //HttpUtils.post(url, deCode,IOS_HEADER_MAP, iamp);
        OkHttpUtils.doHttpRequest(url, deCode, "post", IOS_HEADER_MAP, iamp);
    }


    /**
     * iso非消耗品恢复
     * 官方文旦：Verify your receipt first with the production URL; then verify with the sandbox URL if you receive a 21007 status code.
     * 先验证正式地址，code=21007后验证沙箱地址
     * @param player
     * @param token
     * @param handler
     * @param <T>
     */
    public static<T extends IGamePlayer> void doIosNonExpendOrderId(
            final T player,long orderId,String token,IosNonExpendableHandler handler,int times){
        log.info("ios nonExpend verify,user is {}",player.getId());

        String deCode = new String(Base64.decode(token));
        IosNonExpendPurchase np = new IosNonExpendPurchase(player,orderId,deCode,token,handler,times);
        String url = getIosUrl(times);
        //HttpUtils.post(url,deCode,IOS_HEADER_MAP, np);
        OkHttpUtils.doHttpRequest(url, deCode, "post", IOS_HEADER_MAP, np);
    }

    public static void setCheckGooglePurchase(boolean checkGooglePurchase) {
        PurchaseManager.checkGooglePurchase = checkGooglePurchase;
    }


}




