package com.kasumi.core.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.HttpResult;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.OkHttpCallback;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;

/**
 * 提审
 */
public class IosAuditMissIdPurchase<T extends IGamePlayer> extends HttpResult {
    private T player;
    private String token;
    private String fullToken;
    private OrderHandler handler;
    private int times;

    private static final Logger log = LoggerFactory.getLogger(IosAuditMissIdPurchase.class);

    public IosAuditMissIdPurchase(T player, String token, String fullToken, OrderHandler handler, int times) {
        this.player = player;
        this.token = token;
        this.fullToken = fullToken;
        this.handler = handler;
        this.times = times;
    }

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    @Override
    public void doException(Throwable ex) {
        exception(ex);
    }

    public void exception(Throwable ex) {
        ex.printStackTrace();
        handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, 1, "", 0);
        log.error("IOS audit exception,user is {},order is {}", player.getId(), 1);
    }

    public void success(String body, int code) {
        try {
            log.info("ios auth is {}", body);
            if (code == 200) {
                JSONObject obj = JSON.parseObject(body);
                String status = obj.getString("status");

                if("21007".equals(status)){
                    if(times <= 1){
                        log.info(" verify status is 21007");
                        PurchaseManager.doIosAuditMissOrderId(player,fullToken,handler,times + 1);
                        return;
                    }
                }
                if ("0".equals(status)) {
                    var receipt = obj.getJSONObject("receipt");
                    String productId = receipt.getString("product_id");

                    OrderInfo info = this.handler.getOrderFromDbByProduceId(player.getId(), productId);
                    if (info != null) {
                        info.setMissOrder(true);
                        info.setPurchaseData(body);
                        info.setPurchaseToken(this.fullToken);
                        int purchaseType = IosPurchase.calPurchaseType(times);
                        info.setPurchaseType(purchaseType);
                        handler.transActionSuccess(this.player, info, purchaseType);
                    } else {
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Not_Exist, 1, productId, 0);
                    }
                } else {
                    int codeErr = BaseMessageCode.Order_Token_Error;
                    if("21005".equals(status)){
                        codeErr = BaseMessageCode.ThirdPartyServiceError;
                    }
                    log.error("ios auth Token_Error,user is {}", player.getId());
                    handler.writeTransactionVerify(this.player, codeErr, 1, "", 0);
                }
            } else {
                handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, 1, "", 0);
                log.error("ios error response is {},user is {},token is {}", code, this.player.getId(), this.token);
            }
        } catch (Exception e) {
            log.error("ios auth exception,user is {}", player.getId());
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, 1, "", 0);
            e.printStackTrace();
        } finally {
            player.removeCheckOrder(1);
        }
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}