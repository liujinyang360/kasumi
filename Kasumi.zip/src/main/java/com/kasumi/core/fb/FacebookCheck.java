package com.kasumi.core.fb;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kasumi.conf.CommProperties;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.HttpResult;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.OkHttpCallback;
import com.samus.core.utils.Tools;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.samus.core.utils.Tools;


import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.Map;


public abstract class FacebookCheck<T extends IGamePlayer> extends HttpResult {
    private final T player;
    private final String facebookToken;
    private final int type;
    public final boolean limitedLogin;
    private static final Logger log = LoggerFactory.getLogger(FacebookCheck.class);

    public T getPlayer() {
        return player;
    }
    public String getFacebookToken() {
        return facebookToken;
    }

    public FacebookCheck(T player, String token, int type) {
        this.player = player;
        this.facebookToken = token;
        this.type = type;
        this.limitedLogin = false;
    }

    public FacebookCheck(T player,String token, int type,boolean limitedLogin){
        this.player = player;
        this.facebookToken = token;
        this.type = type;
        this.limitedLogin = limitedLogin;
    }

    /**
     * 写错误信息
     *
     * @param error 错误信息
     */
    protected abstract void writeErrorInfo(int error, int type);

    /**
     * 从数据库中获取基本信息
     *
     * @param facebookId facebookId
     * @return 基本信息map
     */
    protected abstract Map<String, String> getSimpleInfoFromDb(String facebookId);

    /**
     * 邀请安装处理
     *
     * @param facebookId fb
     */
    protected abstract void dealInvite(String facebookId, int uid);

    protected abstract void updateFacebookInfo(T player, String facebookId);

    protected abstract void doFinished(int id, String name, String headerUrl, String fbEmail);

    protected abstract void writeRespInfo(Map<String, String> map, int result, int type);

    protected abstract void saveFbName(int uid,String oldFbName,String newFbName);

    /**
     * 切换账号返回数据
     *
     * @param map
     * @param name
     * @param headerUrl
     * @param facebookId
     */
    protected abstract void writeSwitchInfo(Map<String, String> map, String name, String headerUrl, String facebookId);


    @Override
    public void doException(Throwable ex) {
        exception(ex);
    }

    public void exception(Throwable ex) {
        log.info("check failed....");
        ex.printStackTrace();
        writeErrorInfo(BaseMessageCode.Server_Error, type);
    }

    public void success(String data, int code) {
        if (code == 200) {
            try {
                String name = "";
                String email = "";
                String headerUrl = "";
                String facebookId = "";

                /**
                 * 如果是受限登录（客户端ATT没有被接受）
                 */
                if(isLimitedLogin()){
                    String jwks = data;
                    JWKSet jwkSet = JWKSet.parse(jwks);

                    // 验证ID Token
                    boolean isValid = validateIDToken(getFacebookToken(), jwkSet);
                    if (!isValid) {
                        log.error("bind facebook error playerId == {}", getPlayer().getId());
                        writeErrorInfo(BaseMessageCode.AccountCheckFail, getType());
                        return;
                    }

                    log.info("ID Token验证成功  playerId = {} " ,getPlayer().getId());
                    JWTClaimsSet claims = SignedJWT.parse(getFacebookToken()).getJWTClaimsSet();

                    /**
                     * 过期时间
                     */
                    int exp = (int)(claims.getExpirationTime().getTime() / 1000);
                    if(Tools.getCurrentSeconds() >= exp){
                        log.error("token 已过期");
                        writeErrorInfo(BaseMessageCode.AccountCheckFail,getType());
                        return;
                    }

                    facebookId = claims.getSubject();
                    name = claims.getStringClaim("name");
                    headerUrl = claims.getStringClaim("picture");
                    email = claims.getStringClaim("email");

                    if(name == null) {
                        log.error("facebook check error playerId {}, name is null", player.getId());
                        writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
                        return;
                    }

                    if(email == null){
                        email = "";
                    }
                    if(headerUrl == null){
                        headerUrl = "";
                    }

                    System.out.println("用户ID: " + facebookId);
                    System.out.println("用户名: " + name);
                    System.out.println("电子邮件: " + email);
                    System.out.println("picture: " + headerUrl);
                }
                else {
                    JSONObject jsonObject = JSON.parseObject(data);
                    if (jsonObject.get("error") != null) {
                        log.error("bind facebook error playerId == {}", player.getId());
                        writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
                        return;
                    }

                    facebookId = jsonObject.get("id").toString();
                    var nameJson = jsonObject.get("name");
                    if (nameJson == null) {
                        log.error("facebook check error playerId {}, json {}", player.getId(), data);
                        writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
                        return;
                    }
                    name = nameJson.toString();
                    JSONObject innerJson = jsonObject.getJSONObject("picture").getJSONObject("data");
                    headerUrl = innerJson.get("url").toString();
                    email = "";
                    var jsonEmail = jsonObject.get("email");
                    if (jsonEmail != null) {
                        email = jsonEmail.toString();
                    }
                }

                var map = getSimpleInfoFromDb(facebookId);
                if (type == CommProperties.ACCOUNT_BIND) {
                    if (map.size() == 0) {
                        //邀请安装处理
                        //player.setName(name);
                        player.setHeader(headerUrl);
                        dealInvite(facebookId, player.getId());
                        updateFacebookInfo(player, facebookId);
                        saveFbName(player.getId(),player.getFacebookName(),name);
                        //个人信息缓存更新
                        doFinished(player.getId(), name, headerUrl, email);
                        log.info("facebook bind, update fb message userId = {}, name = {}, header = {}", player.getId(),
                                name, headerUrl);
                    } else {
                        //该facebookID已绑定过账号， 返回账号信息
                        log.info("facebookId == {} 已绑定过账号，返回给客户端账号信息， bindUserId = {}", facebookId, map.get("user_id"));
                        writeRespInfo(map, BaseMessageCode.HadBindOtherAccount, this.type);
                        int uid = Integer.parseInt(map.get("user_id"));
                        saveFbName(uid,map.get("facebook_name"),name);
                    }
                } else {
                    if (map.size() == 0) {
                        writeErrorInfo(BaseMessageCode.AccountNotExist, type);
                    } else {
                        log.info("switch fb account, userId = {}, name = {}, token = {}, oldUserId = {}",
                                map.get("user_id"), name, map.get("token"), player.getId());
                        writeSwitchInfo(map, name, headerUrl, facebookId);
                        int uid = Integer.parseInt(map.get("user_id"));
                        saveFbName(uid,map.get("facebook_name"),name);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                log.error("fb account check fail, type {}", this.type);
                writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
            }
        } else {
            log.error("fb account check fail, type {},code = {}", this.type,code);
            log.error("response = {}",data);
            writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
        }
    }

    private static boolean validateIDToken(String idTokenString, JWKSet jwkSet) throws Exception {
        SignedJWT signedJWT = SignedJWT.parse(idTokenString);
        JWSObject jwsObject = JWSObject.parse(idTokenString);
        JWK jwk = jwkSet.getKeyByKeyId(jwsObject.getHeader().getKeyID());

        if (jwk == null || !(jwk instanceof RSAKey)) {
            throw new IllegalArgumentException("JWK key not found or is not an RSA key");
        }

        RSAKey rsaKey = (RSAKey) jwk;
        RSASSAVerifier verifier = new RSASSAVerifier(rsaKey);

        return signedJWT.verify(verifier);
    }

    public int getType() {
        return type;
    }

    public boolean isLimitedLogin() {
        return limitedLogin;
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }
}
