package com.kasumi.core.playercenter;


import com.kasumi.conf.CommProperties;
import com.kasumi.io.ClientChannel;
import com.kasumi.io.packet.WritePacket;
import com.kasumi.modules.player.IPlayer;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @desc: 游戏用户管理中心
 * * 游戏服玩家一般只在连接断开时销毁
 * 加入了web socket
 * @author:
 */

public abstract class PlayerCenter<T extends IPlayer> {
    /**
     * 检测是否掉线的map
     * 预防连接后没有登录,channel一直不关闭的情况,应该进行超时处理,用户登录后从此列表中移除
     */
    protected final ConcurrentHashMap<Channel, Long> channelTimeMap = new ConcurrentHashMap<>();
    /**
     * 玩家列表[id,Player]
     */
    protected final ConcurrentHashMap<Integer, T> playerMap = new ConcurrentHashMap<>();
    /**
     * 玩家列表[Channel,Player]
     */
    protected final ConcurrentHashMap<ClientChannel, T> channelPlayerMap = new ConcurrentHashMap<>();

    /**
     * 连接对应map
     */
    protected final ConcurrentHashMap<Channel, ClientChannel> channelMap = new ConcurrentHashMap<>();

    /**
     * 等待进入的玩家
     */
    protected final ConcurrentHashMap<Integer, WaitEnterInfo<T>> waitToEnterMap = new ConcurrentHashMap<>();

    private static final Logger log = LoggerFactory.getLogger(PlayerCenter.class);


    public abstract void deleteFromRedis(int userId);

    public abstract long getTimeOutTime(ClientChannel ch);

    public ClientChannel getOrCreateClientChannel(Channel channel, boolean isWebsocket, long timeOut) {
        var clientChannel = channelMap.get(channel);
        if (clientChannel == null) {
            clientChannel = new ClientChannel(channel,isWebsocket, timeOut);
            channelMap.put(channel, clientChannel);
        }
        clientChannel.setLastReceiveTime(System.currentTimeMillis());
        return clientChannel;
    }


    /**
     * 服务器主动踢掉玩家,一般是出现错误的时候
     *
     * @param channel 连接对象
     * @param reason  踢掉的原因
     */
    public void serverDropPlayer(Channel channel, String... reason) {
        if (channel != null) {
            channel.close();
        }
        if(reason.length > 0){
            log.info("server drop player,reason is {}",reason[0]);
        }
    }


    /**
     * 强制移除玩家对象
     *
     * @param player 玩家对象
     */
    public void forceRemovePlayer(T player) {
        log.info("force remove player id is {},channel is {}", player.getId(), player.getClientChannel());
        playerMap.remove(player.getId());
        if (player.getClientChannel() != null) {
            channelMap.remove(player.getClientChannel().getChannel());
            channelPlayerMap.remove(player.getClientChannel());
            player.getClientChannel().close();
        }
        deleteFromRedis(player.getId());
    }

    public void logoutByReLogin(int playerId) {
        T player = getPlayer(playerId);
        if (player != null) {
            try {
                //设置玩家的下线类型
                player.setLeaveType(CommProperties.LEAVE_TYPE_RELOGIN);
                //通知玩家要掉线
                removePlayer(playerId, player.getClientChannel());
                deleteFromRedis(playerId);

                player.destroy();
                log.info("relogin ,player is {},channel is {}", playerId, player.getClientChannel());
                player.getClientChannel().close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            deleteFromRedis(playerId);
        }
    }

    /**
     * 是否有这个玩家
     *
     * @param userId 玩家id
     * @return 是否有玩家
     */
    public boolean hasPlayer(int userId) {
        return playerMap.containsKey(userId);
    }


    public void checkTimeout(){
        checkChannelTimeout();
        checkPlayerTimeout();
        checkWaitTimeout();
    }

    protected void checkChannelTimeout(){
        long now = System.currentTimeMillis();
        for (Iterator<Map.Entry<Channel, Long>> it = channelTimeMap.entrySet().iterator(); it.hasNext();) {
            Map.Entry<Channel, Long> entry = it.next();
            Channel ch = entry.getKey();
            long time = entry.getValue();
            if (now - time >= CommProperties.Channel_Timeout) {
                try {
                    if (ch != null && ch.isOpen()) {
                        ch.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                it.remove();
                if (ch != null) {
                    log.info("close client channel, channel is {}, {}, {}", ch, ch.isActive(), ch.remoteAddress());
                }
            }
        }
    }

    protected void checkPlayerTimeout(){
        long now = System.currentTimeMillis();
        for(var it = channelPlayerMap.entrySet().iterator();it.hasNext();){
            var entry = it.next();
            var ch = entry.getKey();
            var player = entry.getValue();
            if (now - ch.getLastReceiveTime() >= getTimeOutTime(ch)) {
                player.setTimeout(true);

                log.info("close client channel,channel is {},{},{},{}",ch,ch.isClosed(),player.getId(),ch.getLastReceiveTime());
                if(ch.isClosed()){
                    it.remove();
                }else {
                    ch.close();
                }
            }
        }
    }

    protected void checkWaitTimeout(){
        long now = System.currentTimeMillis();
        for(var it = waitToEnterMap.values().iterator();it.hasNext();){
            var info = it.next();
            if(now - info.getWaitTime() > CommProperties.Wait_Timeout){
                it.remove();
                try {
                    log.info("wait enter is Time out,player is {}",info.getPlayer().getId());
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }


    public void addCheckTimeChannel(Channel channel) {
        channelTimeMap.put(channel, System.currentTimeMillis());
    }

    public void removeCheckTimeChannel(Channel channel) {
        channelTimeMap.remove(channel);
    }

    public void dropAllPlayers() {
        for (var it = playerMap.values().iterator(); it.hasNext(); ) {
            var player = it.next();
            try {
                var channel = player.getClientChannel();
                if (channel != null) {
                    channel.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * 给所有在线的玩家发送数据
     *
     * @param mp 要广播的消息
     */
    public void broadcast(WritePacket mp) {
        if (mp == null) {
            return;
        }
        ByteBuf buf = mp.toBuf();
        for (ClientChannel channel : channelPlayerMap.keySet()) {
            if (channel != null && !channel.isClosed()) {
                channel.sendPacket(buf.copy());
            }
        }
        mp.release();
    }

    public T getPlayer(ClientChannel channel) {
        return channel == null ? null : channelPlayerMap.get(channel);
    }

    public void addPlayer(T player, ClientChannel clientChannel) {
        log.info("add player {},channel is {}", player.getId(), clientChannel);
        playerMap.put(player.getId(), player);

        channelPlayerMap.put(clientChannel, player);
        //移除检测
        removeCheckTimeChannel(clientChannel.getChannel());
    }

    public void addWaitLoginMap(int uid, WaitEnterInfo<T> wi) {
        waitToEnterMap.put(uid, wi);
    }

    public WaitEnterInfo<T> removeWaitLoginInfo(int id) {
        return waitToEnterMap.remove(id);
    }

    //清空
    public void removeWaitAndClose(int playerId) {
        var info = this.removeWaitLoginInfo(playerId);
        if (info != null) {
            ClientChannel channel = info.getClientChannel();
            if (channel != null && channel.isOpen()) {
                channel.close();
            }
        }
    }

    public void removePlayer(int playerId, ClientChannel channel) {
        log.warn("remove player id is {},channel is {}", playerId, channel);
        playerMap.remove(playerId);
        removeClientChannel(channel);
    }

    public void removeClientChannel(ClientChannel channel){
        if (channel != null) {
            channelMap.remove(channel.getChannel());
            channelPlayerMap.remove(channel);
        }
    }

    public T getPlayer(int playerId) {
        return playerMap.get(playerId);
    }

    public ConcurrentHashMap<Integer, T> getPlayerMap() {
        return playerMap;
    }
}
