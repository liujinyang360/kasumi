package com.kasumi.core.playercenter;

import com.kasumi.core.Server;
import com.kasumi.io.ClientChannel;
import com.kasumi.modules.player.IBattlePlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BattlePlayerCenter<T extends IBattlePlayer> extends PlayerCenter<T> {

    private static final Logger log = LoggerFactory.getLogger(BattlePlayerCenter.class);

    /**
     * 断线重连
     * @param uid 用户id
     * @param roomId 房间id
     * @param sign 随机号
     * @param clientChannel 连接
     * @return 成功与否
     */
    public abstract int reconnect(int uid, long roomId, int sign, ClientChannel clientChannel);

    /***
     * 创建等待进入的对象
     * @param player 等待进入的玩家
     * @param entryTpe 进入类型
     * @param ch 到客户端的连接
     * @return 等待进入房间的对象
     */
    public abstract WaitEnterInfo<T> createBattleWaitEnterInfo(T player, int entryTpe, ClientChannel ch);

    /**
     * 中心服强制踢掉玩家
     * 一般因为某种异常
     * @param userId 玩家id
     */
    public void dropPlayerByCentral(int userId){
        var bp = playerMap.get(userId);
        if(bp != null){
            this.removePlayer(bp.getId(),bp.getClientChannel());
            log.info("destroy battle player is {},reason is central force drop",bp.getId());
            var room = bp.getRoom();
            if(room != null){
                room.setShouldDestroy(true);
            }
        }
    }

    /**
     * 添加一个玩家
     * 如果存在老玩家,进行比较,对象不同,销毁老对象
     * 再比较channel,channel不同,关闭channel
     * @param player 玩家对象
     */
    public synchronized void addPlayer(T player){
        var oldPlayer = playerMap.remove(player.getId());
        if(oldPlayer != null ){
            log.error("why find old player,something is wrong,id is {}",player.getId());
            this.removeClientChannel(oldPlayer.getClientChannel());
            log.info("find old player,user is {},channel is {},old channel is {}",player.getId(),player.getClientChannel(),oldPlayer.getClientChannel());
        }
        playerMap.put(player.getId(),player);
        var clientChannel = player.getClientChannel();
        this.channelPlayerMap.put(clientChannel,player);
        this.channelMap.put(clientChannel.getChannel(),player.getClientChannel());

        this.removeCheckTimeChannel(clientChannel.getChannel());

        Server.instance().getRedisController().insertBattlePlayer(player.getId(),player.getPlayerType(), Server.instance().getServerId());
    }

    public void checkWaitEnterRoom(int uid){
        var info = waitToEnterMap.remove(uid);
        if(info != null){
            info.doEnter();
        }
    }

    public void addWaitEnterPlayer(T player, int enterType, ClientChannel ch){
        var info = waitToEnterMap.remove(player.getId());
        if(info != null){
            var oldPlayer = info.getPlayer();
            if(oldPlayer != null && !oldPlayer.equals(player)){
                log.info("destroy battle player is {},reason is double wait enter",player.getId());
                oldPlayer.destroy();
            }
        }
        waitToEnterMap.put(player.getId(),createBattleWaitEnterInfo(player,enterType,ch));
    }
}
