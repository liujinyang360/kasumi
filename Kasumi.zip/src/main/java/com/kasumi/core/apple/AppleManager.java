package com.kasumi.core.apple;

import com.kasumi.utils.tool.HttpUtils;
import com.kasumi.utils.tool.OkHttpUtils;

public class AppleManager {
    /**
     * 获取apple 公钥集
     */
    public static final String APPLE_KEYS = "https://appleid.apple.com/auth/keys";
    /**
     * 苹果授权域名
     */
    public static final String APPLE_ISS = "https://appleid.apple.com";
    /**
     * 苹果后台配置包名
     */
    public static String APPLE_PACKET = "";
    /**
     * 苹果后台配置clientId
     */
    public static String APPLE_ID = "";

    public static void setApplePacket(String packetName) {
        APPLE_PACKET = packetName;
    }

    public static void setAppleId(String appleId) {
        APPLE_ID = appleId;
    }

    public static void doAppleBind(AppleIdCheck appleIdCheck){
        //HttpUtils.get(APPLE_KEYS,null,appleIdCheck);
        OkHttpUtils.doHttpRequest(APPLE_KEYS, null, "get", null, appleIdCheck);
    }
}
