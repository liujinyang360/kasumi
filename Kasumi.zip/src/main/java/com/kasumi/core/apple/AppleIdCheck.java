package com.kasumi.core.apple;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.kasumi.conf.CommProperties;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.modules.HttpResult;
import com.kasumi.modules.player.IGamePlayer;
import com.kasumi.utils.tool.Base64;
import com.kasumi.utils.tool.OkHttpCallback;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.jwt.JWK;
import io.vertx.ext.jwt.JWT;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public abstract class AppleIdCheck<T extends IGamePlayer> extends HttpResult {
    private T player;
    private String tokens;
    private int type;
    private static final Logger log = LoggerFactory.getLogger(AppleIdCheck.class);

    public AppleIdCheck(T player, String tokens, int type) {
        this.player = player;
        this.tokens = tokens;
        this.type = type;
    }

    public T getPlayer() {
        return player;
    }

    /**
     * 写错误信息
     *
     * @param error 错误信息
     */
    protected abstract void writeErrorInfo(int error, int type);

    /**
     * 从数据库中获取基本信息
     *
     * @param appleId appleId
     * @return 基本信息map
     */
    protected abstract Map<String, String> getSimpleInfoFromDb(String appleId);

    protected abstract void updateAppleInfo(T player, String appleId, String appleEmail);

    protected abstract void doFinished(int id, String name);

    protected abstract void writeSwitchInfo(Map<String, String> map, String appleId);

    protected abstract void writeRespInfo(Map<String, String> map, int result, int type);

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        writeErrorInfo(BaseMessageCode.Server_Error, type);
    }

    @Override
    protected void doException(Throwable ex) {
        writeErrorInfo(BaseMessageCode.Server_Error, type);
    }


    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    private void success(String body, int code) {
        if (code == 200) {
            try {
                Map<String, Object> keysMap = JSON.parseObject(body, new TypeReference<>() {});
                List<Map<String, String>> keys = (List<Map<String, String>>) keysMap.get("keys");

                String compactJws = new String(Base64.decode(tokens));
                String[] allToken = compactJws.split("\\.");

                String headerToken = Base64.repairBase64String(allToken[0]);

                String header = new String(Base64.decode(headerToken));
                HashMap headerMap = JSON.parseObject(header, HashMap.class);
                String kid = headerMap.get("kid").toString();

                Map<String, String> keyMap = null;
                for (var map : keys) {
                    if (kid.equals(map.get("kid"))) {
                        keyMap = map;
                        break;
                    }
                }

                JsonObject jwkJson = new JsonObject(JSON.toJSONString(keyMap));
                JWK jwk = new JWK(jwkJson);

                JWT jwt = new JWT();
                jwt.addJWK(jwk);
                JsonObject object = jwt.decode(compactJws);
                String sub = object.getString("sub");
                String iss = object.getString("iss");
                String aud = object.getString("aud");
                String appleEmail = object.getString("email");
                appleEmail = appleEmail == null ? "" : appleEmail;

                if (!AppleManager.APPLE_ISS.equals(iss) || (!AppleManager.APPLE_PACKET.equals(
                        aud) && !AppleManager.APPLE_ID.equals(aud))) {
                    log.info("iss or aud error first {} second {} third {}", AppleManager.APPLE_ISS.equals(iss),
                            AppleManager.APPLE_PACKET.equals(aud), AppleManager.APPLE_ID.equals(aud));
                    log.info("apple_packet {} apple_id {}", AppleManager.APPLE_PACKET, AppleManager.APPLE_ID);
                    writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
                    return;
                }

                var simpleMap = getSimpleInfoFromDb(sub);
                if (type == CommProperties.ACCOUNT_BIND) {
                    if (simpleMap.size() > 1) {
                        log.info("appleId == {} had bind, resp user message bindUserId = {}", sub,
                                simpleMap.get("user_id"));
                        writeRespInfo(simpleMap, BaseMessageCode.HadBindOtherAccount, CommProperties.ACCOUNT_BIND);
                        return;
                    }
                    player.setAppleEmail(appleEmail);
                    player.setAppleId(sub);
                    updateAppleInfo(player, sub, appleEmail);
                    doFinished(player.getId(), sub);
                    log.info("appleId == {} 已绑定过账号，返回给客户端账号信息， bindUserId = {}", sub, simpleMap.get("user_id"));
                } else {
                    if (simpleMap.size() == 0) {
                        writeErrorInfo(BaseMessageCode.AccountNotExist, type);
                    } else {
                        log.info("switch apple account, userId = {}, token = {}", simpleMap.get("user_id"),
                                simpleMap.get("token"));
                        writeSwitchInfo(simpleMap, sub);
                    }
                }
            } catch (Exception e) {
                log.info("catch error");
                writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
                e.printStackTrace();
            }
        } else {
            log.error("Apple account check fail， code : {} ", code);
            writeErrorInfo(BaseMessageCode.AccountCheckFail, type);
        }
    }

    @Override
    protected void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }
}
