package com.kasumi.io.packet;

/**
 * 协议id类,各项目从此类中继承
 * 此类中定义的id不能在子类中重复定义
 * @author Athena
 */
public class BasePacketId {
    /**中转协议*/
    public static final int TRANSFER_PACKET = 60000;
    /**future请求协议*/
    public static final int FUTURE_REQUEST_PACKET = 60001;
    /**future返回协议*/
    public static final int FUTURE_RESPONSE_PACKET = 60002;
    /** client<-->gateway<-->battle转发协议包 **/
    public static final int Gateway_TransferBetween_BattleAndClient = 60003;
    public static final int REPORT_MATCH_HEARTBEAT = 60004;
    public static final int REPORT_SP_HEARTBEAT = 60005;
    public static final int GameRequestKickOff = 60006;
}
