package com.kasumi.io;

import com.kasumi.conf.CommProperties;
import com.kasumi.io.packet.WritePacket;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;

/**
 * 一个客户端的连接
 * 项目中,同时支持tcp和udp(kcp)两种协议
 * 当客户端采用tcp进行通讯时,Channel对象不为空
 * 当客户端采用UDP(kcp)进行通讯时,Kcp对象不为空
 * 当时游戏类的连接管理统一用本类,不再进行判断处理
 * @author Athena
 */
public class ClientChannel {
    /**
     * udp连接
     */
    protected KasumiKcp kcp;
    /**
     * tcp或者websocket连接
     */
    protected Channel channel;

    protected boolean isWebsocket = false;
    /**
     * 上次收到消息的时间
     */
    private long lastReceiveTime = System.currentTimeMillis();

    private long timeOut = CommProperties.DefaultTimeOut;

    /**
     * 客户端ip
     */
    private String ip = null;

    private String remoteHost = null;

    private boolean isWifi = false;

    public ClientChannel(Channel channel,boolean isWebsocket){
        this(channel,isWebsocket, CommProperties.DefaultTimeOut);
    }

    public ClientChannel(Channel channel,boolean isWebsocket,long timeOut){
        this.channel = channel;
        this.isWebsocket = isWebsocket;
        this.timeOut = timeOut;
    }

    public ClientChannel(KasumiKcp kcp){
        this.kcp = kcp;
    }

    public void setKcp(KasumiKcp kcp){
        this.kcp = kcp;
    }

    public void setChannel(Channel channel){
        this.channel = channel;
    }


    public KasumiKcp getKcp(){
        return this.kcp;
    }

    public Channel getChannel(){
        return this.channel;
    }

    public void sendPacket(WritePacket wp){
        if(wp == null){
            return;
        }
        ByteBuf buf = wp.toBuf();
        sendPacket(buf);
    }

    public void sendPacket(ByteBuf buf){
        if(buf == null){
            return;
        }
        if(this.channel != null){
            if(this.isWebsocket){
                this.channel.writeAndFlush(new BinaryWebSocketFrame(buf));
            }else{
                this.channel.writeAndFlush(buf);
            }
        }else if(this.kcp != null){
            this.kcp.write(buf);
        }else {
            buf.release();
        }
    }

    public void close(){
        try {
            if (this.channel != null) {
                this.channel.close();
            }else if(this.kcp != null){
                this.kcp.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public boolean isClosed(){
        if(this.channel != null){
            return !this.channel.isOpen();
        }else if(this.kcp != null){
            return this.kcp.isClosed();
        }else{
            return true;
        }
    }

    public boolean isOpen() {
        return !isClosed();
    }

    public long getLastReceiveTime() {
        return lastReceiveTime;
    }

    public void setLastReceiveTime(long lastReceiveTime) {
        this.lastReceiveTime = lastReceiveTime;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public boolean isTcp() {
        return this.channel != null;
    }

    public boolean isUdp(){
        return this.kcp != null;
    }

    public boolean isWebSocket(){
        return this.isWebsocket;
    }

    public String toString() {
        if(this.channel != null){
            String type = this.isWebsocket ? "WebSocket" : "TCP";
            return "client is "+type+",channel is "+this.getChannel()+",ip is "+this.ip;
        }else if(this.kcp != null){
            return "client is KCP,channel is "+this.getKcp()+",ip is "+this.ip;
        }
        return "client is null channel";
    }

    public void setKcpTimeout(long timeout){
        if(this.kcp != null){
            this.kcp.setTimeoutMillis(timeout);
        }
    }

    public void setTcpTimeOut(long timeOut){
        this.timeOut = timeOut;
    }

    public long getTcpTimeOut() {
        return timeOut;
    }

    public String getRemoteHost() {
        return remoteHost == null ? "" : remoteHost;
    }

    public void setRemoteHost(String remoteHost) {
        this.remoteHost = remoteHost;
    }

    public boolean isWifi() {
        return isWifi;
    }

    public void setWifi(boolean wifi) {
        isWifi = wifi;
    }
}
