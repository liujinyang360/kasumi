package com.kasumi.io.server.websocket;


import com.kasumi.utils.tool.Tools;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.codec.http.*;
import io.netty.handler.codec.http.websocketx.BinaryWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.util.ReferenceCounted;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.net.SocketAddress;


public abstract class WebSocketHandler extends ChannelInboundHandlerAdapter {

    private static final String[] proxy = { "True-PipelineClient-IP","X-Forwarded-For" };

    private static final Logger log = LoggerFactory.getLogger(WebSocketHandler.class);

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (msg instanceof BinaryWebSocketFrame) {
            handleBinaryRequest(ctx, (BinaryWebSocketFrame) msg);
        } else if (msg instanceof FullHttpRequest) {
            var request = (FullHttpRequest) msg;
            var channel = ctx.channel();

            handelHttpRequest(channel,request);
            request.release();
            channel.close();
        } else {
            log.warn("not binaryWebSocketFrame type is {}", msg.getClass());
            try {
                if (msg instanceof ReferenceCounted) {
                    var fc = (ReferenceCounted) msg;
                    fc.release();
                } else {
                    log.error("is not a ReferenceCounted instance {}", msg.getClass());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            ctx.channel().close();
        }
    }

    /**
     * 处理二进制数据
     * @param ctx
     * @param frame
     */
    public abstract void handleBinaryRequest(ChannelHandlerContext ctx, BinaryWebSocketFrame frame) ;

    /**
     * 处理http request数据
     * @param channel
     * @param request
     */
    public abstract void handelHttpRequest(Channel channel,FullHttpRequest request);

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof WebSocketServerProtocolHandler.HandshakeComplete) {
            doHandshakeComplete(ctx.channel(), (WebSocketServerProtocolHandler.HandshakeComplete) evt);
        }
        super.userEventTriggered(ctx, evt);
    }


    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        var msg = cause.toString();
        if (!msg.contains("reset by peer") && !msg.contains("masked")) {
            cause.printStackTrace();
        }
    }

    /**
     *
     * 握手完成后的处理,一般用于取一些header信息
     * @param channel
     * @param hc
     */
    public abstract void doHandshakeComplete(Channel channel, WebSocketServerProtocolHandler.HandshakeComplete hc) ;

    private static String getIp(HttpHeaders headers, SocketAddress address){
        String ip = null;
        for (String s : proxy) {
            ip = headers.get(s);
            if (!isIllegalIp(ip)) {
                break;
            }
        }
        return isIllegalIp(ip) ? Tools.getIP(address) : ip.split(",")[0];
    }

    private static boolean isIllegalIp(String ip){
        return ip == null || "".equals(ip.trim()) || "unknown".equalsIgnoreCase(ip.trim());
    }
}
