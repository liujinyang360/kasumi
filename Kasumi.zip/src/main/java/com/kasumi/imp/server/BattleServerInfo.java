package com.kasumi.imp.server;

public class BattleServerInfo {
    private int id;
    private String innerHost;
    private String host;
    private int port;
    private String method = "tcp";
    private boolean shouldOpen = true;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInnerHost() {
        return innerHost;
    }

    public void setInnerHost(String innerHost) {
        this.innerHost = innerHost;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public boolean isShouldOpen() {
        return shouldOpen;
    }

    public void setShouldOpen(boolean shouldOpen) {
        this.shouldOpen = shouldOpen;
    }

    public boolean isWebsocket(){
        return "ws".equals(this.method);
    }

    public boolean isTcp (){
        return "tcp".equals(this.method);
    }
}
