package com.kasumi.imp;

import com.kasumi.conf.CommProperties;
import com.kasumi.conf.BaseMessageCode;
import com.kasumi.conf.RedisProperties;
import com.kasumi.core.purchase.OrderInfo;
import com.kasumi.core.redis.RedisController;
import com.kasumi.core.redis.RedisPool;
import redis.clients.jedis.Jedis;

public class DefaultRedisController implements RedisController {
    @Override
    public int saveOrder(OrderInfo info) {
        try(Jedis jedis = RedisPool.getJedis(RedisProperties.Redis_Db_Order)){
            String key = info.getOrderId()+"";
            jedis.set(key,info.toJson());
            jedis.expire(key,RedisProperties.Order_Expire_Time);
            return 1;
        }catch(Exception e){
            e.printStackTrace();
            return BaseMessageCode.Server_Error;
        }
    }

    @Override
    public String getOrder(long orderId) {
        try(Jedis jedis = RedisPool.getJedis(RedisProperties.Redis_Db_Order)){
            return jedis.get(orderId+"");
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void removeOrder(long orderId) {
        try(Jedis jedis = RedisPool.getJedis(RedisProperties.Redis_Db_Order)){
            jedis.del(""+orderId);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public boolean addLogin(int playerId, String loginStr) {
        Jedis jedis = null;
        long result = 0;
        try {
            String key = ""+playerId;
            jedis = RedisPool.getJedis();
            result = jedis.setnx(key, loginStr);
            if(result == 1) {
                jedis.expire(key, CommProperties.LOGIN_EXPIRE);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            RedisPool.close(jedis);
        }
        return result == 1;
    }

    @Override
    public void delLogin(int playerId) {
        try (Jedis jedis = RedisPool.getJedis()){
            jedis.del(""+ playerId);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void insertBattlePlayer(int userId, int type, int serverId) {
        try (Jedis jedis = RedisPool.getJedis()) {
            String key = RedisProperties.Battle_Player_Prefix + userId;
            jedis.setex(key, RedisProperties.Battle_Player_Expire_Time, serverId + "," + type);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int preemptSingleMatch(String tag){
        try (Jedis jedis = RedisPool.getJedis(RedisProperties.Redis_Db_System)) {
            String key = RedisProperties.MATCH_SERVER_NAME;
            String value = jedis.get(key);
            if(value == null){
                jedis.setex(key,CommProperties.Match_Expire_Time,tag);
                return 1;
            }else{
                if(value.equals(tag)){
                    jedis.expire(key, CommProperties.Match_Expire_Time);
                    return 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
        return 0;
    }

    public int preemptSingleSp(String tag){
        try (Jedis jedis = RedisPool.getJedis(RedisProperties.Redis_Db_System)) {
            String key = RedisProperties.SP_SERVER_NAME;
            String value = jedis.get(key);
            if(value == null){
                jedis.setex(key,CommProperties.Sp_Expire_Time,tag);
                return 1;
            }else{
                if(value.equals(tag)){
                    jedis.expire(key, CommProperties.Sp_Expire_Time);
                    return 1;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
        return 0;
    }

    public String getSystemValue(String key){
        try (Jedis jedis = RedisPool.getJedis(RedisProperties.Redis_Db_System)) {
            return jedis.get(key);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 玩家是否已经登录
     * @param playerId 玩家id
     * @return 登录字符串(玩家登录的服务器等信息)
     */
    public int getUserGameServerId(int playerId) {
        try (Jedis jedis = RedisPool.getJedis()){
            String loginStr = jedis.get(""+playerId);
            if(loginStr != null && !"".equals(loginStr.trim())){
                return Integer.parseInt(loginStr.split(",")[0]);
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
}
