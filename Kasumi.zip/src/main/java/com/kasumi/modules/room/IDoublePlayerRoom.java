package com.kasumi.modules.room;


import com.kasumi.modules.player.IBattlePlayer;

public interface IDoublePlayerRoom<T extends IBattlePlayer> extends IBaseRoom {
    /**
     * 获取P1
     *
     * @return T
     */
    T getPlayer1();

    /**
     * 获取P2
     *
     * @return T
     */
    T getPlayer2();

    /**
     * 获取房间中AI Player
     *
     * @return T
     */
    T getAiPlayer();

    /**
     * 获取对手Player对象
     *
     * @param userId uid
     * @return T
     */
    T getOtherPlayer(int userId);
}
