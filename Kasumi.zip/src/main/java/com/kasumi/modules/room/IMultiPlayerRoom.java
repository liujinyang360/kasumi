package com.kasumi.modules.room;


import com.kasumi.modules.player.IBattlePlayer;

public interface IMultiPlayerRoom<T extends IBattlePlayer> extends IBaseRoom {
    /**
     * 获取某个玩家
     *
     * @param userId uid
     * @return T
     */
    T getPlayer(int userId);

    /**
     * 添加房间内玩家
     *
     * @param player T
     */
    void addPlayer(T player);
}
