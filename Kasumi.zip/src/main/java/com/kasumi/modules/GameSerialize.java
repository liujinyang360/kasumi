package com.kasumi.modules;

import com.kasumi.io.packet.ReadPacket;
import com.kasumi.io.packet.WritePacket;

/**
 * 序列化和反序列化接口
 * @author Athena
 */
public interface GameSerialize {
	/**
	 *序列化接口
	 * @param writer writer对象
	 * @throws Exception Io错误
	 */
	void serialize(WritePacket writer) throws Exception;

	/**
	 *反序列化接口
	 * @param reader reader对象
	 * @throws Exception Io错误
	 */
	void unSerialize(ReadPacket reader) throws Exception;
}

