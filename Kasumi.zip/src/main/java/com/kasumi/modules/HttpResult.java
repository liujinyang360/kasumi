package com.kasumi.modules;

import com.kasumi.utils.tool.OkHttpCallback;

import java.net.http.HttpResponse;

public abstract class HttpResult implements OkHttpCallback {
    public void doResult(Throwable ex,HttpResponse<String> response) {
        if(ex != null){
            doException(ex);
        }else{
            doSuccess(response);
        }
    }

    /**
     * 出现异常时候的执行方法
     * @param ex
     */
    protected abstract void doException(Throwable ex);

    /**
     * 成功返回时候的执行方法
     * @param response
     */
    protected abstract void doSuccess(HttpResponse<String> response);
}
