package com.kasumi.modules.player;


import com.kasumi.modules.room.IBaseRoom;

public interface IBattlePlayer extends IPlayer {

    default boolean isAi(){
        return this.getAiId() > -1;
    }

    void setAiId(int id);

    int getAiId();

    IBaseRoom getRoom();

    void setRoom(IBaseRoom room);

    void setTimeOut(boolean timeout);

    void disconnect();
}
