package com.kasumi.modules.player;


import com.kasumi.io.ClientChannel;
import com.kasumi.io.packet.WritePacket;
import io.netty.buffer.ByteBuf;

public interface IPlayer {
    /**
     * 玩家Id
     * @return
     */
    int getId();

    /**
     * 销毁对象
     */
    void destroy();

    /**
     * 设置离开类型(断线,主动离开等)
     * @param type
     */
    void setLeaveType(int type);

    /**
     * 发送包
     * @param wp
     * @return
     */
    boolean writePacket (WritePacket wp);

    /**
     * 发送包,用ByteBuf对象
     * @param buf
     * @return
     */
    boolean writePacket(ByteBuf buf);

    /**
     * 设置名字
     * @param name
     */
    void setName(String name);

    /**
     * 获得名字
     * @return
     */
    String getName();

    /**
     * 设置头像
     * @param header
     */
    void setHeader(String header);

    /**
     * 获取头像
     * @return
     */
    String getHeader();

    int getOsType();

    int getPlayerType();

    void setFacebookId(String facebookId);

    void setAppleEmail(String email);

    void setAppleId(String appleId);

    String getDeviceCode();

    ClientChannel getClientChannel() ;

    void setTimeout(boolean bool);

    boolean isTimeout();

    void setClientChannel(ClientChannel channel) ;

    String getFacebookName();
}
