package com.kasumi.utils.tool;


public class Obfuscator {

    /**
     *
     * PRIME :是一个素数且与 MAXSIZE 互质，提供有函数 isProbablyPrime(prime) 验证是否互质
     * MAXSIZE :混淆的块大小，超过此大小自动补位
     * MODINVERSE : 用于反向求出原id（解码），满足（PRIME * MODINVERSE） % MAXSIZE == 1，提供ModInverse(prime,maxSize)方法，求MODINVERSE值
     *
     */
    private static long PRIME = 30487531;
    private static long MAXSIZE = 100000000;
    private static int MODINVERSE = 72626671;

    public Obfuscator() {
    /**
     * 判断PRIME和MAXSIZE是否互质，用以PRIME值的确定
     */
//        if (!isProbablyPrime(prime)) {
//            throw new IllegalArgumentException(String.format("%d is not a prime number", prime));
//        }
    /**
     * MODINVERSE值确定
     */

//        this.modInverse = (int)ModInverse(prime,maxSize);
    }

    /**
     * id混淆编码操作
     *
     * @param id 原id
     * @return 混淆后的伪装id
     */
    public static int encode(long id) {
        return (int) ((id * PRIME) % MAXSIZE + (id - (id % MAXSIZE)));
    }

    /**
     * id混淆接解码操作
     *
     * @param id 混淆后的伪装id
     * @return 原id
     */
    public static int decode(long id) {
        return (int) ((id * MODINVERSE) % MAXSIZE + (id - (id % MAXSIZE)));
    }

    /**
     * 求逆元：MODINVERSE，求出后直接定义，只是提供暴力求解方法
     *
     * @param n ->prime
     * @param modValue ->maxSize
     * @return 原id
     */
    public static long ModInverse(long n,long modValue) {
        int i;
        for (i=0;i<MAXSIZE;i++){
            if((i * n) % modValue == 1){
                break;
            }
        }
        return i;
    }

    /**
     *
     * 判断prime是否与maxSize互质算法
     * @param prime 质数
     * @return
     */
    public static boolean isProbablyPrime ( long prime)
    {
        long temp_1 = 0;
        long temp_2 = MAXSIZE;
        while (temp_2 > 0) {
            temp_1 = prime % temp_2;
            prime = temp_2;
            temp_2 = temp_1;
        }

        if (prime == 1) {
            return true;
        }
        return false;
    }

    public static long getPRIME() {
        return PRIME;
    }

    public static void setPRIME(long PRIME) {
        Obfuscator.PRIME = PRIME;
    }

    public static long getMAXSIZE() {
        return MAXSIZE;
    }

    public static void setMAXSIZE(long MAXSIZE) {
        Obfuscator.MAXSIZE = MAXSIZE;
    }

    public static int getMODINVERSE() {
        return MODINVERSE;
    }

    public static void setMODINVERSE(int MODINVERSE) {
        Obfuscator.MODINVERSE = MODINVERSE;
    }
}

