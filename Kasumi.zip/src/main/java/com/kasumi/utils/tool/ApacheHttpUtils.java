package com.kasumi.utils.tool;

import org.apache.hc.client5.http.async.methods.*;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.classic.methods.HttpPut;
import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.apache.hc.client5.http.impl.async.HttpAsyncClients;
import org.apache.hc.client5.http.impl.nio.PoolingAsyncClientConnectionManager;
import org.apache.hc.client5.http.impl.nio.PoolingAsyncClientConnectionManagerBuilder;
import org.apache.hc.core5.concurrent.FutureCallback;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpResponse;
import org.apache.hc.core5.http.nio.AsyncResponseConsumer;
import org.apache.hc.core5.http.nio.support.AsyncRequestBuilder;
import org.apache.hc.core5.reactor.IOReactorConfig;
import org.apache.hc.core5.util.TimeValue;
import org.apache.hc.core5.util.Timeout;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.Future;

/**
 * apache 的 http
 *
 * @author Crazy
 */
public class ApacheHttpUtils {
    private static final Logger log = LoggerFactory.getLogger(ApacheHttpUtils.class);

    private static final CloseableHttpAsyncClient asyncClient;
    static {
        PoolingAsyncClientConnectionManager asyncConnectionManager = PoolingAsyncClientConnectionManagerBuilder.create()
                .setDefaultConnectionConfig(ConnectionConfig.custom()
                        .setSocketTimeout(Timeout.ofMinutes(1))
                        .setConnectTimeout(Timeout.ofMinutes(1))
                        .setTimeToLive(TimeValue.ofMinutes(10))
                        .build())
                .setMaxConnTotal(256)
                .setMaxConnPerRoute(256)
                .build();

        asyncClient = HttpAsyncClients.custom()
                .setConnectionManager(asyncConnectionManager)
                .setIOReactorConfig(IOReactorConfig.custom()
                        .setSoTimeout(Timeout.ofMinutes(1))
                        .build())
                .build();

        asyncClient.start();
    }

    /**
     *
     * @param url 要访问的url地址
     * @param params 访问的参数
     * @param method 访问的方式Get或者Post
     * @param headers  访问的http头
     * @param callback 访问结束后的回调接口
     * @param <T> 参数类型,通常有string或者byte[]类型
     */
    public static <T> void doHttpRequest(String url, T params, String method, Map<String, String> headers, FutureCallback<SimpleHttpResponse> callback) {
        AsyncRequestBuilder builder = AsyncRequestBuilder.create(method.toUpperCase()).setUri(url);
        if (headers != null && !headers.isEmpty()) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                if (!"Content-Length".equalsIgnoreCase(entry.getKey())) {
                    builder.addHeader(entry.getKey(), entry.getValue());
                }
            }
        }
        if (params != null) {
            if (params instanceof byte[] bs) {
                builder.setEntity(bs, ContentType.APPLICATION_OCTET_STREAM);
            } else {
                builder.setEntity(params.toString());
            }
        }

        asyncClient.execute(builder.build(), SimpleResponseConsumer.create(), callback);
    }


    public static <T> SimpleHttpResponse doHttpRequestSync(final String url, T params, String method, Map<String, String> headers) throws Exception {
        AsyncRequestBuilder builder = AsyncRequestBuilder.create(method.toUpperCase()).setUri(url);
        if (headers != null && !headers.isEmpty()) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                if (!"Content-Length".equalsIgnoreCase(entry.getKey())) {
                    builder.addHeader(entry.getKey(), entry.getValue());
                }
            }
        }
        if (params != null) {
            if (params instanceof byte[] bs) {
                builder.setEntity(bs, ContentType.APPLICATION_OCTET_STREAM);
            } else {
                builder.setEntity(params.toString());
            }
        }


        Future<SimpleHttpResponse> future = asyncClient.execute(builder.build(), SimpleResponseConsumer.create(), new FutureCallback<>() {
            @Override
            public void completed(SimpleHttpResponse result) {
            }

            @Override
            public void failed(Exception ex) {
                ex.printStackTrace();
            }

            @Override
            public void cancelled() {
                log.error("apache http request is cancelled. url = {}", url);
            }
        });

        SimpleHttpResponse response = future.get();
        if (future.isDone()) {
            return response;
        }

        return null;
    }


    public static Future<SimpleHttpResponse> doHttpPost(String url, Map<String, String> header, String params) {
        var builder = SimpleRequestBuilder.post(url);
        header.forEach(builder::addHeader);
        builder.setBody(params, ContentType.APPLICATION_JSON);
        SimpleHttpRequest httpPost = builder.build();
        return asyncClient.execute(httpPost, null);
    }

}



































