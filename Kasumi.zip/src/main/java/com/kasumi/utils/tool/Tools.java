package com.kasumi.utils.tool;

import com.kasumi.conf.CommConstants;

import javax.net.ssl.SSLParameters;
import java.io.*;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author
 */

public class Tools {

	/**
	 * 连接超时
	 */
	public static int connectTimeOut = 50 * Time.SECOND_TIME;
	private static final String[] rndNames = new String[] {"0","1","2","3","4","5","6","7","8","9"};
	private static final int namePostfixLength = 8;
	public static SSLParameters sslParameters = new SSLParameters();

	private static final String Number_Reg = "^[\\+\\-]?[\\d]+(\\.[\\d]+)?$";

	static {
		sslParameters.setProtocols(new String[]{"TLSv1", "TLSv1.1", "TLSv1.2"});
	}


	public static boolean isInteger(String str) {
		if (str == null){
			return false;
		}
		String format = "^[0-9]+$";
		Pattern p = Pattern.compile(format, Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(str);
		return m.matches();
	}

	public static boolean isNumber(String str){
		return str.matches(Number_Reg);
	}

	public static String input2String(InputStream in) {
		try {
			byte[] bytes = new byte[in.available()];
			in.read(bytes,0,bytes.length);
			return new String(bytes,"utf-8");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String InputStr2Str_Reader(InputStream in, String encode) {

		String str = "";
		try {
			if (encode == null || encode.equals("")) {
				// 默认以utf-8形式
				encode = "utf-8";
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(in, encode));
			StringBuffer sb = new StringBuffer();

			while ((str = reader.readLine()) != null) {
//                System.out.println(str);
				sb.append(str).append("\n");
			}
			return sb.toString();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return str;
	}


	public static String InputStr2Str_byteArr(InputStream in, String encode) {
		StringBuffer sb = new StringBuffer();
		byte[] b = new byte[1024];
		int len = 0;
		try {
			if (encode == null || encode.equals("")) {
				// 默认以utf-8形式
				encode = "utf-8";
			}
			while ((len = in.read(b)) != -1) {
				sb.append(new String(b, 0, len, encode));
			}
			return sb.toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void printStackTrace () {
		Throwable ex = new Throwable();
		StackTraceElement[] stackElements = ex.getStackTrace();
		if (stackElements != null) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < stackElements.length; i++) {
				if(i == 0){
					sb.append(Time.getTimeStr(System.currentTimeMillis(),"yy-MM-dd HH:mm:ss")).append("\t");
				}else{
					sb.append("\t\t\t\t\t");
				}
				sb.append(stackElements[i].getClassName()+"\t");
				sb.append(stackElements[i].getFileName()+"\t");
				sb.append(stackElements[i].getLineNumber()+"\t");
				sb.append(stackElements[i].getMethodName());
				if(i != stackElements.length - 1){
					sb.append("\n");
				}
			}
			System.err.println(sb.toString());
		}
	}

	public static String getIP(SocketAddress address){
		if(address == null){
			return "";
		}
		String ip = address.toString();
		int begin = ip.indexOf("/");
		int end = ip.indexOf(":");
		if(begin != -1 && end != -1){
			return ip.substring(begin+1,end);
		}
		return "";
	}


	public static String getClassResources() {
		String path = (String.valueOf(Thread.currentThread().getContextClassLoader().getResource(""))).replaceAll("file:/", "").replaceAll("%20", " ").trim();

		//lib打到同一个jar包，path="jar:D/.."
		path = path.replace("jar:","");

		if (path.indexOf(":") != 1) {
			path = File.separator + path;
		}
		return path;
	}

	public static String getRootPath() {
//		String path = getClassResources();
//		String[] paths = path.split("/target");
//		String rootPath = paths[0];
//		int index = rootPath.lastIndexOf("/");
//		return rootPath.substring(0,index);
//		return rootPath.substring(0,index);

		String path = getClassResources();
		String splitStr = "/target";
		if(path.indexOf("/target") == -1) {
			splitStr = ".jar!/";
		}

		String[] paths = path.split(splitStr);
		String rootPath = paths[0];
		int index = rootPath.lastIndexOf("/");
		return rootPath.substring(0,index);
	}

	public static InputStream getInputStreamByFilePath(String path) throws Exception{
		return new FileInputStream(new File(getRootPath()+"/"+path));
	}

	public static boolean isPathExist(String path) {

		File file = new File(getRootPath() + "/" +path);
		return file.exists();
	}

	public static String get32UUID() {
		String uuid = UUID.randomUUID().toString().trim().replaceAll("-", "");
		return uuid;
	}

	/**
	 * 把由外层,内层两个分隔符的字符串转换为int[] 的List
	 * 如: 1,2,3;4,5,6;7,8,9
	 * 其中 ";" 为外层分隔符 ","为内层分隔符
	 * @param str
	 * @param targ1 外层分隔符
	 * @param targ2 内层分隔符
	 * @return 转换成的int[] List
	 */
	public static ArrayList<int[]> parseIntList(String str, String targ1, String targ2){
		if(str == null || str.trim().equals("")){
			return null;
		}
		ArrayList<int[]> list = new ArrayList<>();
		String[] tmp = str.split(targ1);
		for(int i = 0;i<tmp.length;i++){
			if(tmp[i].trim().length() < 1) {
				continue;
			}
			String[] tmp2 = tmp[i].split(targ2);
			int[] in = new int[tmp2.length];
			for(int j = 0;j<in.length;j++){
				in[j] = Integer.parseInt(tmp2[j]);
			}
			list.add(in);
		}
		return list;
	}

	/**
	 * @param str
	 * @param targ1 外层分隔符
	 * @return 转换成的int[]
	 */
	public static int[] parseIntArray(String str, String targ1){
		if(str == null || str.trim().equals("")){
			return null;
		}
		String[] tmp = str.split(targ1);
		int[] array = new int[tmp.length];
		for(int i = 0;i<tmp.length;i++){
			array[i] = Integer.parseInt(tmp[i]);
		}
		return array;
	}

	public static String intArrayToString(int[] arr, String targ) {
		if (arr.length == 0) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < arr.length; i++) {
			sb.append(arr[i]);
			if (i != arr.length - 1) {
				sb.append(targ);
			}
		}
		return sb.toString();
	}

	public static String intArrayToString(ArrayList<int[]> list,String tag1,String tag2){
		if(list == null || list.isEmpty()){
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for(int i = 0;i<list.size();i++){
			int[] in = list.get(i);
			for(int j = 0; j< in.length;j++){
				sb.append(in[j]);
				if(j != in.length - 1){
					sb.append(tag1);
				}
			}
			if(i != list.size() - 1){
				sb.append(tag2);
			}
		}
		return sb.toString();
	}

	public static byte[] writeInt(int v) {
		byte[] writeBuf = new byte[4];
		writeBuf[0] = (byte) ((v >>> 24) & 0xFF);
		writeBuf[1] = (byte) ((v >>> 16) & 0xFF);
		writeBuf[2] = (byte) ((v >>> 8) & 0xFF);
		writeBuf[3] = (byte) ((v) & 0xFF);
		return writeBuf;
	}

	private final static double EARTH_RADIUS = 6378.137;

	private static double rad(double d) {
		return d * Math.PI / 180.0;
	}

	/**
	 * 根据两点经纬度坐标计算直线距离
	 * <p>
	 * S = 2arcsin√sin²(a/2)+cos(lat1)*cos(lat2)*sin²(b/2)￣*6378.137
	 * <p>
	 * 1. lng1 lat1 表示A点经纬度，lng2 lat2 表示B点经纬度；<br>
	 * 2. a=lat1 – lat2 为两点纬度之差  b=lng1 -lng2 为两点经度之差；<br>
	 * 3. 6378.137为地球赤道半径，单位为千米；
	 *
	 * @param lng1 点1经度
	 * @param lat1 点1纬度
	 * @param lng2 点2经度
	 * @param lat2 点2纬度
	 * @return 距离，单位米(M)
	 * @see <a href="https://zh.wikipedia.org/wiki/%E5%8D%8A%E6%AD%A3%E7%9F%A2%E5%85%AC%E5%BC%8F">半正矢(Haversine)公式</a>
	 */
	public static double getDistance(double lat1, double lng1, double lat2, double lng2) {
		if (lat1 == -1 || lng1 == -1 || lat2 == -1 || lng2 == -1) {
			return -1;
		}
		double radLat1 = rad(lat1);
		double radLat2 = rad(lat2);
		double a = radLat1 - radLat2;
		double b = rad(lng1 - lng2);
		double s = 2 * Math.asin(Math.sqrt(
				Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
		return Math.round(s * EARTH_RADIUS * 1000);
	}

	public static void checkOrCreateFileDirector(String filePath) throws Exception{
		if(filePath == null || "".equals(filePath.trim())){
			throw new Exception("file path is empty");
		}
		File dir = new File(filePath);
		if(!dir.exists() || !dir.isDirectory()){
			dir.mkdirs();
		}
	}

	public static <K, T extends BinarySearchUnit<K>> T binarySearch(List<T> list, K key) {
		if(list == null || list.isEmpty()){
			return null;
		}

		int low = 0;
		int high = list.size() - 1;

		while (low <= high) {
			int mid = (low + high) / 2;
			T t = list.get(mid);
			if (t.isMatch(key)) {
				return t;
			} else if (t.leftMove(key)) {
				high = mid - 1;
			} else {
				low = mid + 1;
			}
		}
		return null;
	}

	public static String getServerGroupName(int serverType) {
		return switch (serverType) {
			case CommConstants.SERVER_TYPE_GAME -> "game";
			case CommConstants.SERVER_TYPE_BATTLE -> "battle";
			case CommConstants.SERVER_TYPE_MATCH -> "match";
			case CommConstants.SERVER_TYPE_GM -> "gm";
			case CommConstants.SERVER_TYPE_SP -> "sp";
			case CommConstants.SERVER_TYPE_GATEWAY -> "gateway";
			default -> "";
		};
	}

	public static String getServerTag(int serverType, int id){
		return getServerGroupName(serverType) + id;
	}
}
