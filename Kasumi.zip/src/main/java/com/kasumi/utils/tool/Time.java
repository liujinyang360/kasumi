package com.kasumi.utils.tool;


import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.WeekFields;
import java.util.*;

/**
 * 时间,日期
 *
 * @author Athena
 *
 */
public class Time {

	/**一整天的毫秒数*/
	public static final long FullDayMillis = 1000*60*60*24L;
	/**一小时的毫秒数*/
	public static final long OneHourMillis = 1000*60*60L;
	/**一分钟的毫秒数*/
	public static final long OneMinuteMillis = 1000*60L;
	/**一周的毫秒数*/
	public static final long OneWeekMillis = FullDayMillis * 7;
	/**一周的毫秒数*/
	public static final long OneMonthMillis = FullDayMillis * 30;
	/**半小时的毫秒数*/
	public static final long HalfHourMillis = OneHourMillis/2;
	/** 一秒钟 */
	public static final int SECOND_TIME = 1000;
	/** 一天的秒数*/
	public static final int DaySecond = 60 * 60 * 24;
	private static final Integer[] ALL_ZONE_ID = {-12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

	public static long getCurrentMillis() {
		return System.currentTimeMillis();
	}

	public static int getCurrentSeconds() {
		return (int)(System.currentTimeMillis() / 1000);
	}

	public static int getDay(LocalDateTime ld) {
		return ld.getYear()*10000+ld.getMonthValue()*100+ld.getDayOfMonth();
	}

	public static int getMin(LocalDateTime ld) {
		return (ld.getYear() % 100) *100000000+ld.getMonthValue()*1000000+ld.getDayOfMonth() *10000 + ld.getHour() * 100 + ld.getMinute();
	}

	public static String getTimeStr(long time){
		Date date= new Date(time);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(date);
	}


	public static String getTimeStr(long time,String formatStr){
		Date date= new Date(time);
		SimpleDateFormat format = new SimpleDateFormat(formatStr);
		return format.format(date);
	}



    public static String getUTCString(int timeDiff) {
        return "UTC" + (timeDiff >= 0 ? "+" : "") + timeDiff;
    }

    public static int getWeekValue(LocalDateTime ldt, int startDay) {
        WeekFields weekFields = WeekFields.of(DayOfWeek.MONDAY, 1);
        DayOfWeek curWeekDay = ldt.getDayOfWeek();
        LocalDateTime startLdt = ldt;
        if (curWeekDay.getValue() != startDay) {
            int curDay = curWeekDay.getValue();
            int plus;
            if (curDay > startDay) {
                plus = startDay - curDay;
            } else {
                plus = startDay - curDay - 7;
            }
            startLdt = ldt.plusDays(plus);
        }
        return startLdt.getYear() * 100 + startLdt.get(weekFields.weekOfYear());
    }

	public static LocalDateTime getLocalDateTime(int utcHour, int daySecond) {
		LocalDateTime ldt = LocalDateTime.now(ZoneId.of(getUTCString(utcHour)));
		return ldt.minusSeconds(daySecond);
	}

	/**
	 * 获取当月总天数
	 * @return
	 */
	public static int getDaysOfMonth() {
		var ldt = LocalDateTime.now();
		var firstLdt = ldt.with(TemporalAdjusters.firstDayOfMonth());
		var lastLdt = ldt.with(TemporalAdjusters.lastDayOfMonth());
		return lastLdt.getDayOfMonth() - firstLdt.getDayOfMonth() + 1;
	}

	/**
	 * 获取当天0点时间戳
	 * @return
	 */
	public static int getZeroTimestamp(int timeDiff) {
		int curTime = getCurrentSeconds();
		LocalDateTime lastDt = LocalDateTime.ofEpochSecond(curTime, 0, ZoneOffset.ofHours(timeDiff));
		lastDt = LocalDateTime.of(lastDt.toLocalDate(), LocalTime.MIN);
		String zoneStr;
		if (timeDiff >= 0) {
			zoneStr = "+" + timeDiff;
		} else {
			zoneStr = "" + timeDiff;
		}
		return (int) (lastDt.toInstant(ZoneOffset.of(zoneStr)).toEpochMilli()/1000);
	}

	/**
	 * 获取当地时间为hourTime的时区
	 *
	 * @return zoneID
	 */
	public static int getTargetClockZoneId(int hourTime) {
		int localZoneId = (int) (TimeZone.getDefault().getRawOffset() / Time.OneHourMillis);
		SimpleDateFormat sdf = new SimpleDateFormat("HH");
		int localHourTime = Integer.parseInt(sdf.format(new Date(System.currentTimeMillis())));
		int min = -12;
		int max = 12;
		int zoneId = localZoneId - (localHourTime - hourTime);

		if (zoneId > max) {
			zoneId = min + (zoneId - max);
		}
		if (zoneId < min) {
			zoneId = max - (min - zoneId);
		}
		return zoneId;
	}

	/**
	 * 获取当地时间不在0-8点之间的时区
	 *
	 * @return zoneIds
	 */

	public static List<Integer> getTargetZones() {
		ArrayList<Integer> arrays = new ArrayList<Integer>(Arrays.asList(ALL_ZONE_ID));
		int zoneId = getTargetClockZoneId(0);
		List<Integer> noZoneList = new ArrayList<>(8);
		noZoneList.add(zoneId);
		for (int i = 0; i <= 7; i++) {
			if (zoneId == 12) {
				noZoneList.add(zoneId);
				zoneId = -12;
				continue;
			}
			noZoneList.add(zoneId);
			zoneId++;
		}
		arrays.removeAll(noZoneList);
		return arrays;
	}

	/**
	 * 当前时间据下一个整点的毫秒数
	 *
	 * @return 毫秒时间数
	 */
	public static long getDeductTime() {
		long time = System.currentTimeMillis();
		return OneHourMillis - (time % OneHourMillis);
	}

	public static long getMinuteDeductTime(){
		long time = System.currentTimeMillis();
		return OneMinuteMillis - (time % OneMinuteMillis);
	}

	/**
	 * 相差天数，同一天数值为0
	 * @param startTime
	 * @param endTime
	 * @param timeDiff
	 * @return
	 */
	public static int getDiffTime(int startTime,int endTime,int timeDiff){
		LocalDateTime startDt = LocalDateTime.ofEpochSecond(startTime, 0, ZoneOffset.ofHours(timeDiff));
		LocalDateTime endDt = LocalDateTime.ofEpochSecond(endTime, 0, ZoneOffset.ofHours(timeDiff));
		if(startDt.isAfter(endDt)){
			var tmp = endDt;
			endDt = startDt;
			startDt = tmp;
		}

		return  (int) (endDt.toLocalDate().toEpochDay() - startDt.toLocalDate().toEpochDay());
	}


	public static long nextTimeMills(int utcHour,int startDay,int hour,int minute,int second){
		LocalDateTime ldt = LocalDateTime.now(ZoneId.of(Time.getUTCString(utcHour)));

		LocalDateTime newLdt = LocalDateTime.of(ldt.getYear(),ldt.getMonth(),ldt.getDayOfMonth(),hour,minute,second);
		int plusDay = 0;
		int weekValue = newLdt.getDayOfWeek().getValue();
		if(weekValue > startDay){
			plusDay = 7 - weekValue + startDay;
		}else if(weekValue == startDay){
			//如果当前时间比指定时间晚
			if(newLdt.isBefore(ldt)){
				plusDay = 7;
			}
		}else{
			plusDay = startDay - weekValue;
		}

		LocalDateTime targetLdt = newLdt.plusDays(plusDay);
		long time = Time.getMillis(targetLdt,utcHour);
		return time;
	}

	/**
	 * 获得某个时间的毫秒数
	 * @param ldt
	 * @return
	 */
	public static long getMillis(LocalDateTime ldt,int utcHour) {
		return ldt.toInstant(ZoneOffset.ofHours(utcHour)).toEpochMilli();
	}

	/**
	 * 获取某个时区当日某个时间点（小时，分钟，秒）的时间戳
	 * @param utcHour
	 * @param startHour
	 * @param startMinute
	 * @param startSecond
	 * @return
	 */
	public static int getCurDayTimeStampByUtcHour(int utcHour,int startHour,int startMinute,int startSecond) {
		LocalDateTime ldt = LocalDateTime.now(ZoneId.of(getUTCString(utcHour)));
		LocalDateTime newLdt = LocalDateTime.of(ldt.getYear(),ldt.getMonth(),ldt.getDayOfMonth(),startHour,startMinute,startSecond);
		int newTime = (int)newLdt.toEpochSecond(ZoneOffset.ofHours(utcHour));
		return newTime;
	}

	public static int getDaysFromTimestamp(int createTime) {
		int days = (getCurrentSeconds() - createTime) / DaySecond;
		return days + 1;
	}

	public static int getMonthDays(int year, int month) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR,year);
		cal.set(Calendar.MONTH,month - 1);
		return  cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	}
}
