package com.kasumi.utils.tool;


import com.kasumi.conf.CommConstants;
import com.kasumi.utils.concurrent.RunWrapper;
import com.kasumi.utils.concurrent.SupplierWrapper;
import com.kasumi.utils.concurrent.ThreadCachedPoolManager;
import com.kasumi.utils.concurrent.ThreadFixedPoolManager;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedTransferQueue;
import java.util.function.Supplier;

/**
 * 线程池
 * @author Athena
 */
public class ThreadPool {

    /**主工作线程池,主要处理异步操作*/
	public static ThreadCachedPoolManager WorkerPool = new ThreadCachedPoolManager("worker-process-thread", CommConstants.Worker_Thread_Number, CommConstants.Worker_Thread_Number , 30L, new LinkedTransferQueue<Runnable>(), 3);
    /**定时器线程池,主要处理定时操作*/
    public static ThreadFixedPoolManager SchedulePool = new ThreadFixedPoolManager(CommConstants.Schedule_Thread_Number, "schedule-thread");
    /**邮件发送线程池,因邮件发送耗时
     * 所以定义线程池数量较小
     * 以免阻塞其他任务
     * */

    /**
     * runnable回调方法
     * @param run
     * @return 执行完的future
     */
    public static CompletableFuture<Void> runAsync(Runnable run){
        return CompletableFuture.runAsync(new RunWrapper(run,true) , WorkerPool.getExecutor());
    }

    /**
     * 带返回参数的回调方法
     * @param <T>
     * @param supplier
     * @return 执行完的future
     */
    public static <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier){
        return CompletableFuture.supplyAsync(new SupplierWrapper<>(supplier) , WorkerPool.getExecutor());
    }

    public static CompletableFuture<Void> runAsync(Runnable run, Executor executor) {
        return CompletableFuture.runAsync(new RunWrapper(run,true) , executor);
    }

}
