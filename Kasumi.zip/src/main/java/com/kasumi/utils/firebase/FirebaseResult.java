package com.kasumi.utils.firebase;


import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;


public class FirebaseResult implements Callback {
    private FirebaseGroup group;
    private FirebaseUnit firebaseUnit ;

    public FirebaseResult(FirebaseGroup group,FirebaseUnit unit){
        this.group = group;
        this.firebaseUnit = unit;
    }

    @Override
    public void onFailure(@NotNull Call call, @NotNull IOException e) {
        this.group.failed();
        e.printStackTrace();
    }

    @Override
    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        try {
            switch (response.code()) {
                case 200:
                    this.group.success();
                    break;
                case 400:
                case 404:
                case 401:
                    this.group.addErrorToken(this.firebaseUnit.token());
                    this.group.failed();
                    break;
                default:
                    this.group.failed();
                    break;
            }
        }finally {
            response.close();
        }
    }

    public FirebaseUnit getFirebaseUnit() {
        return firebaseUnit;
    }
}
