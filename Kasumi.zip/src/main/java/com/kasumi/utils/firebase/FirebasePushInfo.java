package com.kasumi.utils.firebase;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kasumi.utils.tool.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Athena
 * firebase推送详情,用以统计和处理推送完成后的事情
 */


public abstract class FirebasePushInfo {

    private static final Logger log = LoggerFactory.getLogger(FirebasePushInfo.class);

    private int beginTime;
    private int endTime;
    private int totalCount;
    private int successCount;
    private int failureCount;
    private int errorCount;
    private int costTime;
    private int totalPushRound;
    private int failureRequestCount ;
    private boolean doGc;
    private String taskName;

    private LinkedBlockingQueue<FirebaseUnit> unitQueue = new LinkedBlockingQueue<>();

    private ConcurrentHashMap<Integer,FirebaseGroup> groupMap = new ConcurrentHashMap<>();

    @JsonIgnore
    protected ArrayList<String> errorTokenList = new ArrayList<>();

    @JsonIgnore
    private AtomicInteger counter = new AtomicInteger(0);

    public FirebasePushInfo() {
    }

    public void init(int batchSize){
        int id = 0;
        int count = 0;
        FirebaseGroup group = null;
        while(!unitQueue.isEmpty()){
            var unit = unitQueue.poll();
            if(count % batchSize == 0){
                group = new FirebaseGroup(id ++,this);
                this.groupMap.put(group.getId(),group);
            }
            group.addUnit(unit);
            count ++;
        }
        this.beginTime = Time.getCurrentSeconds();
    }

    public FirebasePushInfo(String taskName, boolean doGc){
        this.taskName = taskName;
        this.doGc = doGc;
    }


    public void groupFinished(int groupId){
        this.groupMap.remove(groupId);
        if(this.groupMap.size() == 0){
            try {
                doComplete();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    /**
     * 推送完成后的处理,一般要删除无效的token
     * @throws Exception 可能出现exception.不要影响后续程序
     */
    public abstract void afterPushComplete() throws Exception;

    public void addUnit(FirebaseUnit unit){
        this.unitQueue.add(unit);
        this.totalCount ++;
    }

    @JsonIgnore
    private int addAndGetPushSize(){
        int count = counter.addAndGet(1);
        return count;
    }

    public void doComplete() throws Exception{
        this.endTime = Time.getCurrentSeconds();
        this.costTime = endTime - beginTime;
        this.errorCount = this.errorTokenList.size();

        log.info("Firebase 推送整个组, 一共 = {} 条,开始时间 = {} 秒,结束时间 = {} 秒,耗时 = {} 秒,成功 = {} 条,失败 = {} 条,过期 = {} 条 ",
              totalCount,  beginTime , endTime , costTime , successCount , failureCount - errorCount,errorCount);
        afterPushComplete();
        if(doGc) {
            System.gc();
        }
    }

    public synchronized void addSuccessCount(){
        this.successCount ++;
        this.addAndGetPushSize();
    }

    public synchronized void addFailureCount(){
        this.failureCount ++;
        this.addAndGetPushSize();
    }

    public synchronized void addErrorToken(String token){
        this.errorTokenList.add(token);
    }

    public synchronized void addFailureRequestCount(){
        this.failureRequestCount ++;
    }

    public int getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(int beginTime) {
        this.beginTime = beginTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(int successCount) {
        this.successCount = successCount;
    }

    public int getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(int failureCount) {
        this.failureCount = failureCount;
    }

    public int getErrorCount() {
        return errorCount;
    }

    public void setErrorCount(int errorCount) {
        this.errorCount = errorCount;
    }

    public int getCostTime() {
        return costTime;
    }

    public void setCostTime(int costTime) {
        this.costTime = costTime;
    }

    public int getTotalPushRound() {
        return totalPushRound;
    }

    public void setTotalPushRound(int totalPushRound) {
        this.totalPushRound = totalPushRound;
    }

    public int getFailureRequestCount() {
        return failureRequestCount;
    }

    public void setFailureRequestCount(int failureRequestCount) {
        this.failureRequestCount = failureRequestCount;
    }

    public boolean isDoGc() {
        return doGc;
    }

    public void setDoGc(boolean doGc) {
        this.doGc = doGc;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public AtomicInteger getCounter() {
        return counter;
    }

    public void setCounter(AtomicInteger counter) {
        this.counter = counter;
    }

    public ConcurrentHashMap<Integer, FirebaseGroup> getGroupMap() {
        return groupMap;
    }

    public LinkedBlockingQueue<FirebaseUnit> getUnitQueue() {
        return unitQueue;
    }
}
