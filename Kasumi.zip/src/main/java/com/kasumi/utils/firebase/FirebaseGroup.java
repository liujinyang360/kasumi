package com.kasumi.utils.firebase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.LinkedBlockingQueue;

public class FirebaseGroup {

    private static final Logger log = LoggerFactory.getLogger(FirebaseGroup.class);

    private LinkedBlockingQueue<FirebaseUnit> unitQueue = new LinkedBlockingQueue<>();
    private int totalSize;
    private int finishSize;
    private FirebasePushInfo pushInfo;

    private boolean isReady = false;
    private int id;

    public FirebaseGroup(int id,FirebasePushInfo info){
        this.id = id;
        this.pushInfo = info;
    }

    public synchronized void readyToPush(){
        if(!isReady) {
            this.totalSize = unitQueue.size();
            isReady = true;
        }
    }

    public LinkedBlockingQueue<FirebaseUnit> getUnitQueue() {
        return unitQueue;
    }

    public void addUnit(FirebaseUnit unit){
        this.unitQueue.add(unit);
    }

    private synchronized void finishOne(){
        this.finishSize ++;
        if(this.finishSize == totalSize){
            log.info("firebase success group id = {} , totalSize = {} ", this.id, totalSize);
            this.pushInfo.groupFinished(this.id);
        }
    }

    public synchronized void success(){
        this.pushInfo.addSuccessCount();
        finishOne();
    }

    public synchronized void failed(){
        this.pushInfo.addFailureCount();
        finishOne();
    }

    public void addErrorToken(String token){
        this.pushInfo.addErrorToken(token);
    }

    public boolean isReady(){
        return isReady;
    }

    public int getId() {
        return id;
    }
}
