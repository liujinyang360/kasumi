package com.kasumi.utils.firebase;


import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.gson.JsonObject;
import com.kasumi.conf.CommConstants;
import com.kasumi.core.purchase.GoogleToken;
import com.kasumi.utils.tool.*;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;


public class FirebaseManager {

    public static String FIREBASE_API_URL = "https://fcm.googleapis.com/v1/projects/%s%/messages:send";
    private static GoogleToken googleToken = null;
    private static int MaxBatchSize = 1000;
    private static int TokenAdvancedTime = 60 * 5;

    private static int GroupPushInterval = 300;

    private static String authFilePath;
    private static OkHttpClient[] okHttpClientArr;
    static {
        initOkHttpClient();
    }

    public static void init(String authFile, String projectId) {
        authFilePath = authFile;
        FIREBASE_API_URL = FIREBASE_API_URL.replace("%s%", projectId);
    }

    @Deprecated
    public synchronized static String getAccessToken() {
        int now = Time.getCurrentSeconds();
        try {
            if (googleToken == null || now > (googleToken.gainTime + googleToken.expireTime - TokenAdvancedTime)) {
                var credentials = GoogleCredential
                        .fromStream(Tools.getInputStreamByFilePath(authFilePath))
                        .createScoped(List.of("https://www.googleapis.com/auth/firebase.messaging"));
                credentials.refreshToken();

                googleToken = new GoogleToken();
                googleToken.tokens = new ArrayList<>();
                googleToken.gainTime = now;
                googleToken.expireTime = credentials.getExpiresInSeconds().intValue();

                googleToken.tokens.add(credentials.getAccessToken());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (googleToken == null || googleToken.tokens == null || googleToken.tokens.isEmpty()) {
            return null;
        }
        return googleToken.tokens.get(0);
    }

    public static String getAuthToken() {
        try {
            var credentials = GoogleCredential
                    .fromStream(Tools.getInputStreamByFilePath(authFilePath))
                    .createScoped(List.of("https://www.googleapis.com/auth/firebase.messaging"));
            credentials.refreshToken();

            return credentials.getAccessToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void pushSingle(FirebaseUnit uint) {
        OkHttpUtils.doFirebaseRequest(uint,getAccessToken2());
    }

    public static void pushBatch(FirebasePushInfo info) {

        var totalCount = info.getUnitQueue().size();
        if (totalCount == 0) {
            return;
        }
        info.init(MaxBatchSize);
        info.setTotalCount(totalCount);
        String accessToken = getAuthToken();

        int pushInterval = 0;
        for (var group : info.getGroupMap().values()) {
            ThreadPool.SchedulePool.schedule(() -> groupPush(group,accessToken), pushInterval);
            pushInterval += GroupPushInterval;
        }
    }

    public static void firebasePush(FirebasePushInfo info) {
        if (info.getTotalCount() == 0) {
            return;
        }
        info.init(MaxBatchSize);

        int pushInterval = 0;
        for (var group : info.getGroupMap().values()) {
            ThreadPool.SchedulePool.schedule(() -> groupPush(group), pushInterval);
            pushInterval += GroupPushInterval;
        }
    }


    private static void groupPush(FirebaseGroup group,String accessToken) {
        if (!group.isReady()) {
            group.readyToPush();
        }
        var client = okHttpClientArr[group.getId() % okHttpClientArr.length];
        var queue = group.getUnitQueue();
        while (!queue.isEmpty()) {
            var unit = queue.poll();
            if (unit != null) {
                FirebaseResult result = new FirebaseResult(group, unit);
                doFirebaseRequest(result,accessToken, client);
            }
        }
    }

    public static void doFirebaseRequest(FirebaseResult result,String authToken, OkHttpClient okHttpClient) {
        var unit = result.getFirebaseUnit();
        var message = OkHttpUtils.createFirebaseMessage(unit);
        // 构建 HTTP 请求
        RequestBody requestBody = RequestBody.create(
                message.toString(),
                MediaType.parse("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
                .url(FirebaseManager.FIREBASE_API_URL)
                .post(requestBody)
                .addHeader("Authorization", "Bearer " + authToken)
                .addHeader("Content-Type", "application/json")
                .build();

        okHttpClient.newCall(request).enqueue(result);
    }



    @Deprecated
    private static void groupPush(FirebaseGroup group) {
        if (!group.isReady()) {
            group.readyToPush();
        }
        var queue = group.getUnitQueue();
        while (!queue.isEmpty()) {
            var unit = queue.poll();
            if (unit != null) {
                FirebaseResult result = new FirebaseResult(group, unit);
                OkHttpUtils.doFirebaseRequest(result);
            }
        }
    }


    public static int getMaxBatchSize() {
        return MaxBatchSize;
    }

    public static void setMaxBatchSize(int maxBatchSize) {
        MaxBatchSize = maxBatchSize;
    }

    public static int getTokenAdvancedTime() {
        return TokenAdvancedTime;
    }

    public static void setTokenAdvancedTime(int tokenAdvancedTime) {
        TokenAdvancedTime = tokenAdvancedTime;
    }

    public static void setAuthFilePath(String authFilePath) {
        FirebaseManager.authFilePath = authFilePath;
    }

    public static String getAccessToken2() {

        String SERVICE_ACCOUNT_JSON = """
                {
                  "type": "service_account",
                  "project_id": "merge2d",
                  "private_key_id": "b7e356664ffac74af4399f606930e9cb4b5024e0",
                  "private_key": "-----BEGIN PRIVATE KEY-----\\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDn6GZ98PbORDxW\\nZq5CxcyxRCz0nZikOn3H+yQXuQzHtA6RvkBkQ5WKTHoBtf+o821QAj1LevdANlCG\\nIcqA+hEcRu2fYJbKGouevVXP58JIAr1fdXmvV+qEwQaWCr4Rrbp8BvA7osPRXeQu\\n2ncthOoHp1odlR8OQqI4D8UeOG8RhtTA1dAzi9BFCjObkT0rfVa2OdvibjKROH3J\\neNFgK9ofb4QbdxdSOoqWM7S420orJIplJeyLKWF3Nn9jQ2dR755cAleDVvcjLkHg\\nBKJvfhDO3+GL0osQYnblQClcTYMyPqWH/Is7lXBGWCqU3fmF4CBhFkOOM8AwFU4u\\n5jGSzdT1AgMBAAECggEAAYz4DU1gY/86CBeganIBQ7yf3rVxt2edB6T95mcoE8Nk\\nPSsnrlzGvZMBSPs/QidRpKdJzPZp5gPNlJIXzn0POdVTIcKgZdYpntp6MefOHcmU\\nw7RE9xsfp3v0EjnI54UQfos1kxpNQ88U68Rra/LVVqLiPRb4FAcVDT0jNEbGypbp\\nyZ3Y8N0lLTljWuwIMym9+P5WNuIYcsWSRBGp0wI+APx56QCpWjPNAGsXGA/Mqb+w\\n+V6Y/JnZ1yLTGRkg4fOa8VTMAua2YHVLmpxPSbSko/Y64t2jSf9FOvfCsJhxQeth\\nqiZcG8KPcWr7GfXXUCtlhPVoCbNiAgaWF8I9qp9xYQKBgQD7o15BmwMTD2GoA/KI\\nkauCehplPfj2A+DPimNS1R7AMrTGTct63HZGMUT9r9bSzCEjcVyNEiNCXxkFhqZo\\nJALfPPOioS1t3+l+doCF2ZRjeMzgWDW8BpRZXYW8OBRH7InVqfoPmimo1ZUl822E\\n9mmAyEg6gZe9d1xViUFIQRCdFQKBgQDr7XrRKlwGbNdj2kDENafE0+lVupoZNfWx\\nAToCCS6GBaZPX8f1YFbZfGHeRfsxx4G6dzO2rDCYTPFwii0OOIXV0NpXsMYBqrhm\\ns8NqDpfDopuh1mU5vBvUmWe+AnrgmjyQ99sUqHA8/ujrJvCHnF6GsT+CwSePVmh+\\n5OoGcS0QYQKBgQDncwkEAMbgJhqlhhPzB0EgPpy+mDTAWyrQ2bGng3zIPRtG9lD9\\nDX//6dtSFwTZWIX2apM88fzaVEvYaFPwn4bAu/g/kk4NrJDAD9EAy/KPV5Hhm2C5\\nM7gJRlr2lwIYcXkJvFDTPvGoZ+LKSE9op5i8qfq9TWs7Cmk0B42zHp1gTQKBgQCT\\nA2qSyDiL8GrPWAMfwOeIKRyvRRYdO5ib8c250wrgjMizkVXCu4OjBnTd0vHSdSWL\\nkhfxbp7haKDSpeepguMy92/3ULox87XwmXfdsLY1PDCKylRNg8A73FPe/SCgsLup\\nAinMV6GJALcXQS6E8pWcjPqsebwy/38iA3cpCIEyQQKBgQDRkr7Zdb9Gzl4VwTDl\\nhE4fwJf8np9LpkQnqAa5W8wNwKGEaPFFz7Cd2QkmNqSKT4zRX3+Z/Ha5PC8wub0e\\nINPDUWgnuJ5M4Spup9zGQiBPX2dsZMSGitdwV5VN5W4u2T32Pgync832iL8pw4th\\nJYwQE/IzXQjqrNQNr1fj+UB3Cw==\\n-----END PRIVATE KEY-----\\n",
                  "client_email": "firebase-adminsdk-g3oj2@merge2d.iam.gserviceaccount.com",
                  "client_id": "111792603931416770865",
                  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                  "token_uri": "https://oauth2.googleapis.com/token",
                  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-g3oj2%40merge2d.iam.gserviceaccount.com"
                }
                """;
        ByteArrayInputStream serviceAccountStream = new ByteArrayInputStream(SERVICE_ACCOUNT_JSON.getBytes(StandardCharsets.UTF_8));

        try {
            var credentials = GoogleCredential

                    .fromStream(serviceAccountStream)
                    .createScoped(List.of("https://www.googleapis.com/auth/firebase.messaging"));

            credentials.refreshToken();

            System.out.println("过期时间 ：" + credentials.getExpiresInSeconds());
            String tokenValue = credentials.getAccessToken();
            System.out.println("tokenValue : " + tokenValue);
            return tokenValue;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    public static void initOkHttpClient() {
        int count = 20;
        okHttpClientArr = new OkHttpClient[count];

        for (int i = 0; i < count; i++) {
            Dispatcher dispatcher = new Dispatcher();
            dispatcher.setMaxRequests(64);
            dispatcher.setMaxRequestsPerHost(32);

            ConnectionPool connectionPool = new ConnectionPool(200, 5, TimeUnit.MINUTES);

            okHttpClientArr[i] = new OkHttpClient.Builder()
                    .dns(new JDns())
                    .dispatcher(dispatcher)
                    .connectionPool(connectionPool)
                    .readTimeout(5 , TimeUnit.MINUTES)
                    .writeTimeout(5 , TimeUnit.MINUTES)
                    .connectTimeout(5 , TimeUnit.MINUTES)
                    .build();
        }
    }
}
