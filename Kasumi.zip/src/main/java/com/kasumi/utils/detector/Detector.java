package com.kasumi.utils.detector;

public interface Detector {
    void dealResult(String message);
}
