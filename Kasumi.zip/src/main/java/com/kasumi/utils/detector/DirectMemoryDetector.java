package com.kasumi.utils.detector;


import com.kasumi.core.Server;
import com.kasumi.utils.tool.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicLong;


public abstract class DirectMemoryDetector implements Runnable, Detector {
    private static boolean inited;
    private static AtomicLong RESERVED_MEMORY;
    private static AtomicLong TOTAL_CAPACITY;
    private static Long MAX_MEMORY;

    private static final Logger log = LoggerFactory.getLogger(DirectMemoryDetector.class);

    private boolean hasIgnore = false;

    private int lastGcTime = Time.getCurrentSeconds();

    public static void init() {
        try {
            var clazz = Class.forName("java.nio.Bits");
            Field[] fields = clazz.getDeclaredFields();
            for (var f : fields) {
                if (f.getName().equals("RESERVED_MEMORY")) {
                    f.setAccessible(true);
                    RESERVED_MEMORY = (AtomicLong) f.get(clazz);
                } else if (f.getName().equals("TOTAL_CAPACITY")) {
                    f.setAccessible(true);
                    TOTAL_CAPACITY = (AtomicLong) f.get(clazz);
                } else if (f.getName().equals("MAX_MEMORY")) {
                    f.setAccessible(true);
                    MAX_MEMORY = (Long) f.get(clazz);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            inited = true;
        }
    }

    public static int[] getMemoryInfo() {
        if (!inited) {
            init();
        }
        int[] info = new int[3];
        if (MAX_MEMORY != null) {
            info[0] = (int) (MAX_MEMORY / 1024 / 1024);
        }
        if (TOTAL_CAPACITY != null) {
            info[1] = (int) (TOTAL_CAPACITY.get() / 1024 / 1024);
        }
        if (RESERVED_MEMORY != null) {
            info[2] = (int) (RESERVED_MEMORY.get() / 1024 / 1024);
        }
        return info;
    }

    @Override
    public void run() {
        try {
            int[] memoryInfo = getMemoryInfo();
            if (memoryInfo[0] > 0 && memoryInfo[1] > 0 && memoryInfo[2] > 0) {
                int now = Time.getCurrentSeconds();
                boolean needGc = false;
                log.info("MAX_MEMORY is {},TOTAL_CAPACITY is {}, RESERVED_MEMORY is {}", memoryInfo[0], memoryInfo[1], memoryInfo[2]);
                //用了60%以上的内存,从服务器列表中移除,并报警
                if (memoryInfo[1] * 100 / memoryInfo[0] >= 60) {
                    needGc = true;
                    //报警
                    if (!hasIgnore) {
                        dealResult(Server.instance().getName() + ": has fatal memory leak");
                    }
                } else if (memoryInfo[1] * 100 / memoryInfo[0] >= 40) {//用了40%以上的内存,GC并报警
                    needGc = true;
                    //报警
                    dealResult(Server.instance().getName() + ": maybe has memory leak");
                }

                if (needGc && now - lastGcTime > 60) {
                    System.gc();
                    lastGcTime = now;
                    log.info("maybe memory leak, do gc ....");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
