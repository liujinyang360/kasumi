package com.kasumi.utils.csv;

import com.csvreader.CsvReader;
import io.netty.util.internal.StringUtil;

import java.io.InputStream;
import java.lang.reflect.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class CsvParser {

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static <T> T parseCsv(CsvTypeReference<T> typeReference, InputStream in, int beginIndex) throws Exception {
        if (beginIndex < 0) {
            throw new Exception("begin index should >= 0,now is " + beginIndex);
        }

        Type type = typeReference.getType();
        Type rawType = ((ParameterizedType) type).getRawType();
        Type itemType;
        Object result;
        boolean isMap = false;

        if (Collection.class.isAssignableFrom((Class<?>) rawType)) {
            result = createCollection(rawType);
            itemType = ((ParameterizedType) type).getActualTypeArguments()[0];
        } else if (Map.class.isAssignableFrom((Class<?>) rawType)) {
            result = createMap(rawType);
            itemType = ((ParameterizedType) type).getActualTypeArguments()[1];
            isMap = true;
        } else {
            throw new Exception("parser only support Collection or Map Object,now is " + rawType.getTypeName());
        }

        Class<?> clazz = (Class<?>) itemType;
        CsvFieldStruct fieldStruct = createFieldStruct(clazz, isMap);

        CsvReader reader = null;
        try {
            reader = new CsvReader(in, StandardCharsets.UTF_8);
            int row = 0;
            while (reader.readRecord()) {
                row++;
                if (row < beginIndex) {
                    continue;
                }
                Object e = parseCsvElement(reader, clazz, fieldStruct);
                if (!isMap) {
                    ((Collection) result).add(e);
                } else {
                    Method method = fieldStruct.getKeyGetMethod();
                    method.setAccessible(true);
                    ((Map) result).put(method.invoke(e), e);
                }
            }
        } catch (Exception e) {
            throw new Exception("parser error..." + e.toString());
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
        return (T) result;
    }


    @SuppressWarnings({"rawtypes", "unchecked"})
    public static <T> T parseCsv(CsvTypeReference<T> typeReference, InputStream in, int nameIndex, int beginIndex) throws Exception {
        if (nameIndex < 0 || beginIndex < 1 || nameIndex >= beginIndex) {
            throw new Exception(
                    "name index should >= 0,now is " + nameIndex + ",begin index should >= 1,now is " + beginIndex + ",name index should < begin index");
        }

        Type type = typeReference.getType();
        Type rawType = ((ParameterizedType) type).getRawType();
        Type itemType;
        Object result;
        boolean isMap = false;

        if (Collection.class.isAssignableFrom((Class<?>) rawType)) {
            result = createCollection(rawType);
            itemType = ((ParameterizedType) type).getActualTypeArguments()[0];
        } else if (Map.class.isAssignableFrom((Class<?>) rawType)) {
            result = createMap(rawType);
            itemType = ((ParameterizedType) type).getActualTypeArguments()[1];
            isMap = true;
        } else {
            throw new Exception("parser only support Collection or Map Object,now is " + rawType.getTypeName());
        }

        Class<?> clazz = (Class<?>) itemType;
        CsvFieldStruct fieldStruct = null;

        CsvReader reader = null;
        try {
            reader = new CsvReader(in, StandardCharsets.UTF_8);
            int row = 0;
            var nameMap = new HashMap<String, Integer>();
            while (reader.readRecord()) {
                row++;
                if (row == nameIndex) {
                    nameMap = createNameMap(reader);
                    fieldStruct = createFieldStruct(clazz, isMap, nameMap);
                    continue;
                }

                if (row < beginIndex) {
                    continue;
                }

                Object e = parseCsvElement(reader, clazz, fieldStruct);
                if (!isMap) {
                    ((Collection) result).add(e);
                } else {
                    Method method = fieldStruct.getKeyGetMethod();
                    method.setAccessible(true);
                    ((Map) result).put(method.invoke(e), e);
                }
            }
        } catch (Exception e) {
            throw new Exception("parser error..." + e.toString());
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
        return (T) result;
    }


    private static HashMap<String, Integer> createNameMap(CsvReader reader) throws Exception {
        var nameMap = new HashMap<String, Integer>();
        int col = reader.getColumnCount();
        for (int i = 0; i < col; i++) {
            String name = reader.get(i).trim().replace("_", "").toLowerCase().replaceAll("\\p{C}", "");
            nameMap.put(name, i);
        }
        return nameMap;
    }

    private static Object parseCsvElement(CsvReader reader, Class<?> clazz, CsvFieldStruct fieldStruct) throws Exception {
        Object e = clazz.getDeclaredConstructor().newInstance();
        var fieldList = fieldStruct.getFieldList();
        for (int i = 0; i < fieldList.size(); i++) {
            var element = fieldList.get(i);
            if (element.getIndex() < 0) {
                continue;
            }
            var annotation = element.getFieldAnnotation();
            if (annotation != null && !"".equals(annotation.method())) {
                Method method = e.getClass().getMethod(annotation.method(), String.class);
                method.setAccessible(true);
                method.invoke(e, getValue(reader.get(element.getIndex()), "String"));
            } else if ((annotation != null && !"".equals(annotation.split()))) {
                String value = (String) getValue(reader.get(element.getIndex()), "String");
                if (value == null || value.equals("")) {
                    continue;
                }
                String[] tmp = value.split(annotation.split());
                Method method = element.getMethod();
                method.setAccessible(true);
                if (element.getType().isArray()) {
                    Object arrayObject = Array.newInstance(element.getType().getComponentType(), tmp.length);
                    for (int j = 0; j < tmp.length; j++) {
                        Array.set(arrayObject, j, getValue(tmp[j], element.getType().getComponentType().getName()));
                    }
                    method.invoke(e, arrayObject);
                } else if (Collection.class.isAssignableFrom(element.getType())) {
                    var list = parseObject(element.getFieldType(), tmp);
                    method.invoke(e, list);
                } else {
                    throw new Exception("annotation split should declare Array or Collection Field, elementName = " + element.getFiledName());
                }
            } else {
                Method method = element.getMethod();
                method.setAccessible(true);
                method.invoke(e, getValue(reader.get(element.getIndex()), element.getTypeName()));
            }
        }
        return e;
    }

    private static CsvFieldStruct createFieldStruct(Class<?> clazz, boolean isMap) throws Exception {
        CsvFieldStruct struct = new CsvFieldStruct(isMap);
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            var field = fields[i];
            //静态属性不序列化
            if (Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            var annClass = field.getAnnotation(CsvField.class);
            if (annClass != null && annClass.ignore()) {
                continue;
            }
            CsvFieldInfo ce = new CsvFieldInfo(field);
            struct.addFieldInfo(ce);
        }
        struct.initFieldInfo(clazz);
        return struct;
    }

    private static CsvFieldStruct createFieldStruct(Class<?> clazz, boolean isMap, HashMap<String, Integer> nameMap) throws Exception {
        CsvFieldStruct struct = new CsvFieldStruct(isMap);
        struct.setIndexByName(true);
        Field[] fields = clazz.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            var field = fields[i];
            //静态属性不序列化
            if (Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            var annClass = field.getAnnotation(CsvField.class);
            if (annClass != null && annClass.ignore()) {
                continue;
            }
            int filedIndex = nameMap.getOrDefault(field.getName().trim().replace("_", "").toLowerCase(), -1);
            if (filedIndex >= 0) {
                CsvFieldInfo ce = new CsvFieldInfo(field);
                ce.setIndex(filedIndex);
                struct.addFieldInfo(ce);
            }
        }
        struct.initFieldInfo(clazz);
        return struct;
    }

    private static Object getValue(String value, String type) throws Exception {
        switch (type) {
            case "int":
            case "Integer":
            case "java.lang.Integer":
                if (StringUtil.isNullOrEmpty(value)) {
                    return 0;
                }
                return Integer.parseInt(value);
            case "long":
            case "Long":
            case "java.lang.Long":
                if (StringUtil.isNullOrEmpty(value)) {
                    return 0;
                }
                return Long.parseLong(value);
            case "float":
            case "Float":
            case "java.lang.Float":
                if (StringUtil.isNullOrEmpty(value)) {
                    return 0.0f;
                }
                return Float.parseFloat(value);
            case "byte":
            case "Byte":
            case "java.lang.Byte":
                if (StringUtil.isNullOrEmpty(value)) {
                    return 0;
                }
                return Byte.parseByte(value);
            case "short":
            case "Short":
            case "java.lang.Short":
                if (StringUtil.isNullOrEmpty(value)) {
                    return 0;
                }
                return Short.parseShort(value);
            case "double":
            case "Double":
            case "java.lang.Double":
                if (StringUtil.isNullOrEmpty(value)) {
                    return 0.0;
                }
                return Double.parseDouble(value);
            case "boolean":
            case "Boolean":
            case "java.lang.Boolean":
                if (StringUtil.isNullOrEmpty(value)) {
                    return false;
                }
                return Boolean.parseBoolean(value);
            case "string":
            case "String":
            case "java.lang.String":
                return value;
            case "BigDecimal":
                if (StringUtil.isNullOrEmpty(value)) {
                    return new BigDecimal("0");
                }
                return new BigDecimal(value);
            default:
                throw new Exception("type not find " + type);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static Collection parseObject(Type type, String[] tmp) throws Exception {
        Type itemType = ((ParameterizedType) type).getActualTypeArguments()[0];
        Collection list = createCollection(((ParameterizedType) type).getRawType());
        for (String s : tmp) {
            list.add(getValue(s, itemType.getTypeName()));
        }
        return list;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static Collection createCollection(Type type) throws Exception {
        Class<?> rawClass = (Class<?>) type;
        Collection list;
        if (rawClass == AbstractCollection.class
                || rawClass == Collection.class) {
            list = new ArrayList();
        } else if (rawClass.isAssignableFrom(HashSet.class)) {
            list = new HashSet();
        } else if (rawClass.isAssignableFrom(LinkedHashSet.class)) {
            list = new LinkedHashSet();
        } else if (rawClass.isAssignableFrom(TreeSet.class)) {
            list = new TreeSet();
        } else if (rawClass.isAssignableFrom(ArrayList.class)) {
            list = new ArrayList();
        } else if (rawClass.isAssignableFrom(EnumSet.class)) {
            Type itemType;
            itemType = Object.class;
            list = EnumSet.noneOf((Class<Enum>) itemType);
        } else if (rawClass.isAssignableFrom(Queue.class)) {
            list = new LinkedList();
        } else {
            try {
                list = (Collection) rawClass.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                throw new Exception("create instance error, class " + rawClass.getName());
            }
        }
        return list;
    }

    @SuppressWarnings({"rawtypes"})
    public static Map createMap(Type type) throws Exception {
        Class<?> rawClass = (Class<?>) type;
        Map map;
        if (rawClass == AbstractMap.class
                || rawClass == Map.class) {
            map = new HashMap();
        } else if (rawClass == HashMap.class) {
            map = new HashMap();
        } else if (rawClass == Hashtable.class) {
            map = new Hashtable();
        } else if (rawClass == IdentityHashMap.class) {
            map = new IdentityHashMap();
        } else if (rawClass == SortedMap.class || rawClass == TreeMap.class) {
            map = new TreeMap();
        } else if (rawClass == ConcurrentHashMap.class || rawClass == ConcurrentMap.class) {
            map = new ConcurrentHashMap();
        } else if (rawClass == LinkedHashMap.class) {
            map = new LinkedHashMap();
        } else {
            try {
                map = (Map) rawClass.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                throw new Exception("create instance error, class " + rawClass.getName());
            }
        }
        return map;
    }
}
