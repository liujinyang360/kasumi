package com.kasumi.utils.log;


import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.HiddenFileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static com.kasumi.utils.tool.Tools.getRootPath;


public class FileListener extends FileAlterationListenerAdaptor {
    private static final Logger log = LoggerFactory.getLogger(FileListener.class);
    public static ExecutorService fixedThreadPool = Executors.newFixedThreadPool(1);
    public static String fileAddress = getRootPath() + LogManager.fileName;
    public static File file = new File(fileAddress);
    public static long num = 0;

    public void onFileChange(File file) {
        if (fileAddress.equals(file.getAbsolutePath())) {
            try {
                readAW();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void readAW() throws IOException {
        if (!LogManager.initEnd) {
            return;
        }
        try (RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");) {
            if (num > randomAccessFile.length()) {
                num = 0;
            }
            randomAccessFile.seek(num);
            String str = randomAccessFile.readLine();
            for (; str != null; str = randomAccessFile.readLine()) {
                LogManager.convertLog(str);
            }
            num = randomAccessFile.length();
        }
    }

    public void onStart(FileAlterationObserver observer) {
        super.onStart(observer);
    }

    public void onStop(FileAlterationObserver observer) {
        super.onStop(observer);
    }

    public static void listen() {
        fixedThreadPool.submit(() -> {
            log.info("File Listener Begin");
            long interval = TimeUnit.SECONDS.toMillis(1);
            IOFileFilter directories = FileFilterUtils.and(
                    FileFilterUtils.directoryFileFilter(),
                    HiddenFileFilter.VISIBLE);
            IOFileFilter files = FileFilterUtils.and(
                    FileFilterUtils.fileFileFilter(),
                    FileFilterUtils.suffixFileFilter(LogManager.fileFilterType));
            IOFileFilter filter = FileFilterUtils.or(directories, files);
            FileAlterationObserver observer = new FileAlterationObserver(new File(getRootPath()), filter);
            observer.addListener(new FileListener());
            FileAlterationMonitor monitor = new FileAlterationMonitor(interval, observer);
            try {
                monitor.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}