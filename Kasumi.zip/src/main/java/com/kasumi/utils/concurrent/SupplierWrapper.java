package com.kasumi.utils.concurrent;

import com.kasumi.conf.CommProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

/**
 * Supplier封装类,主要目的是用来检测原Supplier执行时间
 * @author Athena
 *
 * @param <T> 原Supplier类
 */

public class SupplierWrapper<T> implements Supplier<T> {

	private Supplier<T> supplier;
	private String 	callInfo = null;

	private static final Logger log = LoggerFactory.getLogger(SupplierWrapper.class);
	
	public SupplierWrapper(Supplier<T> supplier) {
		this.supplier = supplier;
		StackTraceElement[] stack = new Throwable().getStackTrace();
		if(stack.length >= 2 && stack[2] != null){
			callInfo = "call at " + stack[2].getClassName() + "." + stack[2].getMethodName() + "():"+ stack[2].getLineNumber();
		}
	}
		
	@Override
	public T get() {
		long now = System.currentTimeMillis();
		T t = this.supplier.get();
		long interval = System.currentTimeMillis() - now;
		if(interval > CommProperties.SlowExecuteInterval) {
			log.info(callInfo + " use time {}",interval);
		}
		return t;
	}
}
