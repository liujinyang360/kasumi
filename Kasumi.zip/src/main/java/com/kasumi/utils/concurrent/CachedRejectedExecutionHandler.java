package com.kasumi.utils.concurrent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * 线程池异常处理类
 * @author Athena
 */

public class CachedRejectedExecutionHandler implements RejectedExecutionHandler {
	private String			name;
	private ThreadPoolExecutor handlerExecutor;


	private static final Logger log = LoggerFactory.getLogger(CachedRejectedExecutionHandler.class);

	public CachedRejectedExecutionHandler(ThreadPoolExecutor handlerExecutor, String name){
		this.handlerExecutor = handlerExecutor;
		this.name = name;
	}
	
	@Override
	public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
		if(handlerExecutor == null || handlerExecutor.isShutdown()) {
			return;
		}
		if(r instanceof RunWrapper){
			RunWrapper rw = (RunWrapper)r;
			log.debug("rejected by [{}], queue size is {}, " + rw.getCallInfo(), name, handlerExecutor.getQueue().size());
		}else{
			log.debug("rejected by [{}]", name);
		}
		handlerExecutor.execute(r);
	}
}
