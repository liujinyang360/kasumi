package com.kasumi.utils.concurrent;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author Athena
 */
public class ThreadFixedPoolManager{
	/**线程数量*/
	private int 						count;
	/**线程池名称*/
	private String 						name;
	/**线程池执行器*/
	private ScheduledThreadPoolExecutor executor;
	
	public ThreadFixedPoolManager(int count, String name){
		this.count = count;
		this.name = name;
		executor = new ScheduledThreadPoolExecutor(count);
		ThreadFactoryImpl factory = new ThreadFactoryImpl(executor, name);
		executor.setThreadFactory(factory);
		executor.setRejectedExecutionHandler(new ServerRejectedExecutionHandler());
		executor.prestartAllCoreThreads();
	}
	
	public int getCount(){
		return count;
	}
	
	public String getName(){
		return name;
	}
	
	public ScheduledThreadPoolExecutor getScheduledExecutor(){
		return this.executor;
	}
	
	public final ScheduledFuture<?> schedule(Runnable r, long delay){
		r = new RunWrapper(r, true);
		return  executor.schedule(r, delay, TimeUnit.MILLISECONDS);
	}

	public final ScheduledFuture<?> schedule(Runnable r, long delay,TimeUnit unit){
		r = new RunWrapper(r, true);
		return  executor.schedule(r, delay, unit);
	}
	
	public final ScheduledFuture<?> execute(Runnable r){
		r = new RunWrapper(r, true);
		return  executor.schedule(r, 0, TimeUnit.MILLISECONDS);
	}
	
	public final ScheduledFuture<?> scheduleTask(Runnable r,long delay, long period){
		r = new RunWrapper(r, true);
		return executor.scheduleAtFixedRate(r, delay, period, TimeUnit.MILLISECONDS);
	}

	public final ScheduledFuture<?> scheduleTask(Runnable r,long delay, long period,TimeUnit unit){
		r = new RunWrapper(r, true);
		return executor.scheduleAtFixedRate(r, delay, period, unit);
	}
	
	public final void purge(){
		this.executor.purge();
	}
}
