package com.kasumi.utils.concurrent;

import com.kasumi.conf.CommProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 执行run的封装,捕获异常
 * @author Athena
 */

public class RunWrapper implements Runnable{
	private Runnable	runnable;
	private boolean		printInfo; 
	private String 		callInfo = "can not get call info";

	private static final Logger log = LoggerFactory.getLogger(RunWrapper.class);

	public RunWrapper(Runnable runnable, boolean printInfo){
		this.runnable = runnable;
		this.printInfo = printInfo;
		
		StackTraceElement[] stack = new Throwable().getStackTrace();
		if(stack.length >= 2 && stack[2] != null){
			callInfo = "call at " + stack[2].getClassName() + "." + stack[2].getMethodName() + "():"+ stack[2].getLineNumber();
		}
	}
	
	@Override
	public final void run(){
		try{
			long cur = System.currentTimeMillis();
			runnable.run();
			if(printInfo){
				long useTime = System.currentTimeMillis() - cur;
				if(useTime > CommProperties.SlowExecuteInterval){
					log.info(callInfo + " use time {}",useTime);
				}
			}
		}catch(Throwable e){
			log.error(callInfo + " has a ", e.toString());
			e.printStackTrace();
		}
	}
	
	public String getCallInfo(){
		return callInfo;
	}
}