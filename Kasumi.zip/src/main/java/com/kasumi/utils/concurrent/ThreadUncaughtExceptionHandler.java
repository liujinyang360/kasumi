package com.kasumi.utils.concurrent;

import org.apache.log4j.Logger;

import java.lang.Thread.UncaughtExceptionHandler;


public class ThreadUncaughtExceptionHandler implements UncaughtExceptionHandler{
	/**
	 * Logger for this class.
	 */
	private static final Logger	log	= Logger.getLogger(ThreadUncaughtExceptionHandler.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void uncaughtException(Thread t, Throwable e){
		log.error("Critical Error - Thread: " + t.getName() + " terminated abnormaly: " + e, e);
		e.printStackTrace();
	}
}