package com.kasumi.utils.concurrent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ThreadCachedPoolManager {
	
	private static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ThreadCachedPoolManager.class);
	
	private String	name;
	private int		minCount;
	private int		maxCount;
	private long 	keepTime;
	private ThreadPoolExecutor executor;
	private ThreadPoolExecutor singleExecutor;
	private ThreadFactoryImpl factory;
	
	public ThreadCachedPoolManager(String name, int minCount, int maxCount, long keepTime, BlockingQueue<Runnable> queue, int rejectedCount){
		this.name = name;
		this.minCount = minCount;
		this.maxCount = maxCount;
		this.keepTime = keepTime;
		
		executor = new ThreadPoolExecutor(minCount, maxCount, keepTime, TimeUnit.SECONDS, queue);
		factory = new ThreadFactoryImpl(executor, name);
		singleExecutor = new ThreadPoolExecutor(rejectedCount, 3, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
		singleExecutor.setThreadFactory(new ThreadFactoryImpl(singleExecutor, name + "-RejectedHandler"));
		executor.setThreadFactory(factory);
		executor.setRejectedExecutionHandler(new CachedRejectedExecutionHandler(singleExecutor, name));
//		executor.allowCoreThreadTimeOut(true);
	}

	public String getName() {
		return name;
	}

	public int getMinCount() {
		return minCount;
	}

	public void setMinCount(int minCount) {
		this.minCount = minCount;
		executor.setCorePoolSize(minCount);
	}

	public int getMaxCount() {
		return maxCount;
	}

	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
		executor.setMaximumPoolSize(maxCount);
	}

	public long getKeepTime() {
		return keepTime;
	}

	public void setKeepTime(long keepTime) {
		this.keepTime = keepTime;
		executor.setKeepAliveTime(keepTime, TimeUnit.SECONDS);
	}
	
	public void execute(Runnable command){
		ThreadGroup tg = Thread.currentThread().getThreadGroup();
		if(tg != factory.getThreadGroup()){
			command = new RunWrapper(command, true);
			executor.execute(command);
		}else{
			logger.debug("use [{}] pool repeat [{}]", getName(), command);
			command.run();
		}
	}

	public ThreadPoolExecutor getExecutor() {
		return executor;
	}
}
