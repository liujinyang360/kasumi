package com.kasumi.utils.block;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * BlockThread用来解决多线程环境下需要顺序执行的操作
 * 将需要执行的方法通过唯一的id传入相应的队列中
 * 主意,传入的方法不要加锁,否则有死锁的风险
 * @author Athena
 */
public class BlockThread extends Thread{
    private static BlockThread[] blockThreads;
    private static int threadSize = 0;
    private static boolean isInit = false;

    private LinkedBlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<>();
    private Object lock = new Object();

    public static void init() throws Exception{
        init(Runtime.getRuntime().availableProcessors());
    }

    /**
     * 添加一个任务
     * @param finalId 不可更改的id,一般是用户id,决定分发到哪个线程中
     * @param run 需要执行的方法
     */
    public static void addTask(long finalId,Runnable run){
        if(!isInit){
            try {
                init();
            }catch (Exception e){
                e.printStackTrace();
                return;
            }
        }

        long hash = finalId < 0 ? -finalId : finalId;
        blockThreads[(int) (hash % threadSize)].add(run);
    }

    public synchronized static void init(int threads) throws Exception{
        if(isInit){
            return;
        }
        if(threads <= 0){
            throw new Exception("thread size must > 0");
        }

        blockThreads = new BlockThread[threads];
        threadSize = threads;
        for(int i = 0; i < threads;i++){
            blockThreads[i] = new BlockThread();
            blockThreads[i].setName("BlockThread-"+i);
            blockThreads[i].start();
        }
        isInit = true;
    }

    private void add(Runnable run){

        this.taskQueue.add(run);
        synchronized (this.lock){
            this.lock.notify();
        }
    }

    @Override
    public void run() {
        while(true){
            while(!taskQueue.isEmpty()){
                try{
                    var run = taskQueue.poll();
                    run.run();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            synchronized (this.lock){
                try {
                    lock.wait();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
}
