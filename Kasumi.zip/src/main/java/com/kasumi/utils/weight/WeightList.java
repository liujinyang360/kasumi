package com.kasumi.utils.weight;


import com.kasumi.utils.tool.Rnd;
import com.kasumi.utils.tool.Tools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

/**
 * 权重选择类,构建列表,根据权重获得数据
 *
 * @param <T> 任意类型
 * @author Athena
 */
public class WeightList<T> {
    private long maxWight = 0L;//最大权重,随机时用此值作为最大值
    private ArrayList<Weight<T>> list;
    private boolean isInit = false;
    private String name;

    private static Logger logger = LoggerFactory.getLogger(WeightList.class);

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Weight<T>> getList() {
        return list;
    }

    public long getMaxWight() {
        return maxWight;
    }

    public WeightList() {
        this.list = new ArrayList<>();
    }

    public WeightList(int size) {
        this.list = new ArrayList<>(size);
    }

    public void addWeight(Weight<T> weight) {
        if (weight.getWeight() < 1) {
            return;
        }
        this.maxWight += weight.getWeight();
        long max = maxWight - 1;
        long min = maxWight - weight.getWeight();
        weight.setMinWeight(min);
        weight.setMaxWeight(max);

        this.list.add(weight);
    }

    public int getSize() {
        return this.list.size();
    }

    private WeightList<T> cloneWeightList() {
        WeightList<T> wl = new WeightList<>();
        for (Weight<T> weight : this.list) {
            wl.addWeight(weight);
        }
        return wl;
    }

    public T getRnd() {
        long rnd = Rnd.nextLong(maxWight);

        var weight = Tools.binarySearch(this.list, rnd);
        if (weight == null) {
            return this.list.get(0).getElement();
        } else {
            return weight.getElement();
        }
    }

    public Weight<T> getRndWeight() {
        long rnd = Rnd.nextLong(maxWight);
        var weight = Tools.binarySearch(this.list, rnd);
        return weight == null ? this.list.get(0) : weight;
    }


    public int size() {
        return this.list == null ? 0 : this.list.size();
    }


    /**
     * 获得n个元素,需每次构建权重列表(看起来低效)
     * 主意:此处不要用lambda来获取,逻辑太复杂,不好调试
     *
     * @param count 需要的数量
     * @return 多个元素的列表
     */
    public ArrayList<T> getElementsByCount(int count) {

        if (count > this.list.size() || count < 1) {
            logger.error("选择数量超过可选择数量,或者选择数量小于1\t" + this.name);
            return null;
        }
        ArrayList<T> results = new ArrayList<>();
        if (count == this.list.size()) {
            for (Weight<T> weight : this.list) {
                results.add(weight.getElement());
            }
        } else {
            WeightList<T> wl = this.cloneWeightList();
            int tmpCount = count;
            while (tmpCount > 0) {
                int size = wl.list.size();
                int index = -1;
                long rnd = Rnd.nextLong(wl.maxWight);
                for (int i = 0; i < size; i++) {
                    Weight<T> weight = wl.list.get(i);
                    if (weight.getMinWeight() <= rnd && weight.getMaxWeight() >= rnd) {
                        results.add(weight.getElement());
                        index = i;
                        break;
                    }
                }
                if (index == -1) {
                    index = 0;
                    results.add(wl.list.get(0).getElement());
                }
                wl.list.remove(index);
                tmpCount--;
            }
        }
        return results;
    }

    public void clear() {
        if (this.list != null) {
            this.list.clear();
        }
        this.maxWight = 0L;
    }

    public void destroy() {
        if (this.list != null) {
            this.list.clear();
            this.list = null;
        }
    }
}
