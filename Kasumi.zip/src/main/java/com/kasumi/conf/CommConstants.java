package com.kasumi.conf;

/**
 * 底层引擎需要的常量
 * 任何项目不可更改
 */
public class CommConstants {

    public static final int PACKET_HEADER_LENGTH = 6;
    public static final int PACKET_ID_LENGTH = 2;

    public static final int Worker_Thread_Number = Math.max(8,Runtime.getRuntime().availableProcessors()*3) ;
    /**定时器线程数*/
    public static final int Schedule_Thread_Number = Math.min(8,Runtime.getRuntime().availableProcessors()) ;

    //HIGH 服务器类型
    /**游戏服的服务器类型*/
    public static final int SERVER_TYPE_GAME = 1;
    /**单点服的服务器类型single point*/
    public static final int SERVER_TYPE_SP = 2;
    /**对战服的服务器类型*/
    public static final int SERVER_TYPE_BATTLE = 3;
    /**匹配服务器类型*/
    public static final int SERVER_TYPE_MATCH = 4;
    /**GM服的服务器类型*/
    public static final int SERVER_TYPE_GM = 5;
    /**gateway 服务器**/
    public static final int SERVER_TYPE_GATEWAY = 6;

    /**每个包的最大长度*/
    public static final int Normal_MAX_PACKET_SIZE = (int)Short.MAX_VALUE * 2 - 100;

    public static final int MIDDLE_MAX_PACKET_SIZE = 1024 * 1024 * 5;
    /**大包长度*/
    public static final int LARGE_MAX_PACKET_SIZE = 1024 * 1024 * 50;

    /**最小时区*/
    public static final int MIN_TIME_ZONE = -12;
    /**最大时区*/
    public static final int MAX_TIME_ZONE = 12;

    public static final int Firebase_Send_Limit = 100;
    public static final String Error_IDFA = "00000000-0000-0000-0000-000000000000";
    public static final int PreemptSingle = 1;
    public static final int PreemptMulti = 2;
}
