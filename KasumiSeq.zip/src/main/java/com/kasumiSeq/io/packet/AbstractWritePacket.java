package com.kasumiSeq.io.packet;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;

import java.util.ArrayList;

public abstract class AbstractWritePacket<T>{
    protected int id;
    protected int seqId;
    protected ByteBuf writeBuf;
    protected ByteBuf finalBuf;

    protected byte[] finalBytes;//在堆内存中,不用回收

   protected ArrayList<String[]>  logList = new ArrayList<>();

    public AbstractWritePacket(int id,int seqId) {
        this.id = id;
        this.writeBuf = PooledByteBufAllocator.DEFAULT.buffer(16);
        this.seqId = seqId;
        if(this.seqId != 0){
            writeInt(seqId);
        }
    }

    public int getId() {
        return id;
    }

    public int getSeqId(){
        return this.seqId;
    }

    public final void writeInt(int in) {
        logList.add(new String[]{"Int",String.valueOf(in)});
        this.writeBuf.writeIntLE(in);
    }

    public final void writeShort(int in) {
        logList.add(new String[]{"Short",String.valueOf(in)});
        this.writeBuf.writeShortLE(in);
    }

    public final void writeByte(int in) {
        logList.add(new String[]{"Byte",String.valueOf(in)});
        this.writeBuf.writeByte(in);
    }

    public final void writeBoolean(boolean b) {
        logList.add(new String[]{"Boolean",String.valueOf(b)});
        this.writeBuf.writeBoolean(b);
    }

    public final void writeBytes(byte[] bytes) {
        logList.add(new String[]{"Bytes",String.valueOf(bytes.length)});
        this.writeBuf.writeBytes(bytes, 0, bytes.length);
    }

    public final void writeBytes(ByteBuf buf){
        this.writeBuf.writeBytes(buf);
    }

    public final void writeBytes(ByteBuf buf,int startIndex,int length){
        this.writeBuf.writeBytes(buf,startIndex,length);
    }

    public final void writeUtfStr(String str){
        if(str == null){
            str = "";
        }
        try {
            byte[] bytes = str.getBytes("utf-8");
            this.writeShort(bytes.length);
            this.writeBytes(bytes);
            logList.add(new String[]{"UtfStr",str});
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public final void writeLongUtfStr(String str){
        if(str == null){
            str = "";
        }
        try {
            byte[] bytes = str.getBytes("utf-8");
            int length = bytes.length;
            this.writeInt(length);
            this.writeBytes(bytes);
            logList.add(new String[]{"LongUtfStr",str});
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public final void writeLong(long l) {
        this.writeBuf.writeLongLE(l);
        logList.add(new String[]{"Long",String.valueOf(l)});
    }

    public final void writeDouble(double d) {
        this.writeBuf.writeDoubleLE(d);
        logList.add(new String[]{"Double",String.valueOf(d)});
    }

    public final void writeFloat(float f) {
        this.writeBuf.writeFloatLE(f);
        logList.add(new String[]{"Float",String.valueOf(f)});
    }

    /**
     * 将writeBuf中的数据转换成协议,转换完成后自动释放writeBuf的内存
     * @return finalBuf
     */

    protected ByteBuf toByteBuff(){
        if (this.finalBuf == null) {
            int writeLength = this.writeBuf.writerIndex();
            int packetLength = writeLength + 2;
            this.finalBuf = PooledByteBufAllocator.DEFAULT.buffer(packetLength + 4);
            this.finalBuf.writeIntLE(packetLength);
            this.finalBuf.writeShortLE(this.id);
            this.finalBuf.writeBytes(this.writeBuf, writeLength);
            this.writeRelease();
        }
        return this.finalBuf;
    }

    public abstract T toBuf();

    /**
     * 仅仅写数据,不包括长度和协议号
     * @return 去掉header的buff
     */
    public ByteBuf toBufIgnoreHeader() {
        if (this.finalBuf == null) {
            int writeLength = this.writeBuf.writerIndex();
            this.finalBuf = PooledByteBufAllocator.DEFAULT.buffer(writeLength );
            this.finalBuf.writeBytes(this.writeBuf, writeLength);
            this.writeRelease();
        }
        return this.finalBuf;
    }

    /**
     * 把ByteBuf数据转换为byte数组
     * @param keepSource 是否保留原始数据,默认不保留
     * @return
     */
    public byte[] toBytes(boolean ... keepSource){
        if(this.finalBytes == null) {
            ByteBuf buf = this.toByteBuff();
            this.finalBytes = new byte[buf.readableBytes()];
            buf.readBytes(this.finalBytes);
            //如果参数不存在或者为false,则回收内存
            if(keepSource.length == 0 || !keepSource[0]){
                this.release();
            }
        }
        return this.finalBytes;
    }

    /**
     * 把ByteBuf数据(不包括头数据)转换为byte数组
     * @param keepSource 是否保留原始数据,默认不保留
     * @return
     */
    public byte[] toBytesIgnoreHeader(boolean ... keepSource){
        if(this.finalBytes == null) {
            ByteBuf buf = this.toBufIgnoreHeader();
            this.finalBytes = new byte[buf.readableBytes()];
            buf.readBytes(this.finalBytes);
            //如果参数不存在或者为false,则回收内存
            if(keepSource.length == 0 || !keepSource[0]){
                this.release();
            }
        }
        return this.finalBytes;
    }



    public int getWriteLength(){
        return this.writeBuf.writerIndex();
    }

    public void writeRelease() {
        if(this.writeBuf != null && this.writeBuf.refCnt() > 0) {
            try {
                this.writeBuf.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 释放所有内存
     * 通常来说finalBuf的内存无需手动释放
     * 但是广播的时候除外,因为每广播一次需要retain
     */
    public void release() {
        if (this.finalBuf != null && this.finalBuf.refCnt() > 0) {
            try {
                this.finalBuf.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void fullRelease(){
        this.writeRelease();
        this.release();
    }

    public ArrayList<String[]> getLogList() {
        return logList;
    }
}
