package com.kasumiSeq.io.packet;

import io.netty.buffer.ByteBuf;

/**
 * 	下行协议,协议格式为:4字节长度 + 2字节协议号 + body(byte[])
 *  其中长度包括协议号的长度,即body.length() + 2
 *  {@link ReadPacket}具有相同的格式,之所有分read和write是因为客户端不支持同协议号返回
 * @author Athena
 *
 */
public class WritePacket extends AbstractWritePacket<ByteBuf> {

	public WritePacket(int id) {
		super(id,0);
	}

	public WritePacket(int id,int seqId){
		super(id,seqId);
	}

	/**
	 * 将writeBuf中的数据转换成协议,转换完成后自动释放writeBuf的内存
	 * @return finalBuf
	 */
	public ByteBuf toBuf() {
		return super.toByteBuff();
	}
}
