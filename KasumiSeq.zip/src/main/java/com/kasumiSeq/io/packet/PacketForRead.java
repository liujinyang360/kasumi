package com.kasumiSeq.io.packet;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;

/**
 * 仅用于读取的packet
 * @author Athena
 */
public class PacketForRead extends ReadPacket {

    public PacketForRead(ByteBuf readBuf) {
        super(-1, readBuf);
    }

    @Override
    public void process() throws Exception {

    }

    public static PacketForRead packetForRead(ByteBuf readBuf){
        ByteBuf bf = PooledByteBufAllocator.DEFAULT.buffer(readBuf.readableBytes());
        readBuf.readBytes(bf);
        return new PacketForRead(bf);
    }
}
