package com.kasumiSeq.io.packet;

import com.kasumiSeq.io.ClientChannel;
import com.samus.core.transfer.Message;
import io.netty.buffer.ByteBuf;

import java.util.ArrayList;

/**
 * {@link WritePacket},他们具有相同的格式,一个只管读,一个只管写
 * @author Athena
 *
 */
public abstract class ReadPacket {
	private final int id;
	private final ByteBuf readBuf;
	/**
	 * futureId 用来标识一个Future,当此值不为-1的时候意味着该协议要返回future的完成情况
	 */
	private long futureId = -1;

	private String backTag;

	private ClientChannel clientChannel;

	protected ArrayList<String[]> logList = new ArrayList<>();

	public ReadPacket(int id, ByteBuf readBuf) {
		this.id = id;
		this.readBuf = readBuf;
	}


	public int id() {
		return this.id;
	}
	
	public int readableBytes() {
		return this.readBuf.readableBytes();
	}

	public String getBackTag() {
		return backTag;
	}

	public void setBackTag(String backTag) {
		this.backTag = backTag;
	}

	public ClientChannel getClientChannel() {
		return clientChannel;
	}

	public void setClientChannel(ClientChannel clientChannel) {
		this.clientChannel = clientChannel;
	}

	public abstract void process() throws Exception;

	public void process(Message message) throws Exception {
		this.process();
	}

	public final int readInt() {
		int value = this.readBuf.readIntLE();
		logList.add(new String[]{"int", String.valueOf(value)});
		return value;
//		return this.readBuf.readIntLE();
	}
	
	public final int readUnsignedShort() {
		int value = this.readBuf.readUnsignedShortLE();
		logList.add(new String[]{"UnSignedShort", String.valueOf(value)});
		return value;
	}

	public final int readUnsignedByte(){
		int value = this.readBuf.readUnsignedByte();
		logList.add(new String[]{"UnSignedByte", String.valueOf(value)});
		return value;
	}
	
	public final int readShort() {
		int value = this.readBuf.readShortLE();
		logList.add(new String[]{"short", String.valueOf(value)});
		return value;
	}

	public final int readByte() {
		int value = this.readBuf.readByte();
		logList.add(new String[]{"byte", String.valueOf(value)});
		return value;
	}
	
	public final boolean readBoolean() {
		boolean value = this.readBuf.readBoolean();
		logList.add(new String[]{"boolean", String.valueOf(value)});
		return value;
	}

	
	public final long readLong() {
		long value = this.readBuf.readLongLE();
		logList.add(new String[]{"long", String.valueOf(value)});
		return value;
	}

	public final double readDouble() {
		double value = this.readBuf.readDoubleLE();
		logList.add(new String[]{"double", String.valueOf(value)});
		return value;
	}

	public final float readFloat() {
		float value = this.readBuf.readFloatLE();
		logList.add(new String[]{"float", String.valueOf(value)});
		return value;
	}

	public final long readUnsignedInt() {
		long value = this.readBuf.readUnsignedIntLE();
		this.logList.add(new String[]{"UnSignedByte", String.valueOf(value)});
		return value;
	}
	
	public final String readUtfStr() {
		try {
			int length = this.readUnsignedShort();
			byte[] bytes = new byte[length];
			this.readBytes(bytes);
			String value = new String(bytes, "utf-8");
			logList.add(new String[]{"String", value});
			return value;
		}catch (Exception e){
			e.printStackTrace();
		}
		return "";
	}

	public final String readLongUtfStr() {
		try {
			int length = this.readInt();
			byte[] bytes = new byte[length];
			this.readBytes(bytes);
			String value = new String(bytes, "utf-8");
			logList.add(new String[]{"String", value});
			return value;
		}catch (Exception e){
			e.printStackTrace();
		}
		return "";
	}
	
	public final void readBytes(byte[] bytes) {
		this.readBuf.readBytes(bytes);
		logList.add(new String[]{"byte[]", String.valueOf(bytes.length)});
	}

	public ByteBuf getReadBuf() {
		return readBuf;
	}

	public final void readBytes(ByteBuf byteBuf){
		logList.add(new String[]{"ByteBuf Length", String.valueOf(byteBuf.readableBytes())});
		this.readBuf.readBytes(byteBuf);
	}

	public long getFutureId() {
		return futureId;
	}

	public boolean isFuture() {
		return futureId > 0;
	}

	public void setFutureId(long futureId) {
		this.futureId = futureId;
	}

	/**
	 * 由系统自动调用
	 */
	public final void release() {
		if(this.readBuf != null && this.readBuf.refCnt() > 0) {
			try {
				this.readBuf.release();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

	public int capacity(){
		return readBuf.capacity();
	}

	public boolean canRead() {
		return readBuf.isReadable();
	}

	public ArrayList<String[]> getLogList() {
		return logList;
	}
}
