package com.kasumiSeq.io;

import io.netty.buffer.ByteBuf;

public interface KasumiKcp {

    void write(ByteBuf buf);

    void close();

    boolean isClosed();

    void setTimeoutMillis(long timeoutMillis);
}
