package com.kasumiSeq.io;


import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.io.packet.ReadPacket;
import com.kasumiSeq.io.packet.WritePacket;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * 协议解析器
 * @author Athena
 *
 */

public abstract class AbstractPacketDecoder extends ByteToMessageDecoder {

	private static final Logger log = LoggerFactory.getLogger(AbstractPacketDecoder.class);

	/**
	 * 协议解析方法,协议格式{@link WritePacket}
	 */
	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
		if (in.readableBytes() < CommConstants.PACKET_HEADER_LENGTH) {
			return;
		}

		in.markReaderIndex();
		int dataLength = in.readIntLE();

		// 包长度不对
		if (dataLength < CommConstants.PACKET_ID_LENGTH ) {
			invalidPacketSize(ctx.channel());
			return;
		}

		int packetId = in.readUnsignedShortLE();
		if(dataLength > maxPacketSize(packetId)){
			invalidPacketSize(ctx.channel());
			return;
		}

		if (in.readableBytes() < dataLength - 2) {
			in.resetReaderIndex();
			return;
		}

		ByteBuf readBuf = PooledByteBufAllocator.DEFAULT.buffer(dataLength - 2);
		in.readBytes(readBuf);

		ReadPacket mp = createPacket(packetId, readBuf);
		if (mp != null) {
			out.add(mp);
			if(this.checkPacketSize() && dataLength > largePacketSize()){
				log.info("receive a large packet,id is {},length is {},channel is {}",packetId,dataLength,ctx.channel());
			}
		} else {//没找到相应协议需要释放内存,否则传到handler类里面进行释放
			readBuf.release();
			notExistPacket(ctx.channel(),packetId);
		}
	}

	protected boolean checkPacketSize(){
		return false;
	}

	protected int largePacketSize(){
		return CommConstants.Normal_MAX_PACKET_SIZE;
	}

	/**
	 * 处理大小不对的包
	 * @param channel 连接channel
	 */
	public abstract void invalidPacketSize(Channel channel);

	/**
	 * 处理未定义的包
	 * @param channel channel
	 * @param id 协议id
	 */
	public abstract void notExistPacket(Channel channel, int id);

	/**
	 * 生成项目需要的包,每个项目可能不同,但是都继承于{@link ReadPacket}
	 * @param id 协议id
	 * @param readBuf 包体
	 * @return 具体协议
	 */
	public abstract ReadPacket createPacket(int id, ByteBuf readBuf);

	/**
	 * 最大包长度
	 * @param packetId 协议id
	 * @return 最大包体长度,推荐用 CommConstants.MIDDLE_MAX_PACKET_SIZE
	 */
	public abstract int maxPacketSize(int packetId);

}
