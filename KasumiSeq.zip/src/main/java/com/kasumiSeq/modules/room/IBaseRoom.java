package com.kasumiSeq.modules.room;


import com.kasumiSeq.io.packet.WritePacket;

public interface IBaseRoom {
    /**
     * 房间ID
     *
     * @return roomId
     */
    long getId();

    /**
     * 创建时间
     *
     * @return time
     */
    long getCreateTime();

    /**
     * 初始化房间
     */
    void init();

    /**
     * 广播通知房间内玩家
     *
     * @param wp wp
     */
    void broadcast(WritePacket wp);

    /**
     * 房间销毁
     */
    void destroy();

    /**
     * 房间初始化结束
     */
    void doInitEnd();

    boolean isFinished();

    int getSignNumber();

    boolean isShouldDestroy();

    void setShouldDestroy(boolean shouldDestroy);

    boolean isDestroy();
}
