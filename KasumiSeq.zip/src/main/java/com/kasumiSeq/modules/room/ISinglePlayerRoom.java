package com.kasumiSeq.modules.room;


import com.kasumiSeq.modules.player.IBattlePlayer;

public interface ISinglePlayerRoom<T extends IBattlePlayer> extends IBaseRoom {
    /**
     * 获取玩家
     *
     * @return T
     */
    T getPlayer();
}
