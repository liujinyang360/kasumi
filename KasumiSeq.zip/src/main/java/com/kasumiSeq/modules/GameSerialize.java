package com.kasumiSeq.modules;

import com.kasumiSeq.io.packet.ReadPacket;
import com.kasumiSeq.io.packet.WritePacket;

/**
 * 序列化和反序列化接口
 * @author Athena
 */
public interface GameSerialize {
	/**
	 *序列化接口
	 * @param writer writer对象
	 * @throws Exception Io错误
	 */
	void serialize(WritePacket writer) throws Exception;

	/**
	 *反序列化接口
	 * @param reader reader对象
	 * @throws Exception Io错误
	 */
	void unSerialize(ReadPacket reader) throws Exception;
}

