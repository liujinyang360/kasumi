package com.kasumiSeq.modules.player.imp;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.utils.tool.Time;
import com.kasumiSeq.modules.GameSerialize;
import com.kasumiSeq.modules.player.IPlayer;

import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * 玩家基类
 * 包括必要的属性,定义必须实现得方法
 * @author Athena
 */
public abstract class AbstractPlayer implements IPlayer, GameSerialize {
    /**
     * 玩家Id
     */
    private int id;
    /**
     * 设备id（账号绑定后删除）
     */
    private String deviceCode;
    /**
     * 设备ID，不会被删除，随账号设备更新。供查询用
     */
    private String finalDeviceCode = "";
    /**
     * 玩家名字
     */
    private String name;
    /**
     * 邮箱
     */
    private String email = "";
    /**
     * 时差
     */
    private int timeDiff = 0;
    /**
     * 时区id
     */
    private ZoneId zoneId;
    /**
     * 创建时间
     */
    private int createTime;
    /**
     * 下线时间
     */
    private int logoutTime;
    /**
     * 更新时间
     */
    private int updateTime;
    /**
     * 最后登录时间
     **/
    private int loginTime;
    /**
     * 充值
     */
    private int diamond;
    /**
     * coin
     */
    private int coin;
    /**
     * 玩家设备类型
     */
    private int osType = CommProperties.Os_Android;
    /**
     * 服务端生成的token
     */
    private String token = "";
    /**
     * 上次收包时间
     */
    private long lastReceiveTime = System.currentTimeMillis();

    /**
     * apple id
     */
    private String appleId;

    /**
     * apple email
     */
    private String appleEmail;

    /**
     * facebook id
     */
    private String facebookId = "";
    private String facebookToken = "";
    private String facebookName = "";

    /**
     * 玩家头像
     */
    private String header = "";

    private String versionCode="";

    /**
     * 来源
     */
    private String userFrom = "";

    /**
     * firebase用户id
     **/
    private String firebaseId;
    /**
     * firebase设备token
     **/
    private String firebaseDeviceToken;
    /**
     * FCM token
     **/
    private String fcmToken = "";

    /**
     * 国家
     **/
    private String countryCode = "";
    /**
     *  系统码
     */
    private String idfa = "";
    /**
     * 语言
     **/
    private String langCode = "";
    private String phoneModel = "";
    /**
     * app包名称
     **/
    private String packageName = "";
    /**
     * 是否是回归账户
     */
    private boolean hasRecall = false;
    /**
     * 该设备是否有游客账户
     */
    private boolean hasVisitor = false;
    /**
     * 是否新注册用户
     */
    private boolean isNew;
    /**
     *是否已销毁
     */
    protected boolean isDestroy = false;

    /**
     * 是否初始化完成
     */
    protected boolean initEnd = false;

    /**
     * 离线类型
     */
    private int leaveType = CommProperties.LEAVE_TYPE_NORMAL;

    /**
     * 用户等级
     */
    private int stage = 0;


    public AbstractPlayer(int id){
        this.id = id;
    }


    public void setTimeDiff(int timeDiff) {
        this.timeDiff = timeDiff;
        if(this.timeDiff < CommConstants.MIN_TIME_ZONE){
            this.timeDiff = CommConstants.MIN_TIME_ZONE;
        }else if(this.timeDiff > CommConstants.MAX_TIME_ZONE){
            this.timeDiff = CommConstants.MAX_TIME_ZONE;
        }
    }

    public int getTimeDiff(){
        return this.timeDiff;
    }

    public ZoneId getZoneId() {
        if(this.zoneId == null){
            this.zoneId = ZoneId.of(this.timeDiff >= 0 ? "+" + this.timeDiff : "" + this.timeDiff);
        }
        return zoneId;
    }

    /**
     * 是否有facebook方式登录过
     *
     * @return 是够登录过
     */
    public boolean hasDeviceLoginFb() {
        return !"".equals(this.facebookId);
    }

    public int getDay() {
        return Time.getDay(LocalDateTime.now(this.getZoneId()));
    }

    @Override
    public int getId() {
        return id;
    }

    public boolean isHasRecall() {
        return hasRecall;
    }

    public void setHasRecall(boolean hasRecall) {
        this.hasRecall = hasRecall;
    }
    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getFinalDeviceCode() {
        return finalDeviceCode;
    }

    public void setFinalDeviceCode(String finalDeviceCode) {
        this.finalDeviceCode = finalDeviceCode;
    }

    public int getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(int loginTime) {
        this.loginTime = loginTime;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    public int getCreateTime() {
        return createTime;
    }

    public void setCreateTime(int createTime) {
        this.createTime = createTime;
    }

    public int getLogoutTime() {
        return logoutTime;
    }

    public void setLogoutTime(int logoutTime) {
        this.logoutTime = logoutTime;
    }

    public int getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(int updateTime) {
        this.updateTime = updateTime;
    }

    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }

    @Override
    public int getOsType() {
        return osType;
    }

    public void setOsType(int osType) {
        this.osType = osType;
    }

    public long getLastReceiveTime() {
        return lastReceiveTime;
    }

    public void setLastReceiveTime(long lastReceiveTime) {
        this.lastReceiveTime = lastReceiveTime;
    }

    public int getLeaveType() {
        return leaveType;
    }

    @Override
    public void setLeaveType(int leaveType) {
        this.leaveType = leaveType;
    }

    public String getFacebookId() {
        return facebookId;
    }

    public void setFacebookId(String facebookId) {
        this.facebookId = facebookId;
    }

    @Override
    public String getHeader() {
        return header;
    }

    @Override
    public void setHeader(String header) {
        this.header = header;
    }

    public String getAppleId() {
        return appleId;
    }

    @Override
    public void setAppleId(String appleId) {
        this.appleId = appleId;
    }
    public int getDiamond() {
        return diamond;
    }

    public void setDiamond(int diamond) {
        this.diamond = diamond;
    }

    public String getAppleEmail() {
        return appleEmail;
    }

    @Override
    public void setAppleEmail(String appleEmail) {
        this.appleEmail = appleEmail;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setZoneId(ZoneId zoneId) {
        this.zoneId = zoneId;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    /**
     * 获取大版本号 eg: 2.6.3 返回 6
     * @return
     */
    public int getVersionNum() {
        if ("".equals(versionCode)) {
            return 0;
        }
        String[] str = this.versionCode.split("\\.");
        if (str.length != 3) {
            return 0;
        }
        return Integer.parseInt(str[1]);
    }


    public int getStage() {
        return stage;
    }

    public void setStage(int stage) {
        this.stage = stage;
    }

    public String getFacebookToken() {
        return facebookToken;
    }

    public void setFacebookToken(String facebookToken) {
        this.facebookToken = facebookToken;
    }

    public String getFacebookName() {
        return facebookName;
    }

    public void setFacebookName(String facebookName) {
        this.facebookName = facebookName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getLangCode() {
        return langCode;
    }

    public void setLangCode(String langCode) {
        this.langCode = langCode;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getUserFrom() {
        return userFrom;
    }

    public void setUserFrom(String userFrom) {
        this.userFrom = userFrom;
    }

    public String getFirebaseId() {
        return firebaseId;
    }

    public void setFirebaseId(String firebaseId) {
        this.firebaseId = firebaseId;
    }

    public String getFirebaseDeviceToken() {
        return firebaseDeviceToken;
    }

    public void setFirebaseDeviceToken(String firebaseDeviceToken) {
        this.firebaseDeviceToken = firebaseDeviceToken;
    }

    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public boolean isHasVisitor() {
        return hasVisitor;
    }

    public void setHasVisitor(boolean hasVisitor) {
        this.hasVisitor = hasVisitor;
    }

    public boolean isNew() {
        return isNew;
    }

    public void setNew(boolean aNew) {
        isNew = aNew;
    }

    public boolean isDestroy() {
        return isDestroy;
    }

    public boolean isInitEnd() {
        return initEnd;
    }

    public void setInitEnd(boolean initEnd) {
        this.initEnd = initEnd;
    }

    public String getPhoneModel() {
        return phoneModel;
    }

    public void setPhoneModel(String phoneModel) {
        this.phoneModel = phoneModel;
    }

    public String getIdfa() {
        return idfa;
    }

    public void setIdfa(String idfa) {
        if (!CommConstants.Error_IDFA.equals(idfa.trim())) {
            this.idfa = idfa;
        }
    }

    @Override
    public void destroy(){
        if(this.isDestroy){
            return;
        }
        this.isDestroy = true;
    }

    public int getClassify() {
        return this.getId() % 2 + 1;
    }

}
