package com.kasumiSeq.modules.player;

public interface IGamePlayer extends IPlayer {
    void doTimeOut();

    void doTimeCheck();

    void doDayChanged();

    void removeCheckOrder(long orderId);
}
