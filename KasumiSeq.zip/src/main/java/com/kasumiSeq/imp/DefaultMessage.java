package com.kasumiSeq.imp;

import com.kasumiSeq.core.Server;
import com.kasumiSeq.io.packet.WritePacket;
import com.samus.core.transfer.Message;
import io.netty.buffer.ByteBuf;

import java.util.UUID;

public class DefaultMessage extends Message {

    public static DefaultMessage CallBackMessage(String tag){
        DefaultMessage message = new DefaultMessage(tag,UUID.randomUUID().toString().replace("-",""),false);
        return message;
    }

    public static DefaultMessage CallBackResponseMessage(String tag,String uuid){
        DefaultMessage message = new DefaultMessage(tag,uuid,true);
        return message;
    }

    public static DefaultMessage CallBackMessage(String tag, String expand) {
        DefaultMessage message = new DefaultMessage(tag,UUID.randomUUID().toString().replace("-",""),false, expand);
        return message;
    }

    public DefaultMessage(String tag){
        super(Server.instance().getTopic(),tag,Server.instance().getTag());
    }

    public DefaultMessage(String topic,String tag,String sourceTag ){
        super(topic,tag,sourceTag);
    }

    public DefaultMessage(String tag,WritePacket packet){
        this(tag);
        this.writePacket(packet);
    }

    public DefaultMessage(String tag, WritePacket packet, String expand) {
        super(Server.instance().getTopic(), tag, Server.instance().getTag(), "", false, expand);
        this.writePacket(packet);
    }

    public DefaultMessage(String tag,String uuid,boolean isCallbackResponse){
        super(Server.instance().getTopic(),tag,Server.instance().getTag(),uuid,isCallbackResponse);
    }

    public DefaultMessage(String tag,String uuid,boolean isCallbackResponse, String expand){
        super(Server.instance().getTopic(),tag,Server.instance().getTag(),uuid,isCallbackResponse, expand);
    }

    public DefaultMessage(ByteBuf readBuf){
        super(readBuf);
    }

    /**
     * 调用此方法会自动释放packet的内存
     * 不想释放的调用writeBytes方法
     * @param packet
     */
    public void writePacket(WritePacket packet){
        this.writeBytes(packet.toBuf());
        packet.release();
    }
}
