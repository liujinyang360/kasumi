package com.kasumiSeq.imp;

import com.kasumiSeq.core.Server;
import com.samus.core.transfer.CallbackResponse;
import com.samus.core.transfer.Pipeline;

public abstract class DefaultCallbackResponse implements CallbackResponse {
    @Override
    public Pipeline pipeline() {
        return Server.instance().pipeline();
    }

    @Override
    public String tag() {
        return Server.instance().getTag();
    }
}
