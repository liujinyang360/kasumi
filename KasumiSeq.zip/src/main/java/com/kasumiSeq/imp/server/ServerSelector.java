package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.core.Server;
import com.kasumiSeq.utils.tool.Rnd;
import com.kasumiSeq.utils.tool.ThreadPool;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

/**
 * 对战服或单点服选择器
 * 当对应单点模式时,从redis获取合法的tag
 * 否则从心跳中随机获取一个
 */
public class ServerSelector {
    public static int CHECK_DELAY = 2000;

    private String key;

    private String singleTag = null;

    private int preemptType = CommConstants.PreemptSingle;

    private int checkInterval = CommProperties.Preempt_Interval;

    private ScheduledFuture<?> checkFuture;

    private ConcurrentHashMap<String,Long> serverTagMap = new ConcurrentHashMap<>();

    public ServerSelector(String key,int preemptType){
        this.key = key;
        this.preemptType = preemptType;
    }

    public void startCheck(){
        if(this.checkFuture != null){
            this.checkFuture.cancel(true);
        }
        this.checkFuture = ThreadPool.SchedulePool.scheduleTask(()->check(),CHECK_DELAY,checkInterval);
    }

    public void addTag(String tag){
        this.serverTagMap.put(tag,System.currentTimeMillis());
    }

    public void setCheckInterval(int checkInterval) {
        this.checkInterval = checkInterval;
    }

    public void check(){
        if(this.preemptType == CommConstants.PreemptSingle){
            this.singleTag = Server.instance().getRedisController().getSystemValue(this.key);
        }else{
            long now = System.currentTimeMillis();
            for(var it = this.serverTagMap.entrySet().iterator();it.hasNext();){
                var entry = it.next();
                if(now - entry.getValue() >= CommProperties.SELECT_SERVER_EXPIRE_TIME){
                    it.remove();
                }
            }
        }
    }

    public String getTag(){
        if(this.preemptType == CommConstants.PreemptSingle){
            return this.singleTag;
        }else{
            var list = new ArrayList<String>();
            list.addAll(this.serverTagMap.keySet());
            return list.isEmpty() ? null : list.get(Rnd.get(list.size()));
        }
    }
}

