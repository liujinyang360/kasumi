/**
 * 匹配服分两种模式:single和multi
 * 处于单实例模式下,同时只有一台匹配服工作,所有的请求发送到该服务器上
 * 处于多实例模式下,同时有多台服务器工作,请求可以发送到任意服务器上
 * 在单实例模式下,各服务器会抢占redis的match字段,最先写入的作为工作服务器
 * 在多实例模式下,match字段对应一个map,所有服务器均写入,由游戏服自行选择
 * 一般默认为单实例模式
 * 需要注意的是,多实例模式下,因为redis无法对map的key单独设置超时时间,所以由游戏服检测超时
 */

package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.imp.DefaultMessage;
import com.kasumiSeq.io.packet.BasePacketId;
import com.kasumiSeq.io.packet.WritePacket;
import com.kasumiSeq.utils.tool.ThreadPool;
import com.kasumiSeq.utils.tool.Tools;
import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ScheduledFuture;

public abstract class DefaultMatchServer extends DefaultServer{
    public static int HeartbeatDelay = 1000 * 10;

    private boolean showLog = false;

    private ScheduledFuture<?> preemptFuture = null;

    private static final Logger log = LoggerFactory.getLogger(DefaultMatchServer.class);

    public DefaultMatchServer() throws Exception{
        this("configs/match.xml");
    }
    public DefaultMatchServer(String configFile) throws Exception{
        super(CommConstants.SERVER_TYPE_MATCH,configFile);
    }
    public DefaultMatchServer(String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception{
        super(CommConstants.SERVER_TYPE_MATCH,selfConfigFile,dbConfigFile,redisConfigFile,commonConfigFile);
    }

    /**
     *
     */
    public void startPreemptFuture(){
        this.stopPreemptFuture();
        if (this.matchPreemptModel == CommConstants.PreemptSingle) {
            this.preemptFuture = ThreadPool.SchedulePool.scheduleTask(() -> doRedisPreempt(),
                    getPreemptDelay(), CommProperties.Preempt_Interval);
        }else{//向游戏服发心跳
            this.preemptFuture = ThreadPool.SchedulePool.scheduleTask(() -> sendHeartbeatToGameServer(),
                    HeartbeatDelay, CommProperties.Preempt_Interval);
        }
    }

    protected void sendHeartbeatToGameServer(){
        WritePacket packet = new WritePacket(BasePacketId.REPORT_MATCH_HEARTBEAT);
        packet.writeUtfStr(this.getTag());
        DefaultMessage message = new DefaultMessage(Tools.getServerGroupName(CommConstants.SERVER_TYPE_GAME),packet);
        this.pipeline().sendMessage(message);
    }

    public int getPreemptDelay(){
        return  (this.getServerId() - 1)*10*1000;
    }

    public void stopPreemptFuture(){
        if(this.preemptFuture != null){
            this.preemptFuture.cancel(true);
            this.preemptFuture = null;
        }
    }

    protected void doRedisPreempt(){
        this.getRedisController().preemptSingleMatch(this.getTag());
    }

    @Override
    public void initSelf(String fileName) throws Exception {
        SAXBuilder sb = new SAXBuilder();
        Element root = sb.build(Tools.getInputStreamByFilePath(fileName)).getRootElement();
        serverId = root.getAttribute("id").getIntValue();
        setMachineId(root.getAttribute("machine").getIntValue());
        Attribute debugAttribute = root.getAttribute("debug");

        if (debugAttribute != null) {
            isDebug = debugAttribute.getBooleanValue();
        }

        Attribute logAttribute = root.getAttribute("log");
        if (logAttribute != null) {
            showLog = logAttribute.getBooleanValue();
        }
        log.info("show log is {}",showLog);
    }
}
