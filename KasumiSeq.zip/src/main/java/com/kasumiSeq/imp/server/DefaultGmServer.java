package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.utils.tool.Tools;
import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

public abstract class DefaultGmServer extends DefaultServer {

    protected String pwd = "";

    public DefaultGmServer() throws Exception{
        this("configs/gm.xml");
    }
    public DefaultGmServer(String configFile) throws Exception {
        super(CommConstants.SERVER_TYPE_GM,configFile);
    }

    public DefaultGmServer(String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception {
        super(CommConstants.SERVER_TYPE_GM,selfConfigFile,dbConfigFile,redisConfigFile,commonConfigFile);
    }

    @Override
    public void initSelf(String fileName) throws Exception {
        SAXBuilder sb = new SAXBuilder();
        Element root = sb.build(Tools.getInputStreamByFilePath(fileName)).getRootElement();
        serverId = root.getAttribute("id").getIntValue();
        setMachineId(root.getAttribute("machine").getIntValue());

        Element severElement = root.getChild("server");
        this.tcpPort = severElement.getAttribute("port").getIntValue();
        this.pwd = severElement.getAttribute("pwd").getValue();
        Attribute debugAttr = root.getAttribute("debug");
        if(debugAttr != null){
            isDebug = debugAttr.getBooleanValue();
        }
    }
}
