package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.RedisProperties;
import com.kasumiSeq.core.purchase.PurchaseManager;
import com.kasumiSeq.utils.tool.Tools;
import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

public abstract class DefaultGameServer extends DefaultServer {

    protected ServerSelector matchServerSelector ;

    public DefaultGameServer() throws Exception{
        this("configs/game.xml");
    }

    public DefaultGameServer(String configFile) throws Exception {
        super(CommConstants.SERVER_TYPE_GAME,configFile);
        this.initMatchServerSelector();
    }

    public DefaultGameServer(String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception{
        super(CommConstants.SERVER_TYPE_GAME,selfConfigFile,dbConfigFile,redisConfigFile,commonConfigFile);
        this.initMatchServerSelector();
    }

    @Override
    public void initSelf(String fileName) throws Exception {
        SAXBuilder sb = new SAXBuilder();
        Element root = sb.build(Tools.getInputStreamByFilePath(fileName)).getRootElement();
        this.serverId = root.getAttribute("id").getIntValue();
        setMachineId(root.getAttribute("machine").getIntValue());
        Attribute debugAttribute = root.getAttribute("debug");
        if (debugAttribute != null) {
            this.isDebug = debugAttribute.getBooleanValue();
        }
        Attribute testPayAttribute = root.getAttribute("iosTestPay");
        if (testPayAttribute != null) {
            PurchaseManager.setIosTestPay(testPayAttribute.getBooleanValue());
        }

        Element severElement = root.getChild("server");
        this.tcpPort = severElement.getAttribute("port").getIntValue();

        Element ws = root.getChild("ws");
        this.websocketPort = ws.getAttribute("port").getIntValue();
        this.useWebsocket = ws.getAttribute("useWs").getBooleanValue();
    }

    protected void initMatchServerSelector(){
        this.matchServerSelector = new ServerSelector(RedisProperties.MATCH_SERVER_NAME,this.matchPreemptModel);
        this.matchServerSelector.startCheck();
    }
}
