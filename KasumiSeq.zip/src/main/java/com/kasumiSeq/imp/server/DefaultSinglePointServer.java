/**
 *单点服务器是比较特殊的服务器,主要特征是需要执行某些只能由一个实例完成的工作,如排行榜,活动结算等
 *当然单点服务器也能作为分布式的多点服务器,每个服务器执行相同的操作,但不推荐
 *单点的选择不采用投票的模式,由redis控制,各个服务器在启动的时候进行抢占,先抢到的作为工作服务器
 *在代码编写时,需要注意判断,一般由isWorker属性进行控制,只有在是worker的情况下执行相应的代码
 */
package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.imp.DefaultMessage;
import com.kasumiSeq.io.packet.BasePacketId;
import com.kasumiSeq.io.packet.WritePacket;
import com.kasumiSeq.utils.tool.ThreadPool;
import com.kasumiSeq.utils.tool.Tools;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.util.concurrent.ScheduledFuture;

public abstract class DefaultSinglePointServer extends DefaultServer{
    protected boolean isWorker = false;
    public static int HeartbeatDelay = 1000 * 10;
    private ScheduledFuture<?> preemptFuture = null;
    private boolean isInit;

    public abstract void workDispatch(int workType,Object ... paras);

    public DefaultSinglePointServer() throws Exception {
        this("configs/sp.xml");
    }

    public DefaultSinglePointServer(String selfConfigFile) throws Exception {
        super(CommConstants.SERVER_TYPE_SP,selfConfigFile);
    }

    public DefaultSinglePointServer(String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception {
        super(CommConstants.SERVER_TYPE_SP,selfConfigFile,dbConfigFile,redisConfigFile,commonConfigFile);
    }

    @Override
    public void initSelf(String fileName) throws Exception {
        SAXBuilder sb = new SAXBuilder();
        Element root = sb.build(Tools.getInputStreamByFilePath(fileName)).getRootElement();

        serverId = root.getAttribute("id").getIntValue();
        var debugAttr = root.getAttribute("debug");
        if(debugAttr != null){
            isDebug = debugAttr.getBooleanValue();
        }
        setMachineId(root.getAttribute("machineId").getIntValue());
        startPreemptFuture();
        if (this.singlePointPreemptModel == CommConstants.PreemptMulti) {
            // 如果是多点模式, 初始化提前到这里.
            this.init();
        }
    }

    public void startPreemptFuture(){
        this.stopPreemptFuture();
        if (this.singlePointPreemptModel == CommConstants.PreemptSingle) {
            this.preemptFuture = ThreadPool.SchedulePool.scheduleTask(() -> doRedisPreempt(),
                    getPreemptDelay(), CommProperties.Preempt_Interval);
        }else{//向游戏服发心跳
            this.preemptFuture = ThreadPool.SchedulePool.scheduleTask(() -> sendHeartbeatToAllServer(),
                    HeartbeatDelay, CommProperties.Preempt_Interval);
        }
    }

    /**
     * 单点服需要向所有服发心跳
     */
    protected void sendHeartbeatToAllServer(){
        WritePacket packet = new WritePacket(BasePacketId.REPORT_SP_HEARTBEAT);
        packet.writeUtfStr(this.getTag());
        DefaultMessage message = new DefaultMessage(this.getAllTag(),packet);

        this.pipeline().sendMessage(message);
    }

    public int getPreemptDelay(){
        return  (this.getServerId() - 1)*10*1000;
    }

    public void stopPreemptFuture(){
        if(this.preemptFuture != null){
            this.preemptFuture.cancel(true);
            this.preemptFuture = null;
        }
    }

    protected void doRedisPreempt(){
        int result = this.getRedisController().preemptSingleSp(this.getTag());
        if(result == 1){
            this.isWorker = true;
            if (!isInit) {
                this.isInit = true;
                try {
                    this.init();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }else if(result == 0){
            this.isWorker = false;
            this.isInit = false;
        }
    }

    public boolean isWorker() {
        return isWorker;
    }

    /**
     * 此方法只是建议,实际项目中未必这样做
     * 当单点服的工作模式为单服模式时,只能有一个服务器工作,此处建议把每项需要单点服完成的工作用id进行区分,统一调此方法进行处理
     * 以保证只有当自身为工作服务器或者处于多服模式下才进行任务,以免造成数据冲突,否则需要在每个工作方法之前进行判断
     * @param workType 工作类型
     * @param paras 工作参数
     */
    public void doWork(int workType, Object... paras){
        if(this.isWorker || this.singlePointPreemptModel == CommConstants.PreemptMulti){
            workDispatch(workType,paras);
        }
    }

    /**
     * 本实例是主单点服务或者当由从服务器转化为主服务器时初始化需要的数据
     *
     * 如果在这个方法中加载数据用线程, 禁止做耗时操作.
     */
    public abstract void init();
}
