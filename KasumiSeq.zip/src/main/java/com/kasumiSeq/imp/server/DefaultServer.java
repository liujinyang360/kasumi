package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.RedisProperties;
import com.kasumiSeq.core.Server;
import com.kasumiSeq.core.db.DbPool;
import com.kasumiSeq.core.redis.RedisPool;
import com.kasumiSeq.imp.DefaultRedisController;
import com.kasumiSeq.utils.tool.ThreadPool;
import com.kasumiSeq.utils.tool.Tools;
import com.samus.core.transfer.Dispatcher;
import com.samus.core.transfer.Message;
import com.samus.core.transfer.Pipeline;

import java.io.InputStream;
import java.util.Properties;

public abstract class DefaultServer<R extends DefaultRedisController> extends Server {

    protected static String DefaultDbConfigFile = "configs/dbpool.xml";
    protected static String DefaultRedisConfigFile = "configs/redis.xml";
    protected static String DefaultCommonConfigFile = "configs/comm.properties";

    protected ServerSelector singlePointServerSelector;

    protected Properties properties = null;


    public DefaultServer(int serverType, String selfConfigFile) throws Exception {
        this(serverType, selfConfigFile, DefaultDbConfigFile, DefaultRedisConfigFile, DefaultCommonConfigFile);
    }

    public DefaultServer(int serverType, String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception {
        setInstance(this);
        this.serverType = serverType;
        this.redisController = createRedisController();
        this.init(selfConfigFile, dbConfigFile, redisConfigFile, commonConfigFile);
    }


    public void initDb(String dbConfigFile) throws Exception {
        DbPool.initPool(dbConfigFile);
    }

    public void initRedis(String redisConfigFile) throws Exception {
        InputStream in = Tools.getInputStreamByFilePath(redisConfigFile);
        RedisPool.init(in, ThreadPool.SchedulePool.getScheduledExecutor());
        in.close();
    }

    public void init(String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception {
        this.initDb(dbConfigFile);
        this.initRedis(redisConfigFile);
        this.initSelf(selfConfigFile);
        this.initComm(commonConfigFile);
    }

    public abstract void initSelf(String fileName) throws Exception;

    public abstract R createRedisController();

    public void initComm(String fileName) throws Exception {
        if (this.properties == null) {
            this.properties = new Properties();
            properties.load(Tools.getInputStreamByFilePath(fileName));
        }

        this.matchPreemptModel = Integer.parseInt(properties.getProperty("match.preempt", CommConstants.PreemptSingle + ""));
        this.singlePointPreemptModel = Integer.parseInt(properties.getProperty("single.point.preempt", CommConstants.PreemptSingle + ""));

        this.setTopic(properties.getProperty("pipeline.topic"));
        this.setAllTag(properties.getProperty("pipeline.tag.all", "all"));

        this.initPipeline();

        initSinglePointSelector();
    }

    @Override
    protected void initPipeline() {
        String pipelineServer = properties.getProperty("pipeline.server");

        this.pipeline = new Pipeline(this.getServerId());
        String tags = this.getAllTag()+"&&"+this.getGroupTag()+"&&"+this.getTag();
        try {
            this.pipeline.start(pipelineServer, this.getTopic(), tags, this.getTag(), message -> {
                try{
                    message.readInt();
                    int packetId = message.readUnsignedShort();
                    var readPacket = createPacket(packetId,message.getReadBuf());
                    if(readPacket != null){
                        readPacket.process(message);
                    }
                }catch (Exception ex){
                    ex.printStackTrace();
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public R getRedisController() {
        return (R) super.getRedisController();
    }

    /**
     * 不需要的话方法体重写为空
     */
    protected void initSinglePointSelector() {
        this.singlePointServerSelector = new ServerSelector(RedisProperties.SP_SERVER_NAME, this.singlePointPreemptModel);
        this.singlePointServerSelector.startCheck();
    }
}
