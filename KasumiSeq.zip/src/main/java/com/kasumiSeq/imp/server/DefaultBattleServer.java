package com.kasumiSeq.imp.server;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.utils.tool.Tools;
import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import java.util.ArrayList;
import java.util.HashSet;

public abstract class DefaultBattleServer extends DefaultServer {
    private ArrayList<BattleServerInfo> serverInfoList = new ArrayList<>();
    private ArrayList<BattleServerInfo> tcpServerInfoList = new ArrayList<>();
    private ArrayList<BattleServerInfo> websocketServerInfoList = new ArrayList<>();

    public DefaultBattleServer() throws Exception {
        this("configs/battle.xml");
    }

    public DefaultBattleServer(String selfConfigFile) throws Exception {
        super(CommConstants.SERVER_TYPE_BATTLE,selfConfigFile);
    }

    public DefaultBattleServer(String selfConfigFile, String dbConfigFile, String redisConfigFile, String commonConfigFile) throws Exception {
        super(CommConstants.SERVER_TYPE_BATTLE,selfConfigFile,dbConfigFile,redisConfigFile,commonConfigFile);
    }

    @Override
    public void initSelf(String fileName) throws Exception {
        SAXBuilder sb = new SAXBuilder();
        Element root = sb.build(Tools.getInputStreamByFilePath(fileName)).getRootElement();

        serverId = root.getAttribute("id").getIntValue();
        setMachineId(root.getAttribute("machine").getIntValue());
        Attribute debugAttr = root.getAttribute("debug");
        isDebug = debugAttr != null && debugAttr.getBooleanValue();

        HashSet<Integer> tcpPortSet = new HashSet<>();
        HashSet<Integer> webSocketPortSet = new HashSet<>();
        var serverList = root.getChildren("server");
        for (var server : serverList) {
            BattleServerInfo bi = new BattleServerInfo();
            bi.setId(serverId);
            bi.setHost(server.getAttributeValue("host"));
            bi.setMethod(server.getAttributeValue("method"));
            bi.setPort(server.getAttribute("port").getIntValue());
            var innerHostAttr = server.getAttribute("innerHost");
            if (innerHostAttr != null) {
                bi.setInnerHost(innerHostAttr.getValue());
            }
            if (bi.isTcp()) {
                if (tcpPortSet.contains(bi.getPort())) {
                    bi.setShouldOpen(false);
                } else {
                    tcpPortSet.add(bi.getPort());
                }
                tcpServerInfoList.add(bi);
            } else if (bi.isWebsocket()) {
                if (webSocketPortSet.contains(bi.getPort())) {
                    bi.setShouldOpen(false);
                } else {
                    webSocketPortSet.add(bi.getPort());
                }
                websocketServerInfoList.add(bi);
            } else {
                continue;
            }
            serverInfoList.add(bi);
        }
    }

    public ArrayList<BattleServerInfo> getServerInfoList() {
        return serverInfoList;
    }

    public ArrayList<BattleServerInfo> getTcpServerInfoList() {
        return tcpServerInfoList;
    }

    public ArrayList<BattleServerInfo> getWebsocketServerInfoList() {
        return websocketServerInfoList;
    }
}
