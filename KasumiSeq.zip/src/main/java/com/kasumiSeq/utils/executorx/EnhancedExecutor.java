package com.kasumiSeq.utils.executorx;

import java.util.concurrent.*;

/**
 * 增强的执行器，基于 Java 21 虚拟线程实现
 * 统一了固定线程池和弹性线程池的功能
 * 
 * @author Athena
 */
public class EnhancedExecutor {

    private final ScheduledThreadPoolExecutor scheduler;
    private final ExecutorService executor;
    private final long slowTaskThreshold;

    private static final int DEFAULT_SLOW_PERIOD = 100;

    /**
     * 构造函数
     *
     * @param schedulerThreads 定时调度器线程数量
     * @param slowTaskThreshold 任务执行时间阈值 (ms)
     */
    public EnhancedExecutor(int schedulerThreads, long slowTaskThreshold) {
        // 定时任务调度器（使用虚拟线程）
        this.scheduler = new ScheduledThreadPoolExecutor(schedulerThreads, Thread.ofVirtual().factory());
        // 普通任务执行器（每个任务一个虚拟线程）
        this.executor = Executors.newThreadPerTaskExecutor(Thread.ofVirtual().factory());
        // 慢任务阈值
        this.slowTaskThreshold = slowTaskThreshold < DEFAULT_SLOW_PERIOD ? DEFAULT_SLOW_PERIOD : slowTaskThreshold;
    }

    /**
     * 提交普通任务
     */
    public void execute(Runnable task) {
        executor.execute(new RunWrapper(task, true, slowTaskThreshold));
    }

    /**
     * 提交带延迟的任务
     */
    public ScheduledFuture<?> schedule(Runnable task, long delay, TimeUnit unit) {
        return scheduler.schedule(() -> execute(task), delay, unit);
    }

    /**
     * 提交带延迟的任务（默认单位：毫秒）
     */
    public ScheduledFuture<?> schedule(Runnable task, long delay) {
        return schedule(task, delay, TimeUnit.MILLISECONDS);
    }

    /**
     * 提交定时任务（固定频率）
     */
    public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, long initialDelay, long period, TimeUnit unit) {
        return scheduler.scheduleAtFixedRate(() -> execute(task), initialDelay, period, unit);
    }

    /**
     * 提交定时任务（固定频率，默认单位：毫秒）
     */
    public ScheduledFuture<?> scheduleTask(Runnable task, long initialDelay, long period) {
        return scheduleAtFixedRate(task, initialDelay, period, TimeUnit.MILLISECONDS);
    }

    /**
     * 提交固定延迟任务
     */
    public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, long initialDelay, long delay, TimeUnit unit) {
        return scheduler.scheduleWithFixedDelay(() -> execute(task), initialDelay, delay, unit);
    }

    /**
     * 清理已取消的任务
     */
    public void purge() {
        scheduler.purge();
    }

    /**
     * 获取底层调度器（兼容旧代码）
     */
    public ScheduledThreadPoolExecutor getScheduledExecutor() {
        return scheduler;
    }

    /**
     * 获取底层执行器
     */
    public ExecutorService getExecutor() {
        return executor;
    }

    /**
     * 优雅关闭
     */
    public void shutdown() {
        scheduler.shutdown();
        executor.shutdown();
    }

    /**
     * 强制关闭
     */
    public void shutdownNow() {
        scheduler.shutdownNow();
        executor.shutdownNow();
    }
}

