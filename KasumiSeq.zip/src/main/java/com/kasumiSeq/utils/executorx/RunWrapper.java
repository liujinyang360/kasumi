package com.kasumiSeq.utils.executorx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务包装器：负责异常捕获和慢任务监控
 * 
 * @author Athena
 */
public class RunWrapper implements Runnable {
    private final Runnable task;
    private final boolean monitorExecutionTime;
    private final long slowTaskThreshold;
    private final String callInfo;

    private static final Logger log = LoggerFactory.getLogger(RunWrapper.class);

    public RunWrapper(Runnable task, boolean monitorExecutionTime, long slowTaskThreshold) {
        this.task = task;
        this.monitorExecutionTime = monitorExecutionTime;
        this.slowTaskThreshold = slowTaskThreshold;

        // 记录调用信息
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        if (stack.length >= 3) {
            callInfo = "Called at " + stack[2].getClassName() + "." + stack[2].getMethodName() + "():" + stack[2].getLineNumber();
        } else {
            callInfo = "Call information unavailable";
        }
    }

    @Override
    public void run() {
        long start = System.currentTimeMillis();
        try {
            task.run();
        } catch (Throwable e) {
            log.error(callInfo + " encountered an exception: " + e.getMessage(), e);
            e.printStackTrace();
        } finally {
            if (monitorExecutionTime) {
                long duration = System.currentTimeMillis() - start;
                if (duration > slowTaskThreshold) {
                    log.warn(callInfo + " executed in " + duration + "ms, exceeding threshold of " + slowTaskThreshold + "ms");
                }
            }
        }
    }

    public String getCallInfo() {
        return callInfo;
    }
}

