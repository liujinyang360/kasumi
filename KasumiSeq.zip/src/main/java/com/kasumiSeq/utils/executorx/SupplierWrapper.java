package com.kasumiSeq.utils.executorx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Supplier;

/**
 * Supplier 包装器：负责监控 Supplier 执行时间
 * 
 * @author Athena
 * @param <T> Supplier 返回值类型
 */
public class SupplierWrapper<T> implements Supplier<T> {

    private final Supplier<T> supplier;
    private final long slowTaskThreshold;
    private final String callInfo;

    private static final Logger log = LoggerFactory.getLogger(SupplierWrapper.class);

    /**
     * 构造函数
     * 
     * @param supplier 原始 Supplier
     * @param slowTaskThreshold 慢任务阈值（毫秒）
     */
    public SupplierWrapper(Supplier<T> supplier, long slowTaskThreshold) {
        this.supplier = supplier;
        this.slowTaskThreshold = slowTaskThreshold;
        
        // 记录调用信息
        StackTraceElement[] stack = Thread.currentThread().getStackTrace();
        if (stack.length >= 3) {
            callInfo = "Called at " + stack[2].getClassName() + "." + stack[2].getMethodName() + "():" + stack[2].getLineNumber();
        } else {
            callInfo = "Call information unavailable";
        }
    }

    @Override
    public T get() {
        long start = System.currentTimeMillis();
        try {
            T result = supplier.get();
            long duration = System.currentTimeMillis() - start;
            
            if (duration > slowTaskThreshold) {
                log.warn(callInfo + " executed in " + duration + "ms, exceeding threshold of " + slowTaskThreshold + "ms");
            }
            
            return result;
        } catch (Exception e) {
            log.error(callInfo + " encountered an exception: " + e.getMessage(), e);
            throw e;
        }
    }

    public String getCallInfo() {
        return callInfo;
    }
}

