package com.kasumiSeq.utils.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

public class EsLog {
    private static Logger log = LoggerFactory.getLogger(EsLog.class);
    private static ConcurrentLinkedQueue<EsLog> logQueue = new ConcurrentLinkedQueue<>();
    private String time = "";
    private String level= "";
    private String source= "";
    private String message= "";
    private String server = "";
    public EsLog(String time, String message){
        this.time = time;
        this.message = message;
        this.server = LogManager.serverId;
    }
    public EsLog(String time, String level, String source, String message) {
        this.time = time;
        this.level = level;
        this.source = source;
        this.message = message;
        this.server = LogManager.serverId;
    }
    public static void addLog(EsLog log) {
        logQueue.add(log);
        if (logQueue.size() > LogManager.logMaxSize){
            doSend();
        }
    }
    public static void doSend(){
        ArrayList<EsLog> logList = new ArrayList<>();
        while (!logQueue.isEmpty()) {
            logList.add(logQueue.poll());
        }
        if (logList.isEmpty()) {
            return;
        }
        try {
            ElasticSearch.insertLog(logList);
        }catch (Exception e){
            log.error("insertLog error {}", e.getMessage());
        }
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }
}