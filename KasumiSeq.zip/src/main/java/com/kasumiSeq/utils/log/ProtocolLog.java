package com.kasumiSeq.utils.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @Desciption
 * @Auther alms
 * @Date 2024/6/6 18:35
 **/
public class ProtocolLog {

    private static Logger log = LoggerFactory.getLogger(ProtocolLog.class);
    private static ConcurrentLinkedQueue<ProtocolLog> logQueue = new ConcurrentLinkedQueue<>();
    private String time = "";
    private String level= "";
    private String source= "";
    private String message= "";
    private String server = "";

    private String uid = "";

    private String protocolId = "";

    public ProtocolLog(String time, String message){
        this.time = time;
        this.message = message;
        this.server = LogManager.serverId;
    }

    public ProtocolLog(String uid ,String time, String protocolId, String message) {
        this.uid = uid;
        this.time = time;
        this.protocolId = protocolId;
        this.message = message;
        this.server = LogManager.serverId;
    }

    public ProtocolLog(String time, String level, String source, String message , String uid , String protocolId) {
        this.time = time;
        this.level = level;
        this.source = source;
        this.message = message;
        this.uid = uid;
        this.protocolId = protocolId;
        this.server = LogManager.serverId;
    }


    public static void addLog(ProtocolLog log) {
        logQueue.add(log);
        if (logQueue.size() > LogManager.logMaxSize){
            doSend();
        }
    }
    public static void doSend(){
        ArrayList<ProtocolLog> logList = new ArrayList<>();
        while (!logQueue.isEmpty()) {
            logList.add(logQueue.poll());
        }
        if (logList.isEmpty()) {
            return;
        }
        try {
            ElasticSearch.insertProtocolLog(logList);
        }catch (Exception e){
            log.error("insertLog error {}", e.getMessage());
        }
    }


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getProtocolId() {
        return protocolId;
    }

    public void setProtocolId(String protocolId) {
        this.protocolId = protocolId;
    }
}
