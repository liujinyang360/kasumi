package com.kasumiSeq.utils.log;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.BulkRequest;
import co.elastic.clients.elasticsearch.core.BulkResponse;
import co.elastic.clients.elasticsearch.core.bulk.BulkOperation;
import co.elastic.clients.elasticsearch.core.bulk.IndexOperation;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import co.elastic.clients.util.ObjectBuilder;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Function;


public class ElasticSearch {

    private static final Logger log = LoggerFactory.getLogger(ElasticSearch.class);

    public static ElasticsearchClient client;

    public static ElasticsearchClient protocolClient;

    public static ElasticsearchClient getElasticsearchClient(String userName,String password,String host,int port) {
//        ElasticsearchTransport transport = getElasticsearchTransport(userName,password,host,port);
        ElasticsearchTransport transport = getElasticsearchTransport(host,port);
        return new ElasticsearchClient(transport);
    }

    public static ElasticsearchTransport getElasticsearchTransport(String userName, String password, String host, int port) {
        CredentialsProvider credentialsProvider =
                new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
                new UsernamePasswordCredentials(userName, password));//配置用户名密码
        RestClient restClient = RestClient.builder(
                        new HttpHost(host, port)) //配置路径 端口
                .setHttpClientConfigCallback(httpAsyncClientBuilder ->
                        httpAsyncClientBuilder.setDefaultCredentialsProvider(credentialsProvider))
                .build();
        return new RestClientTransport(
                restClient, new JacksonJsonpMapper());
    }



    public static ElasticsearchTransport getElasticsearchTransport(String host, int port) {
//        CredentialsProvider credentialsProvider =
//                new BasicCredentialsProvider();
//        credentialsProvider.setCredentials(AuthScope.ANY,
//                new UsernamePasswordCredentials(userName, password));//配置用户名密码
        RestClient restClient = RestClient.builder(
                        new HttpHost(host, port)) //配置路径 端口
                .build();
        return new RestClientTransport(
                restClient, new JacksonJsonpMapper());
    }

    public static void insertLog(ArrayList<EsLog> logList) throws IOException {
        BulkRequest.Builder br = new BulkRequest.Builder();
        for (EsLog log : logList) {
//            br.operations(
//                    op -> op.index(index -> index
////                            .index(LogManager.index).document(log).pipeline(LogManager.pipeline))
//                            .index(LogManager.curIndex).document(log))
//            );
            br.operations(new Function<BulkOperation.Builder, ObjectBuilder<BulkOperation>> (){

                @Override
                public ObjectBuilder<BulkOperation> apply(BulkOperation.Builder builder) {
                  return builder.index(new Function<IndexOperation.Builder<EsLog>, ObjectBuilder<IndexOperation<EsLog>>>() {
                      @Override
                      public ObjectBuilder<IndexOperation<EsLog>> apply(IndexOperation.Builder<EsLog> esLogBuilder) {
                          return esLogBuilder.index(LogManager.curIndex).document(log);
                      }
                  });
                }
            });

        }
        BulkResponse bulk = client.bulk(br.build());
        if (bulk.errors()) {
            log.info(String.valueOf(bulk));
        }
    }


    public static void insertProtocolLog(ArrayList<ProtocolLog> logList) throws IOException {
        BulkRequest.Builder br = new BulkRequest.Builder();
        for (ProtocolLog log : logList) {
//            br.operations(
//                    op -> op.index(index -> index
////                            .index(LogManager.index).document(log).pipeline(LogManager.pipeline))
//                            .index(LogManager.curIndex).document(log))
//            );
            br.operations(new Function<BulkOperation.Builder, ObjectBuilder<BulkOperation>> (){

                @Override
                public ObjectBuilder<BulkOperation> apply(BulkOperation.Builder builder) {
                    return builder.index(new Function<IndexOperation.Builder<ProtocolLog>, ObjectBuilder<IndexOperation<ProtocolLog>>>() {
                        @Override
                        public ObjectBuilder<IndexOperation<ProtocolLog>> apply(IndexOperation.Builder<ProtocolLog> esLogBuilder) {
                            return esLogBuilder.index(LogManager.CurProtocolIndex).document(log);
                        }
                    });
                }
            });

        }
        BulkResponse bulk = client.bulk(br.build());
        if (bulk.errors()) {
            log.info(String.valueOf(bulk));
        }
    }
//
//    public static void insertProtocolLog(ArrayList<ProtocolLog> logList) throws IOException {
//        BulkRequest.Builder br = new BulkRequest.Builder();
//        for (var log : logList) {
//            br.operations(
//                    op -> op.index(index -> index
////                            .index(LogManager.index).document(log).pipeline(LogManager.pipeline))
//                            .index(ProtocolLogManager.curIndex).document(log))
//            );
//        }
//        BulkResponse bulk = protocolClient.bulk(br.build());
//        if (bulk.errors()) {
//            log.info(String.valueOf(bulk));
//        }
//    }
}