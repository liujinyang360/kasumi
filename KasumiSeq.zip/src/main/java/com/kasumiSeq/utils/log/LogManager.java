package com.kasumiSeq.utils.log;


import com.kasumiSeq.core.Server;
import com.kasumiSeq.utils.tool.ThreadPool;
import com.kasumiSeq.utils.tool.Time;
import com.kasumiSeq.utils.tool.Tools;
import io.krakens.grok.api.Grok;
import io.krakens.grok.api.GrokCompiler;
import io.krakens.grok.api.Match;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.regex.Pattern;


public class LogManager {
    private static final Logger log = LoggerFactory.getLogger(LogManager.class);

    public static String timeRegex = "^[0-9]{2}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3}";
    public static String sourceRegex = "[a-zA-Z.<>():0-9]*";
    public static String grokPattern = "%{DATE:time} %{SPACE}%{LOGLEVEL:level} %{SOURCE:source} %{GREEDYDATA:message}";
    public static String timeKey = "time";
    public static String levelKey = "level";
    public static String sourceKey = "source";
    public static String messageKey = "message";

    public static ScheduledFuture<?> esLogFuture;


    /*特殊处理str */
    public static StringBuilder exceptionStr = new StringBuilder();
    public static String lastTime = "";

    /* Grok */
    public static Grok grok;
    public static Pattern pattern;

    /* ElasticSearch配置*/
    public static String host;
    public static String port;
    public static String userName;
    public static String password;
    public static String index;
    public static String protocolIndex;
    public static String CurProtocolIndex;
    public static String curIndex;
    public static int curDay;
    public static String pipeline;
    //会有默认 -- 是否设置看情况
    public static String fileName;
    public static String fileFilterType;
    public static String serverId;
    public static int logMaxSize = 100;
    public static boolean initEnd = false;


    public static void init() {
        GrokCompiler grokCompiler = GrokCompiler.newInstance();
        grokCompiler.registerDefaultPatterns();
        grokCompiler.register("DATE", timeRegex);
        grokCompiler.register("SOURCE", sourceRegex);
        grok = grokCompiler.compile(grokPattern);
        pattern = Pattern.compile(timeRegex);
        try {
            SAXBuilder sb = new SAXBuilder();
            Element root = sb.build(Tools.getInputStreamByFilePath("configs/log.xml")).getRootElement();
            logMaxSize = root.getAttribute("sendNum").getIntValue();

            Element esElement = root.getChild("elasticSearch");
            host = esElement.getAttribute("host").getValue();
            port = esElement.getAttribute("port").getValue();
            userName = esElement.getAttribute("userName").getValue();
            password = esElement.getAttribute("password").getValue();
            index = esElement.getAttribute("index").getValue();
            protocolIndex = esElement.getAttribute("protocolIndex").getValue();
            checkRefreshIndex();
            pipeline = esElement.getAttribute("pipeline").getValue();

            Element fileElement = root.getChild("file");
            fileName = fileElement.getAttribute("fileName").getValue();
            fileFilterType = fileElement.getAttribute("filterType").getValue();
            serverId = Server.instance().getTag();
            initEnd = true;
            ElasticSearch.client = ElasticSearch.getElasticsearchClient(userName,password,host,Integer.parseInt(port));
            FileListener.listen();
            esLogFuture  = ThreadPool.SchedulePool.scheduleTask(LogManager::esLogCheck, 1000 * 60 , 1000 * 60);
            log.info("ElasticSearch Init Success");
        } catch (Exception e) {
            cancel();
            log.info("ElasticSearch Init Error ! ! !");
            e.printStackTrace();
        }
    }

    public static void cancel(){
        if (esLogFuture != null && !esLogFuture.isCancelled()){
            esLogFuture.cancel(true);
            esLogFuture = null;
        }
    }


    public static void convertLog(String str) {
        if (isLogs(str)) {
            if (exceptionStr.length() > 0) {
                exceptionStr.deleteCharAt(exceptionStr.length() - 1);
                EsLog.addLog(new EsLog(lastTime, exceptionStr.toString()));
                exceptionStr = new StringBuilder();
            }
            Match grokMatch = grok.match(str);
            Map<String, Object> resultMap = grokMatch.capture();
            lastTime = resultMap.containsKey(timeKey) ? resultMap.get(timeKey).toString() : lastTime;
            EsLog.addLog(new EsLog(lastTime, resultMap.getOrDefault(levelKey,"").toString(), resultMap.getOrDefault(sourceKey,"").toString(), resultMap.getOrDefault(messageKey,"").toString()));
        } else {
            exceptionStr.append(str).append("\n");
        }
    }

    public static boolean isLogs(String str) {
        return pattern.matcher(str).find();
    }

    public static void checkRefreshIndex(){
        int tempDay = Time.getDay(LocalDateTime.ofEpochSecond(Time.getCurrentSeconds(), 0, ZoneOffset.ofHours(+8)));
        if (curDay == tempDay){
            return;
        }
        curDay = tempDay;
        curIndex = index + curDay;
        CurProtocolIndex = protocolIndex + curDay;
        log.info("Es CurIndex = {} , CurProtocolIndex = {}",curIndex , CurProtocolIndex);
    }


    public static void addProtocolLog(ProtocolLog log){
        ProtocolLog.addLog(log);
    }

    public static void esLogCheck(){
        checkRefreshIndex();
        EsLog.doSend();
        ProtocolLog.doSend();
    }
}
