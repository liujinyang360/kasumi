package com.kasumiSeq.utils.detector;

public interface Detector {
    void dealResult(String message);
}
