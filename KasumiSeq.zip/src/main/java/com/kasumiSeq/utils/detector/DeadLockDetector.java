package com.kasumiSeq.utils.detector;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;

public abstract class DeadLockDetector implements Runnable, Detector {

    private boolean needCheck = true;

    @Override
    public void run() {
        if(!needCheck){
            return;
        }
        try {
            ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
            long[] deadLockThreads = threadMXBean.findDeadlockedThreads();
            if(deadLockThreads != null && deadLockThreads.length > 0){
                needCheck = false;
                StringBuffer sb = new StringBuffer();
                for(int i = 0; i < deadLockThreads.length;i++){
                    ThreadInfo threadInfo = threadMXBean.getThreadInfo(deadLockThreads[i]);
                    sb.append(threadInfo.getThreadName()).append("--");
                }
                dealResult(sb.toString());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
