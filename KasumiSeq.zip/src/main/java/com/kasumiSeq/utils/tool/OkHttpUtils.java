package com.kasumiSeq.utils.tool;

import com.google.gson.JsonObject;
import com.kasumiSeq.utils.firebase.FirebaseManager;
import com.kasumiSeq.utils.firebase.FirebaseResult;
import com.kasumiSeq.utils.firebase.FirebaseUnit;
import okhttp3.*;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * okhttp 写的
 * @author Crazy
 */
public final class OkHttpUtils {

    private static final String Content_Type_Header_Name = "Content-Type";

    private static final String Content_Type_Urlencoded = "application/x-www-form-urlencoded";

    private static final String Content_Type_Json = "application/json";

    private static final long ConnectTime = 60 * 1000;
    private static final long ReadTimeOut = 60 * 1000;


    private static OkHttpClient[] okHttpClientArr = new OkHttpClient[20];
    static {
        initOkHttpClient();
    }

//    private static final Dispatcher dispatcher = new Dispatcher();
//    private static final ConnectionPool connectionPool = new ConnectionPool(200,5, TimeUnit.SECONDS);

//    private static OkHttpClient httpClient;
//
//    static {
//        dispatcher.setMaxRequests(10000);
//        dispatcher.setMaxRequestsPerHost(1000);
//        httpClient =
//                new OkHttpClient.Builder()
//                        .dns(new JDns())
//                        .dispatcher(dispatcher)
//                        .connectionPool(connectionPool)
//                        .connectTimeout(ConnectTime,TimeUnit.MILLISECONDS)
//                        .readTimeout(ReadTimeOut,TimeUnit.MILLISECONDS)
//                        .build();
//    }

    private static final Logger log = LoggerFactory.getLogger(OkHttpUtils.class);

    public static <T> void doHttpRequest(String url, T params, String method, Map<String, String> headers, OkHttpCallback cb) {
//        OkHttpClient okHttpClient =
//                new OkHttpClient.Builder()
//                        .dns(new JDns())
//                        .dispatcher(dispatcher)
//                        .connectionPool(connectionPool)
////                        .connectTimeout(50, TimeUnit.SECONDS)
//                        .connectTimeout(ConnectTime,TimeUnit.MILLISECONDS)
//                        .readTimeout(ReadTimeOut,TimeUnit.MILLISECONDS)
//                        .build();

        byte[] p = "".getBytes();
        if (params != null) {
            if (params instanceof byte[] bs) {
                p = bs;
            } else {
                p = params.toString().getBytes();
            }
        }
        RequestBody requestBody = RequestBody.create(p);
        Request.Builder requestBuilder = new Request.Builder().url(url);
        if (headers == null || !headers.containsKey(Content_Type_Header_Name)) {
            requestBuilder.header(Content_Type_Header_Name, Content_Type_Urlencoded);
        }
        if (headers != null && headers.size() > 0) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                requestBuilder.addHeader(entry.getKey(), entry.getValue());
            }
        }
        if (method != null) {
            if ("post".equalsIgnoreCase(method)) {
                requestBuilder.post(requestBody);
            }
            if ("PUT".equalsIgnoreCase(method)) {
                requestBuilder.put(requestBody);
            }
        }
        Request request = requestBuilder.build();
        getClient().newCall(request).enqueue(cb);
    }



    public static JsonObject createFirebaseMessage(FirebaseUnit unit){
        JsonObject notification = new JsonObject();
        notification.addProperty("title",unit.title());
        notification.addProperty("body", unit.body());

        JsonObject apns = new JsonObject();
        JsonObject apnsPayload = new JsonObject();
        JsonObject aps = new JsonObject();
        aps.addProperty("badge",1);
        apnsPayload.add("aps", aps);
        apns.add("payload", apnsPayload);

        JsonObject dataObject = new JsonObject();
        dataObject.addProperty("time_stamp",""+ Time.getCurrentSeconds());

        JsonObject message = new JsonObject();
        JsonObject messageBody = new JsonObject();
        messageBody.add("notification", notification);
        messageBody.addProperty("token", unit.token());// 替换为你的设备令牌
        messageBody.add("apns",apns);
        messageBody.add("data",dataObject);
        message.add("message", messageBody);
//        System.out.println(message);
        return message;
    }

    public static void doFirebaseRequest(FirebaseResult result, String accessToken) {
        var unit = result.getFirebaseUnit();

        var message = createFirebaseMessage(unit);

        // 构建 HTTP 请求
        RequestBody requestBody = RequestBody.create(
                message.toString(),
                MediaType.parse("application/json; charset=utf-8")
        );


        Request request = new Request.Builder()
                .url(FirebaseManager.FIREBASE_API_URL)
                .post(requestBody)
                .addHeader("Authorization", "Bearer " + accessToken)
                .addHeader("Content-Type", "application/json")
                .build();

        getClient().newCall(request).enqueue(result);
    }

    public static void doFirebaseRequest(FirebaseResult result) {
        var unit = result.getFirebaseUnit();

        var message = createFirebaseMessage(unit);
        // 构建 HTTP 请求
        RequestBody requestBody = RequestBody.create(
                message.toString(),
                MediaType.parse("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
                .url(FirebaseManager.FIREBASE_API_URL)
                .post(requestBody)
                .addHeader("Authorization", "Bearer " + FirebaseManager.getAccessToken())
                .addHeader("Content-Type", "application/json")
                .build();

        getClient().newCall(request).enqueue(result);
    }


    public static void doFirebaseRequest(FirebaseUnit unit, String accessToken) {

        var message = createFirebaseMessage(unit);

        System.out.println(message.toString());
        // 构建 HTTP 请求
        RequestBody requestBody = RequestBody.create(
                message.toString(),
                MediaType.parse("application/json; charset=utf-8")
        );


        Request request = new Request.Builder()
                .url("https://fcm.googleapis.com/v1/projects/merge2d/messages:send")
                .post(requestBody)
                .addHeader("Authorization", "Bearer " + accessToken)
                .addHeader("Content-Type", "application/json")
                .build();

        getClient().newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                log.info(response.body().string());
            }
        });
    }

    public static <T> Response doHttpRequestSync(String url, T params, String method, Map<String, String> headers) throws Exception {
//        OkHttpClient okHttpClient =
//                new OkHttpClient.Builder()
//                        .dns(new JDns())
//                        .dispatcher(dispatcher)
//                        .connectionPool(connectionPool)
////                        .connectTimeout(50, TimeUnit.SECONDS)
//                        .connectTimeout(Duration.ofMillis(ConnectTime))
//                        .build();

        byte[] pb = "".getBytes();
        if (params != null) {
            if (params instanceof byte[] bs) {
                pb = bs;
            } else {
                pb = params.toString().getBytes();
            }
        }

        RequestBody requestBody = RequestBody.create(pb);
        Request.Builder requestBuilder = new Request.Builder().url(url);
        if (headers == null || !headers.containsKey(Content_Type_Header_Name)) {
            requestBuilder.header(Content_Type_Header_Name, Content_Type_Urlencoded);
        }
        if (headers != null && headers.size() > 0) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                requestBuilder.addHeader(entry.getKey(), entry.getValue());
            }
        }
        if (method != null) {
            if ("post".equalsIgnoreCase(method)) {
                requestBuilder.post(requestBody);
            }
            if ("PUT".equalsIgnoreCase(method)) {
                requestBuilder.put(requestBody);
            }
        }
        Request request = requestBuilder.build();
        Response execute = getClient().newCall(request).execute();
        return execute;
    }

    private static OkHttpClient getClient(){
        return okHttpClientArr[Rnd.get(okHttpClientArr.length)];
    }


    private static void initOkHttpClient() {

        for (int i = 0; i < okHttpClientArr.length; i++) {
            Dispatcher dispatcher = new Dispatcher();
            dispatcher.setMaxRequests(64);
            dispatcher.setMaxRequestsPerHost(32);

            ConnectionPool connectionPool = new ConnectionPool(200, 5, TimeUnit.MINUTES);

            okHttpClientArr[i] = new OkHttpClient.Builder()
                    .dns(new JDns())
                    .dispatcher(dispatcher)
                    .connectionPool(connectionPool)
                    .readTimeout(5 , TimeUnit.MINUTES)
                    .writeTimeout(5 , TimeUnit.MINUTES)
                    .connectTimeout(5 , TimeUnit.MINUTES)
                    .build();
        }
    }
}


































