package com.kasumiSeq.utils.tool;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class FileUtils {

    /**
     * 直接覆盖
     */
    public static void write(String path, byte[] content, boolean isSync) throws IOException {
        StandardOpenOption[] options = new StandardOpenOption[isSync ? 4 : 3];
        options[0] = StandardOpenOption.CREATE;
        options[1] = StandardOpenOption.TRUNCATE_EXISTING;
        options[2] = StandardOpenOption.WRITE;
        if (isSync) {
            options[3] = StandardOpenOption.SYNC;
        }
        Files.write(Paths.get(path), content, options);
    }


    public static byte[] read(String path) throws IOException {
        return Files.readAllBytes(Paths.get(path));
    }

}
