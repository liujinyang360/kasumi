package com.kasumiSeq.utils.tool;



import com.kasumiSeq.modules.HttpResult;

import javax.net.ssl.SSLParameters;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HttpUtils {

    private static int connectTimeOut = 50 * Time.SECOND_TIME;
    private static SSLParameters sslParameters = new SSLParameters();

    private static final String Content_Type_Header_Name = "Content-Type";

    private static final String Content_Type_Urlencoded = "application/x-www-form-urlencoded";

    private static final String Content_Type_Json = "application/json";

    static {
        sslParameters.setProtocols(new String[]{"TLSv1", "TLSv1.1", "TLSv1.2"});
    }

    public static void get(String url,Map<String,String> headers, HttpResult httpResult){
        HttpClient client = HttpClient.newBuilder().sslParameters(sslParameters).connectTimeout(Duration.ofMillis(connectTimeOut)).build();

        HttpRequest.Builder builder =  HttpRequest.newBuilder().GET().uri(URI.create(url));
        if(headers != null){
            if(!headers.containsKey(Content_Type_Header_Name)){
                headers.put(Content_Type_Header_Name,Content_Type_Urlencoded);
            }
        }else{
            headers = new HashMap<>();
            headers.put(Content_Type_Header_Name,Content_Type_Urlencoded);
        }
        for (var it = headers.entrySet().iterator(); it.hasNext(); ) {
            var entry = it.next();
            builder.header(entry.getKey(), entry.getValue());
        }
        HttpRequest request = builder.build();
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).whenComplete((resp, e) -> {
            httpResult.doResult(e,resp);
        });
    }


    public static <T> void post (String url, T params, Map<String,String> headers, HttpResult httpResult){
        HttpClient client = HttpClient.newBuilder().sslParameters(sslParameters).connectTimeout(Duration.ofMillis(connectTimeOut)).build();

        HttpRequest.Builder builder =  HttpRequest.newBuilder().POST(ofFormData(params)).uri(URI.create(url));
        if(headers != null){
            if(!headers.containsKey(Content_Type_Header_Name)){
                headers.put(Content_Type_Header_Name,Content_Type_Urlencoded);
            }
        }else{
            headers = new HashMap<>();
            headers.put(Content_Type_Header_Name,Content_Type_Urlencoded);
        }

        for(var it = headers.entrySet().iterator();it.hasNext();){
            var entry = it.next();
            builder.header(entry.getKey(),entry.getValue());
        }

        HttpRequest request = builder.build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).whenComplete((resp, e) -> {
            httpResult.doResult(e,resp);
        });
    }

    public static <T> String syncPost (String url, T params, Map<String,String> headers) throws Exception{
        HttpClient client = HttpClient.newBuilder().sslParameters(sslParameters).connectTimeout(Duration.ofMillis(connectTimeOut)).build();

        HttpRequest.Builder builder =  HttpRequest.newBuilder().POST(ofFormData(params)).uri(URI.create(url));
        if(headers != null){
            if(!headers.containsKey(Content_Type_Header_Name)){
                headers.put(Content_Type_Header_Name,Content_Type_Urlencoded);
            }
        }else{
            headers = new HashMap<>();
            headers.put(Content_Type_Header_Name,Content_Type_Urlencoded);
        }

        for(var it = headers.entrySet().iterator();it.hasNext();){
            var entry = it.next();
            builder.header(entry.getKey(),entry.getValue());
        }

        HttpRequest request = builder.build();

        var resp = client.send(request, HttpResponse.BodyHandlers.ofString());
        return resp.body();
    }

    public static void jsonPost (String url, String json, Map<String,String> headers, HttpResult httpResult){
        HttpClient client = HttpClient.newBuilder().sslParameters(sslParameters).connectTimeout(Duration.ofMillis(connectTimeOut)).build();

        HttpRequest.Builder builder =  HttpRequest.newBuilder().POST(HttpRequest.BodyPublishers.ofString(json,StandardCharsets.UTF_8)).uri(URI.create(url));
        if(headers != null){
            headers.put(Content_Type_Header_Name, Content_Type_Json);
        }else{
            headers = new HashMap<>();
            headers.put(Content_Type_Header_Name, Content_Type_Json);
        }
        for(var it = headers.entrySet().iterator();it.hasNext();){
            var entry = it.next();
            builder.header(entry.getKey(),entry.getValue());
        }

        HttpRequest request = builder.build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).whenComplete((resp, e) -> {
            httpResult.doResult(e,resp);
        });
    }

    public static <T> HttpRequest.BodyPublisher ofFormData(T data) {
        String paras = "";
        if(data instanceof Map map){
            var builder = new StringBuilder();
            for(Iterator it = map.entrySet().iterator();it.hasNext();){
                Map.Entry entry = (Map.Entry)it.next();
                if (builder.length() > 0) {
                    builder.append("&");
                }
                builder.append(URLEncoder.encode(entry.getKey().toString(), StandardCharsets.UTF_8));
                builder.append("=");
                builder.append(URLEncoder.encode(entry.getValue().toString(), StandardCharsets.UTF_8));
            }
            paras = builder.toString();
        }else{
            paras = data.toString();
        }
        return HttpRequest.BodyPublishers.ofString(paras);
    }

    public static int getConnectTimeOut() {
        return connectTimeOut;
    }

    public static void setConnectTimeOut(int connectTimeOut) {
        HttpUtils.connectTimeOut = connectTimeOut;
    }
}