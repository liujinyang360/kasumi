package com.kasumiSeq.utils.tool;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;

public interface OkHttpCallback extends Callback {

    void doResponse(@NotNull Call call, @NotNull Response response) throws IOException;

    void doFailure(@NotNull Call call, @NotNull IOException e);
    @Override
    default void onFailure(@NotNull Call call, @NotNull IOException e) {
        doFailure(call,e);
    }

    @Override
    default void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        doResponse(call,response);
        response.close();
    }
}
