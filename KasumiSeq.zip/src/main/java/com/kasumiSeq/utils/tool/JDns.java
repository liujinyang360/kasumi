package com.kasumiSeq.utils.tool;

import okhttp3.Dns;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 先试试java版本的
 *
 * @author Crazy
 */
public class JDns implements Dns {
    private static final Logger log = LoggerFactory.getLogger(JDns.class);

    @NotNull
    @Override
    public List<InetAddress> lookup(@NotNull String hostname) throws UnknownHostException {
        List<InetAddress> lookup = Dns.SYSTEM.lookup(hostname);
        //log.info("dns filter. lookup = {}", lookup);
        return lookup.stream().filter(Inet4Address.class::isInstance).collect(Collectors.toList());
    }
}
