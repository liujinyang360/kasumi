package com.kasumiSeq.utils.tool;

public interface BinarySearchUnit<K> {

    boolean isMatch(K key);
    boolean leftMove(K key);
    boolean rightMove(K key);

}
