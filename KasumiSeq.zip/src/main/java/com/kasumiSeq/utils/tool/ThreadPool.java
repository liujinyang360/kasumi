package com.kasumiSeq.utils.tool;


import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.utils.executorx.EnhancedExecutor;
import com.kasumiSeq.utils.executorx.RunWrapper;
import com.kasumiSeq.utils.executorx.SupplierWrapper;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;

/**
 * 线程池（基于 Java 21 虚拟线程实现）
 * @author Athena
 */
public class ThreadPool {

    /**主工作线程池，主要处理异步操作（使用虚拟线程，无需队列配置）*/
    public static EnhancedExecutor WorkerPool = new EnhancedExecutor(CommConstants.Worker_Thread_Number, CommProperties.SlowExecuteInterval);
    
    /**定时器线程池，主要处理定时操作*/
    public static EnhancedExecutor SchedulePool = new EnhancedExecutor(CommConstants.Schedule_Thread_Number, CommProperties.SlowExecuteInterval);
    
    /**邮件发送线程池，因邮件发送耗时
     * 所以定义线程池数量较小
     * 以免阻塞其他任务
     * */

    /**
     * runnable回调方法
     * @param run
     * @return 执行完的future
     */
    public static CompletableFuture<Void> runAsync(Runnable run){
        return CompletableFuture.runAsync(new RunWrapper(run, true, CommProperties.SlowExecuteInterval), WorkerPool.getExecutor());
    }

    /**
     * 带返回参数的回调方法
     * @param <T>
     * @param supplier
     * @return 执行完的future
     */
    public static <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier){
        return CompletableFuture.supplyAsync(new SupplierWrapper<>(supplier, CommProperties.SlowExecuteInterval), WorkerPool.getExecutor());
    }

    public static CompletableFuture<Void> runAsync(Runnable run, Executor executor) {
        return CompletableFuture.runAsync(new RunWrapper(run, true, CommProperties.SlowExecuteInterval), executor);
    }

}
