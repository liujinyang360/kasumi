package com.kasumiSeq.utils.weight;

import com.kasumiSeq.utils.tool.BinarySearchUnit;

/**
 * 权重元素类,根据权重获得数据
 * @author Athena
 *
 * @param <T> 任意类型
 */
public class Weight<T> implements Comparable<Weight<T>>, BinarySearchUnit<Long> {

	private T element;
	private int weight;
	private long minWeight;
	private long maxWeight;

	/**
	 * 
	 * @param weight 所占权重
	 * @param t 任意类型
	 */
	public Weight(int weight ,T t ){
		this.weight = weight;
		this.element = t;
	}
	
	private Weight(int weight){
		this.weight = weight;
	}
	
	public T getElement() {
		return element;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public long getMinWeight() {
		return minWeight;
	}

	public void setMinWeight(long minWeight) {
		this.minWeight = minWeight;
	}

	public long getMaxWeight() {
		return maxWeight;
	}

	public void setMaxWeight(long maxWeight) {
		this.maxWeight = maxWeight;
	}

	public Weight<T> cloneWeight(){
		Weight<T> wt = new Weight<>(this.getWeight());
		wt.element = this.element;
		return wt;
	}

	/**
	 * 按权重倒序排列,大概率会先选中前面的数据
	 */
	@Override
	public int compareTo(Weight<T> o) {
		return o.getWeight() - this.getWeight() ;
	}

	@Override
	public boolean isMatch(Long key) {
		return key >= this.minWeight && key <= maxWeight;
	}

	@Override
	public boolean leftMove(Long key) {
		return key < this.minWeight;
	}

	@Override
	public boolean rightMove(Long key) {
		return key > this.maxWeight;
	}
}
