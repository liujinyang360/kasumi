package com.kasumiSeq.utils.firebase;


/**
 * firebase消息对象
 * @author Athena
 */

public record FirebaseUnit(String token, String title, String body) {

}
