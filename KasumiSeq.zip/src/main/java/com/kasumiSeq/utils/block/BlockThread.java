package com.kasumiSeq.utils.block;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * BlockThread 用来解决多线程环境下需要顺序执行的操作。
 * 将需要执行的方法通过唯一的 id（一般为用户 id）分发到对应的任务队列中，
 * 从而确保同一 id 的任务在同一个线程中按队列顺序执行。
 *
 * <p>在 Java 21 中，利用虚拟线程可以使线程创建更加轻量，
 * 本实现中每个队列由一个专属的虚拟线程不断轮询并执行任务。</p>
 *
 * <p>注意：传入的 Runnable 方法内部不要再使用加锁操作，否则可能会产生死锁风险！</p>
 *
 * @author Athena
 */
public class BlockThread implements Runnable {
    // 存放所有的 BlockThread 实例（每个实例对应一个任务队列和一个虚拟线程）
    private static BlockThread[] blockThreads;
    private static int threadSize;
    private static boolean isInit = false;

    // 每个 BlockThread 持有一个任务队列，任务以 Runnable 的形式提交
    private final LinkedBlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<>();

    /**
     * 使用默认线程数（即可用处理器数量）进行初始化。
     *
     * @throws Exception 如果线程数不合法则抛出异常
     */
    public static void init() throws Exception {
        init(Runtime.getRuntime().availableProcessors() * 4);
    }

    /**
     * 添加一个任务。
     *
     * @param finalId 用于确定任务所属队列的唯一 id（例如用户 id）
     * @param run     需要执行的任务
     */
    public static void addTask(long finalId, Runnable run) {
        if (!isInit) {
            try {
                init();
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
        // 保证 id 为非负值后取模，确定所属队列下标
        long hash = finalId < 0 ? -finalId : finalId;
        int index = (int) (hash % threadSize);
        blockThreads[index].add(run);
    }

    /**
     * 初始化 BlockThread 集合，并为每个 BlockThread 分配一个专属的虚拟线程来处理任务队列。
     *
     * @param threads 指定线程数（即任务队列数），必须大于 0
     * @throws Exception 如果线程数小于等于 0 则抛出异常
     */
    public static synchronized void init(int threads) throws Exception {
        if (isInit) {
            return;
        }
        if (threads <= 0) {
            throw new Exception("thread size must > 0");
        }

        blockThreads = new BlockThread[threads];
        threadSize = threads;
        for (int i = 0; i < threads; i++) {
            // 创建 BlockThread 实例（即任务队列的处理对象）
            BlockThread blockThread = new BlockThread();
            blockThreads[i] = blockThread;
            // 使用 Java 21 提供的虚拟线程为每个 BlockThread 分配专属线程
            Thread vt = Thread.ofVirtual()
                    .name("BlockThread-" + i)
                    .unstarted(blockThread);
            vt.start();
        }
        isInit = true;
    }

    /**
     * 将任务添加到当前 BlockThread 的任务队列中。
     *
     * @param run 需要执行的任务
     */
    private void add(Runnable run) {
        taskQueue.add(run);
    }

    /**
     * 线程的主循环，不断从任务队列中取出任务并执行。
     * 如果队列为空则会阻塞等待新的任务到来。
     */
    @Override
    public void run() {
        while (true) {
            try {
                // 使用 take() 方法阻塞等待新任务
                var task = taskQueue.take();
                task.run();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
