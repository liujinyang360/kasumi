package com.kasumiSeq.conf;


/**
 * 绝大多数项目用到的变量
 * 可在自己的项目中对值进行修改
 * 注意:不是修改本文件的代码默认值,而是在其他项目中修改属性值
 */
public class CommProperties {
    public static int SlowExecuteInterval = 200;
    public static int FutureCheckTime = 500;

    public static int DefaultTimeOut = 15 * 1500;

    /**pc平台*/
    public static int Os_Pc = 0;
    /**ios平台*/
    public static int Os_Ios = 1;
    /**安卓平台*/
    public static int Os_Android = 2;

    //下线方式
    /**正常下线*/
    public static int LEAVE_TYPE_NORMAL = 1;
    /**重复登录下线*/
    public static int LEAVE_TYPE_RELOGIN = 2;
    /**超时下线*/
    public static int LEAVE_TYPE_TIMEOUT = 3;

    //账户切换绑定方式
    /**账户绑定*/
    public static int ACCOUNT_BIND = 1;
    /**账户切换*/
    public static int ACCOUNT_SWITCH = 2;

    /**
     * 正式服（正式环境）
     */
    public static int OrderVerify_Product_Success = 100;
    /**
     * 苹果正式服的测试订单
     */
    public static int OrderVerify_ProductTest_Success_Ios = 99;
    /**
     * 非消耗品恢复
     */
    public static int OrderVerify_Success_IosNonExpend = 98;

    public static int Purchase_Success_Type = 100;

    /**游戏超时时间*/
    public static int GAME_TIME_OUT = 60*2*1000;
    /**对战服超时*/
    public static int BATTLE_TIME_OUT = 15 * 1000;

    public static int Channel_Timeout = 60 * 2 * 1000;

    public static int Wait_Timeout = 60 * 2 * 1000;

    /**
     * 匹配服,单点服抢占redis的时间间隔
     */
    public static int Preempt_Interval = 3000;
    /**
     * 匹配服超时时间
     */
    public static int Match_Expire_Time = 10000;

    public static int Sp_Expire_Time = 10000;

    public static int SELECT_SERVER_EXPIRE_TIME = 10000;

    public static int LOGIN_TIMEOUT = 5;

    public static final int LOGIN_EXPIRE = 60 * 30;

    public static final int ReLogin_Expire = 20;
}
