package com.kasumiSeq.conf;

/**
 * @author Athena
 * 信息提示类,前1000个id系统占用
 */
public class BaseMessageCode {
    /**成功*/
    public static int OK = 1;
    /**系统错误*/
    public static int Server_Error = 2;
    /**订单不存在*/
    public static int Order_Not_Exist =3;
    /**订单用户不正确*/
    public static int Order_User_Error =4;
    /**订单已经验证过*/
    public static int Order_Already_Verify = 5;
    /**订单token错误*/
    public static int Order_Token_Error = 6;
    /**账号不存在*/
    public static int AccountNotExist = 7;
    /**账户验证失败*/
    public static int AccountCheckFail = 8;
    /**游戏账户已绑定*/
    public static int AccountHadBind = 9;
    /**该第三方账号已绑定其他游戏账户*/
    public static int HadBindOtherAccount = 10;
    /**超过当日验证码发送次数*/
    public static int EmailSendOverLimit = 11;
    /**账户已经绑定邮箱*/
    public static int EmailExist = 12;
    /**邮箱已经被其他账户绑定*/
    public static int EmailHadBind = 13;
    /**验证码错误*/
    public static int EmailCodeError = 14;
    /**非消耗类型*/
    public static int No_NonExpendOrder = 15;

    public static int NOT_CLEAR_ORDER = 16;

    public static int ORDER_VERIFY_CODE_400 = 17;

    public static int ThirdPartyServiceError = 18;

    /**匹了俩AI*/
    public static int Double_Ai = 1000;
    /**匹到了自己*/
    public static int Same_User = 1001;
    /**对手不存在*/
    public static int Rival_Not_Find = 1002;
    /**正在创建房间*/
    public static int Creating_Room = 1003;

}
