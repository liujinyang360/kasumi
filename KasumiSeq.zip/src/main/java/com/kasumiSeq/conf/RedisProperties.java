package com.kasumiSeq.conf;

public class RedisProperties {

    public static int Redis_Db_User = 0;
    public static int Redis_Db_System = 1;
    public static int Redis_Db_Order = 2;


    /**匹配服再redis中储存的Key值*/
    public static final String MATCH_SERVER_NAME = "match_server";

    public static final String SP_SERVER_NAME = "sp_server";
    /**服务器停服/维护时间*/
    public static final String SYS_STOP_TO_TIME = "sys_operation";
    /**Redis检测*/
    public static final String Redis_Check = "redis_check";

    /**对战玩家在redis中的key前缀*/
    public static final String Battle_Player_Prefix = "battle_";

    /**订单过期时间*/
    public static final int Order_Expire_Time = 60 * 60 * 24;

    /**对战玩家在redis中的超时时间*/
    public static final int Battle_Player_Expire_Time = 60 * 60;
}