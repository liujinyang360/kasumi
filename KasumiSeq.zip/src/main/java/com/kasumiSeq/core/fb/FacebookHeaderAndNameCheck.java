package com.kasumiSeq.core.fb;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kasumiSeq.modules.HttpResult;
import com.kasumiSeq.modules.player.IGamePlayer;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;

/**
 * facebook 头像，名称 定时校验
 * @author Athena
 */

public abstract class FacebookHeaderAndNameCheck<T extends IGamePlayer> extends HttpResult {
    private T player;

    private static final Logger log = LoggerFactory.getLogger(FacebookHeaderAndNameCheck.class);

    public FacebookHeaderAndNameCheck(T player) {
        this.player = player;
    }

    /**
     * 校验完成后要做的事情
     * 包括入库,向客户端发送信息等
     * @param name facebook名字
     * @param headerUrl 头像url
     */
    protected abstract void doFinished(String name, String headerUrl, int id, String fbEmail);

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    @Override
    public void doException(Throwable e) {
        exception(e);
    }

    public void exception(Throwable e) {
        e.printStackTrace();
    }

    public void success(String data, int code) {
        if (code == 200) {
            try {
                JSONObject jsonObject = JSON.parseObject(data);
                String name = jsonObject.get("name").toString();
                JSONObject innerJson = jsonObject.getJSONObject("picture").getJSONObject("data");
                String headerUrl = innerJson.get("url").toString();
                String email = "";
                var jsonEmail = jsonObject.get("email");
                if (jsonEmail != null) {
                    email = jsonEmail.toString();
                }

                if (!name.equals(player.getName()) || !headerUrl.equals(player.getHeader())) {
                    player.setName(name);
                    player.setHeader(headerUrl);
                    doFinished(name, headerUrl, player.getId(), email);
                }
                log.info("facebook 检验完成,user is {}", this.player.getId());
            }catch (Exception e){
                e.printStackTrace();
                log.error("facebook check error,user is {}",this.player.getId());
            }
        }
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}
