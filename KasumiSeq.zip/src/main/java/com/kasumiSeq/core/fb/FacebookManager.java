package com.kasumiSeq.core.fb;


import com.kasumiSeq.utils.tool.OkHttpUtils;

/**
 * facebook相关管理类
 * @author Athena
 */
public class FacebookManager {
    /**
     * Facebook登录校验用URL
     */
    public static final String FACEBOOK_URL = "https://graph.facebook.com/me";
    /**
     * Facebook登录校验用参数
     */
    public static String FACEBOOK_LOGIN_PARAMS = "fields=id,name,email,picture.width(200).height(200)&access_token=";


    /**
     * 受限登录OIDC口令
     * https://developers.facebook.com/docs/facebook-login/limited-login/token
     */
    public static final String OIDC_DISCOVERY_URL = "https://limited.facebook.com/.well-known/openid-configuration/";
    public static final String OIDC_JWKS_URI = "https://limited.facebook.com/.well-known/oauth/openid/jwks/";


    public static void doFacebookCheck(FacebookCheck fc) {
        //HttpUtils.post(FACEBOOK_URL, FACEBOOK_LOGIN_PARAMS + fc.getFacebookToken(), null, fc);
        if(fc.isLimitedLogin()){
            doFacebookOIDCCheck(fc);
            return;
        }
        OkHttpUtils.doHttpRequest(FACEBOOK_URL, FACEBOOK_LOGIN_PARAMS + fc.getFacebookToken(), "post", null, fc);
    }

    public static void doFacebookOIDCCheck(FacebookCheck fc) {
        OkHttpUtils.doHttpRequest(OIDC_JWKS_URI, null, "get", null, fc);
    }


    public static void doFacebookHeaderAndName(FacebookHeaderAndNameCheck fc, String facebookToken){
        String params = FACEBOOK_LOGIN_PARAMS + facebookToken;
        //HttpUtils.post(FACEBOOK_URL, params, null, fc);
        OkHttpUtils.doHttpRequest(FACEBOOK_URL, params, "post", null, fc);
    }
}
