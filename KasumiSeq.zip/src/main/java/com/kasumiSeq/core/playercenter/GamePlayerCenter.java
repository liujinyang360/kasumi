package com.kasumiSeq.core.playercenter;

import com.kasumiSeq.modules.player.IGamePlayer;
import com.kasumiSeq.core.Server;
import io.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class GamePlayerCenter<T extends IGamePlayer> extends PlayerCenter<T> {


    private static final Logger log = LoggerFactory.getLogger(GamePlayerCenter.class);

    /**
     * 玩家登出时要做的事情
     *
     * @param player 玩家对象
     */
    public abstract void doPlayerLogOut(T player);

    public abstract void doAfterLogOut(T player);

    public abstract void doForceRemoveBeforeAddPlayer(T player);


    public void logout(Channel channel) {
        if (channel == null) {
            return;
        }
        log.info("logout channel = {}",channel);
        channelTimeMap.remove(channel);
        var clientChannel = channelMap.remove(channel);
        if (clientChannel == null) {
            log.info("logout clientChannel is null, channel = {}",channel);
            return;
        }

        T player = channelPlayerMap.remove(clientChannel);
        if (player != null) {
            int playerId = player.getId();
            player.destroy();
            //下线处理
            deleteFromRedis(playerId);
            doPlayerLogOut(player);
            removePlayer(playerId, clientChannel);
            log.warn("player {} logout,channel is {}", player.getId(), player.getClientChannel());
            doAfterLogOut(player);
        }else{
            log.info("logout player is null,channel = {}",channel);
        }
    }

    public void deleteFromRedis(int playerId) {
        Server.instance().getRedisController().delLogin(playerId);
    }
}
