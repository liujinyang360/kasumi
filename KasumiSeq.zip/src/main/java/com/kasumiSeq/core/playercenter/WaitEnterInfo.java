package com.kasumiSeq.core.playercenter;

import com.kasumiSeq.io.ClientChannel;
import com.kasumiSeq.modules.player.IPlayer;

public class WaitEnterInfo <T extends IPlayer>{

    protected T player;
    protected ClientChannel clientChannel;

    protected int enterType;
    protected long waitTime = System.currentTimeMillis();

    public WaitEnterInfo(T player, ClientChannel ch){
        this.player = player;
        this.clientChannel = ch;
    }

    public WaitEnterInfo(T player, int type, ClientChannel ch){
        this(player,ch);
        this.enterType = type;
    }

    public T getPlayer() {
        return player;
    }

    public ClientChannel getClientChannel() {
        return clientChannel;
    }

    public long getWaitTime() {
        return waitTime;
    }

    public void doEnter(){

    }
}
