package com.kasumiSeq.core.redis;

import org.jdom2.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class BaseRedisPool {

    private JedisPool pool;
    private JedisPoolConfig config = new JedisPoolConfig();
    private int timeOut = 10000;
    private String host;
    private int port;
    private String password;

    private String name;

    private static final Logger log = LoggerFactory.getLogger(BaseRedisPool.class);

    public void init(Element root, ScheduledThreadPoolExecutor executor) throws Exception {
        initConfig(root);
        initPool();
        doCheckInterrupt(executor);
    }

    private void initPool(){
        try{
            if(pool != null){
                pool.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        pool = new JedisPool(config,host,port,timeOut,password);
        // 不要打印pool.toString()，它会包含很长的创建堆栈信息
        log.info("redis pool init success. name={}, host={}:{}, maxTotal={}, maxIdle={}, minIdle={}", 
                 name, host, port, config.getMaxTotal(), config.getMaxIdle(), config.getMinIdle());
    }

    private void initConfig(Element root) throws Exception{
        this.name = root.getAttributeValue("name");

        Element configElement = root.getChild("config");
        config.setMaxIdle(configElement.getAttribute("MaxIdle").getIntValue());
        config.setMaxTotal(configElement.getAttribute("MaxTotal").getIntValue());
        config.setMinIdle(configElement.getAttribute("MinIdle").getIntValue());
        timeOut = configElement.getAttribute("timeout").getIntValue();

        Element serverElement = root.getChild("server");
        host = serverElement.getAttributeValue("host");
        port = serverElement.getAttribute("port").getIntValue();
        password = serverElement.getAttributeValue("pwd");
    }

    /**
     * 获取默认jedis对象
     * @return jedis对象
     */
    public Jedis getJedis() {
        return pool == null ? null : pool.getResource();
    }

    /**
     * 根据数据库编号获取jedis对象
     * @param db 数据库分区编号
     * @return jedis对象
     */
    public Jedis getJedis(int db) {
        Jedis jedis = getJedis();
        if(jedis != null ) {
            jedis.select(db);
        }
        return jedis;
    }

    private void doCheckInterrupt(ScheduledThreadPoolExecutor executor){
        executor.scheduleWithFixedDelay(()->checkInterrupt(),1000,1000, TimeUnit.MILLISECONDS);
    }

    public String getName() {
        return name;
    }

    /**
     * 重连Redis
     */
    private void reConnect(){
        try{
            log.warn("redis {} interrupt,retry connect",this.name);
            initPool();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private synchronized void checkInterrupt(){
        Jedis jedis = null;
        try {
            jedis = getJedis();
            if (jedis == null ||  !"PONG".equals(jedis.ping())) {
                reConnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
            //获取出错,重连
            reConnect();
        } finally {
            if (jedis != null) {
                jedis.close();
            }
        }
    }
}
