package com.kasumiSeq.core.sms;


import com.kasumiSeq.utils.tool.Time;
import org.jdom2.Element;

import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

/**
 * @author Athena
 * 短信任务基类
 */
public abstract class SmsTask <S extends SmsManager>{
    /**
     *任务名字
     */
    private String name;
    /**
     * 上次检测时间
     */
    private int lastCheckTime = Time.getCurrentSeconds();
    /**
     *需要发短信的时间间隔,秒
     */
    private int duration;
    /**
     * 当前参数模板列表
     */
    protected TreeMap<String,String> paraMap = new TreeMap<>();
    /**
     * 要发送的手机号码
     */
    private String[] phoneNumbers;
    /**
     * 短信发送模板code
     */
    private String templateCode;
    /**
     * 签名名称
     */
    private String signName;

    /**
     * id
     * @return id
     */
    public abstract int getId();

    /**
     * 检测任务执行方法
     */
    public abstract void doCheck() throws Exception;

    /**
     * 创建短信发送的参数
     * @param values
     * @return 参数列表
     */
    public abstract HashMap<String,String> createParas(String... values);

    public abstract String getParas(String... values);

    public abstract void sendSms(String... values);

    public void init(Element element) throws Exception{
        this.phoneNumbers = element.getAttributeValue("phones").split(",");
        this.templateCode = element.getAttributeValue("TemplateCode");
        this.signName = element.getAttributeValue("SignName");
        this.setDuration(element.getAttribute("duration").getIntValue());
        List<Element> list = element.getChildren("paras");
        for(Element child : list){
            this.paraMap.put(child.getAttributeValue("name"),child.getAttributeValue("value"));
        }
    }

    public abstract S getSmsManager();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLastCheckTime() {
        return lastCheckTime;
    }

    public void setLastCheckTime(int lastCheckTime) {
        this.lastCheckTime = lastCheckTime;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String[] getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(String[] phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode;
    }

    public String getSignName() {
        return signName;
    }

    public void setSignName(String signName) {
        this.signName = signName;
    }
}
