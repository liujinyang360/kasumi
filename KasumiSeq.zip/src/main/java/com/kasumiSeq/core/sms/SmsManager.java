package com.kasumiSeq.core.sms;

import com.alibaba.fastjson.JSON;
import com.kasumiSeq.modules.HttpResult;
import com.kasumiSeq.utils.tool.OkHttpUtils;
import com.kasumiSeq.utils.tool.Time;
import com.kasumiSeq.core.tencent.TencentAuthorization;
import com.kasumiSeq.core.tencent.TencentSmsParas;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.*;

/**
 * @author Athena
 * 短信检测管理类
 */


public abstract class SmsManager {

    private HashMap<Integer, SmsTask> taskMap = new HashMap<>();

    private String secretId;
    private String secretKey;
    private String remoteHost;

    private static Logger log = LoggerFactory.getLogger(SmsManager.class);

    public void initTask(InputStream in) throws Exception {
        taskMap.clear();
        SAXBuilder sb = new SAXBuilder();
        var root = sb.build(in).getRootElement();

        initParas(root);

        List<Element> taskList = root.getChildren("task");
        for (var child : taskList) {
            var task = createTask(child);
            task.init(child);
            taskMap.put(task.getId(), task);
        }
        log.info("init sms configs end,data is {}", JSON.toJSONString(taskMap));
    }


    public abstract void initParas(Element root) throws Exception;

    public String getSecretId() {
        return secretId;
    }

    public void setSecretId(String secretId) {
        this.secretId = secretId;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getRemoteHost() {
        return remoteHost;
    }

    public void setRemoteHost(String remoteHost) {
        this.remoteHost = remoteHost;
    }

    /**
     * 创建检测任务
     *
     * @param element
     * @return 短信检测任务
     * @throws Exception
     */
    public abstract SmsTask createTask(Element element) throws Exception;

    public void checkSmsTask() {
        taskMap.values().forEach(t -> {
            try {
                t.doCheck();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public SmsTask getSmsTask(int id) {
        return taskMap.get(id);
    }

    public static void sendTencentSms(String[] phones, String signName, String templateCode, String[] paras, String sdkAppId, String secretId, String secretKey, HttpResult httpResult) {

        HashSet<String> phoneNumberSet = new HashSet<>();
        for (String s : phones) {
            phoneNumberSet.add(s);
        }

        LinkedHashSet<String> templateParamSet = new LinkedHashSet<>();
        for (String s : paras) {
            templateParamSet.add(s);
        }

        String timestamp = String.valueOf(Time.getCurrentSeconds());
        try {
            TencentSmsParas smsParas = new TencentSmsParas(phoneNumberSet, templateCode, sdkAppId,
                    templateParamSet, signName);
            String param = smsParas.createParas();

            Map<String, String> headers = new HashMap<>();
            headers.put("Authorization",
                    TencentAuthorization.makeSmsAuthorization(timestamp, param, secretId, secretKey));
            headers.put("Content-Type", "application/json; charset=utf-8");
            headers.put("X-TC-Action", "SendSms");
            headers.put("X-TC-Version", "2021-01-11");
            headers.put("X-TC-Timestamp", timestamp);
            headers.put("X-TC-Region", "ap-beijing");

            //HttpUtils.post("https://sms.tencentcloudapi.com/", param, headers, httpResult);
            OkHttpUtils.doHttpRequest("https://sms.tencentcloudapi.com/", param, "post", headers, httpResult);
            log.info("send finished ....");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}