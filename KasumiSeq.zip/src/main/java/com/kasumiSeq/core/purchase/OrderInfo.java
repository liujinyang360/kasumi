package com.kasumiSeq.core.purchase;

import com.alibaba.fastjson.JSON;

import java.math.BigDecimal;

/**
 * @author Athena
 * 订单的数据结构
 */

public class OrderInfo {
    private long orderId;
    private int userId;
    private String productId;
    private int productType = -1;
    private BigDecimal money ;
    private int num = 1;
    private int type = 1;
    private int skuFrom;
    private int status;
    private int osType;
    private String packetName;
    private int skuId;
    private String skuName;
    private String purchaseToken = "";
    private String purchaseData = "";
    private String purchaseId = "";
    private boolean isVerify;
    private int createTime;
    private int updateTime;
    private int classify;
    private boolean missOrder = false;
    private int purchaseType;
    private String extra = "";

    public boolean isTest() {
        return this.purchaseType != 100;
    }

    public String toJson() throws Exception{
        return JSON.toJSONString(this);
    }

    public static OrderInfo parseInfo(String json) throws Exception{
        return JSON.parseObject(json,OrderInfo.class);
    }

    public long getOrderId() {
        return orderId;
    }

    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public int getProductType() {
        return productType;
    }

    public void setProductType(int productType) {
        this.productType = productType;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getSkuFrom() {
        return skuFrom;
    }

    public void setSkuFrom(int skuFrom) {
        this.skuFrom = skuFrom;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getOsType() {
        return osType;
    }

    public void setOsType(int osType) {
        this.osType = osType;
    }

    public String getPacketName() {
        return packetName;
    }

    public void setPacketName(String packetName) {
        this.packetName = packetName;
    }

    public int getSkuId() {
        return skuId;
    }

    public void setSkuId(int skuId) {
        this.skuId = skuId;
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    public String getPurchaseToken() {
        return purchaseToken;
    }

    public void setPurchaseToken(String purchaseToken) {
        this.purchaseToken = purchaseToken;
    }

    public String getPurchaseData() {
        return purchaseData;
    }

    public void setPurchaseData(String purchaseData) {
        this.purchaseData = purchaseData;
    }

    public String getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(String purchaseId) {
        this.purchaseId = purchaseId;
    }

    public boolean isVerify() {
        return isVerify;
    }

    public void setVerify(boolean verify) {
        isVerify = verify;
    }

    public int getCreateTime() {
        return createTime;
    }

    public void setCreateTime(int createTime) {
        this.createTime = createTime;
    }

    public int getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(int updateTime) {
        this.updateTime = updateTime;
    }

    public int getClassify() {
        return classify;
    }

    public void setClassify(int classify) {
        this.classify = classify;
    }

    public boolean isMissOrder() {
        return missOrder;
    }

    public void setMissOrder(boolean missOrder) {
        this.missOrder = missOrder;
    }

    public int getPurchaseType() {
        return purchaseType;
    }

    public void setPurchaseType(int purchaseType) {
        this.purchaseType = purchaseType;
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }
}
