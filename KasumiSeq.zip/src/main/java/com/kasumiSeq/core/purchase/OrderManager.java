package com.kasumiSeq.core.purchase;

import com.kasumiSeq.conf.BaseMessageCode;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.modules.player.IGamePlayer;
import com.kasumiSeq.core.Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *订单管理类
 * @author Athena
 */

public class OrderManager {

    private static final Logger log = LoggerFactory.getLogger(OrderManager.class);

    public static <T extends IGamePlayer> void createOrder(T player, OrderInfo info, OrderHandler<T> handler) {
        int result = handler.insertOrder(info);
        if (result != 1) {
            handler.writeTransactionResult(player, result, 0, "");
            return;
        }
        if ((result = handler.saveOrder(info)) != 1) {
            handler.writeTransactionResult(player, result, 0, info.getProductId());
        } else {
            handler.writeTransactionResult(player, result, info.getOrderId(), info.getProductId());
        }
    }

    public static <T extends IGamePlayer> void verifyOrder(long orderId, String token, T player, OrderHandler<T> handler) {
        OrderInfo info = null;
        String orderStr = handler.getOrder(orderId);
        if (orderStr != null) {
            try {
                info = OrderInfo.parseInfo(orderStr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            info = handler.getOrderFromDb(orderId);
        }
        if (info == null) {
            handler.writeTransactionVerify(player, BaseMessageCode.Order_Not_Exist, 0, "", 0);
            return;
        }
        if (info.getUserId() != player.getId()) {
            if(handler.checkDeviceIdMatch(player,info) ){
                handler.writeTransactionVerify(player, BaseMessageCode.NOT_CLEAR_ORDER, info.getOrderId(), info.getProductId(), 0);
                return;
            }
            handler.writeTransactionVerify(player, BaseMessageCode.Order_User_Error, info.getOrderId(), info.getProductId(), 0);
            return;
        }
        if (info.isVerify()) {
            handler.writeTransactionVerify(player, BaseMessageCode.Order_Already_Verify, info.getOrderId(), info.getProductId(), info.getPurchaseType(), info.getSkuId());
            return;
        }
        info.setPurchaseToken(token);
        if (player.getOsType() == CommProperties.Os_Android) {
            PurchaseManager.doGoogleAuth(player, info, handler, 0,0);
        } else {
            PurchaseManager.doIosAuth(player, info, handler,1, 0);
        }
    }


    /**
     * ios 提审
     * @param orderId
     * @param token
     * @param player
     * @param handler
     * @param <T>
     */
    public static <T extends IGamePlayer> void iosAuditOrder(long orderId, String token, T player, OrderHandler<T> handler) {

        log.info("isoAuditOrder orderId = {}，userId = {}" ,orderId,player.getId());

        OrderInfo info = null;
        if(orderId == 1){
            PurchaseManager.doIosAuditMissOrderId(player,token,handler,1);
            return;
        }

        String orderStr = Server.instance().getRedisController().getOrder(orderId);
        if (orderStr != null) {
            try {
                info = OrderInfo.parseInfo(orderStr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            info = handler.getOrderFromDb(orderId);
        }
        if (info == null) {
            handler.writeTransactionVerify(player, BaseMessageCode.Order_Not_Exist, 0, "", 0);
            return;
        }
        if (info.getUserId() != player.getId()) {
            handler.writeTransactionVerify(player, BaseMessageCode.Order_User_Error, info.getOrderId(), info.getProductId(), 0);
            return;
        }
        if (info.isVerify()) {
            handler.writeTransactionVerify(player, BaseMessageCode.Order_Already_Verify, info.getOrderId(), info.getProductId(), info.getPurchaseType(), info.getSkuId());
            return;
        }
        info.setPurchaseToken(token);

        //直接成功
        info.setPurchaseType(CommProperties.Purchase_Success_Type);
        handler.transActionSuccess(player,info,CommProperties.Purchase_Success_Type);
    }
}
