package com.kasumiSeq.core.purchase;

import com.alibaba.fastjson.JSON;
import com.kasumiSeq.conf.BaseMessageCode;
import com.kasumiSeq.modules.HttpResult;
import com.kasumiSeq.modules.player.IGamePlayer;
import com.kasumiSeq.utils.tool.ThreadPool;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.HashMap;

/**
 * google平台内购验证
 * @author Athena
 * @param <T> 游戏玩家
 */

public class GooglePurchase<T extends IGamePlayer> extends HttpResult {
    private T player;
    private OrderInfo info;
    private OrderHandler handler;
    private int tokenIndex;
    private int retryTimes;

    private static final Logger log = LoggerFactory.getLogger(GooglePurchase.class);
    public GooglePurchase(T player, OrderInfo info, OrderHandler handler, int tokenIndex, int retryTimes) {
        this.player = player;
        this.info = info;
        this.handler = handler;
        this.tokenIndex = tokenIndex;
        this.retryTimes = retryTimes;
    }

    @Override
    public void doSuccess (HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    public void success(String body, int code) {
        try {

            log.info( "user is {}, response code is {}, google auth is {}",this.player.getId(), code, body);
            if (code == 200) {
                try {
                    HashMap map = JSON.parseObject(body,HashMap.class);

                    if ("0".equals(map.get("purchaseState").toString())) {
                        info.setPurchaseData(body);
                        int purchaseType = 100;

                        String purchaseStr = map.get("purchaseType") != null ? map.get("purchaseType").toString() : null;
                        if (purchaseStr != null) {
                            try {
                                purchaseType = Integer.parseInt(purchaseStr);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        this.info.setPurchaseType(purchaseType);
                        if ((handler.checkTransactionId(map.getOrDefault("orderId", "").toString())) == null) {
                            handler.transActionSuccess(this.player, this.info, purchaseType);
                        } else {
                            handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Already_Verify, info.getOrderId(), info.getProductId(), purchaseType, info.getSkuId());
                        }
                    } else {
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Token_Error, info.getOrderId(), info.getProductId(), 0);
                    }
                } catch (Exception e) {
                    handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), info.getProductId(), 0);
                    e.printStackTrace();
                }
            } else if (code == 403) {
                log.error("google response 403, user is {}, cur index {}", this.player.getId(), tokenIndex);
                PurchaseManager.doGoogleAuth(player, info, handler, ++tokenIndex,++retryTimes);
            } else {
                handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), info.getProductId(), 0);
                log.error("google response error, statusCode {},user is {}, token is {}", code, this.player.getId(), info.getPurchaseToken());
            }
        } catch (Exception e) {
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), info.getProductId(), 0);
            e.printStackTrace();
        }
    }

    public void exception(Throwable e) {
        e.printStackTrace();
        if (retryTimes < 3) {
            ThreadPool.SchedulePool.schedule(() -> PurchaseManager.doGoogleAuth(player, info, handler, tokenIndex,++retryTimes), 1000);
        } else {
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), "", 0);
            log.error("google auth exception,user is {},order is {},cur retry times is {}", player.getId(), info.getOrderId(),retryTimes);
        }
    }

    @Override
    public void doException(Throwable e) {
        exception(e);
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}
