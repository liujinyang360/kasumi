package com.kasumiSeq.core.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kasumiSeq.utils.tool.Tools;

import java.io.InputStream;
import java.util.HashSet;

public class IosSpecialManager {

    /**
     * 提审版本
     */
    private static HashSet<String> auditVersionSet = new HashSet<>();

    /**
     * 非消耗品（恢复购买流程）
     */
    private static HashSet<String> nonExpendableItemSet = new HashSet<>();

    public static void init(InputStream inputStream){
        auditVersionSet.clear();
        nonExpendableItemSet.clear();

        JSONObject jsonObject = JSON.parseObject(Tools.input2String(inputStream));
        JSONArray versions = jsonObject.getJSONArray("auditVersion");
        if(versions != null){
            for(var version : versions){
                if(version instanceof String){
                    auditVersionSet.add((String)version);
                }
            }
        }

        JSONArray nonExpendable = jsonObject.getJSONArray("nonExpendable");
        if(nonExpendable != null){
            for(var item : nonExpendable){
                if(item instanceof String){
                    nonExpendableItemSet.add((String)item);
                }
            }
        }
    }

    /**
     * 是否提审版本
     * @param version
     * @return
     */
    public static boolean isAuditVersion(String version){
        return auditVersionSet.contains(version);
    }

    /**
     * 是否非消耗品订单
     * @param productId
     * @return
     */
    public static boolean isNonExpendableItem(String productId) {
        return nonExpendableItemSet.contains(productId);
    }


    public static HashSet<String> getNonExpendableItemSet() {
        return nonExpendableItemSet;
    }
}
