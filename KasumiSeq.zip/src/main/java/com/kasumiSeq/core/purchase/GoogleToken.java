package com.kasumiSeq.core.purchase;

import java.util.List;

public class GoogleToken {
    public List<String> tokens;
    public int expireTime;
    public int gainTime;
}