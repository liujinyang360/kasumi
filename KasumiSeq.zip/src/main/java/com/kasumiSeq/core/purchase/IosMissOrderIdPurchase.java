package com.kasumiSeq.core.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kasumiSeq.conf.BaseMessageCode;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.modules.HttpResult;
import com.kasumiSeq.modules.player.IGamePlayer;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;

/**
 * orderId 丢失
 */
public class IosMissOrderIdPurchase<T extends IGamePlayer> extends HttpResult {
    private T player;
    private String token;
    private String fullToken;
    private OrderHandler handler;
    private int times;

    private static final Logger log = LoggerFactory.getLogger(IosMissOrderIdPurchase.class);

    public IosMissOrderIdPurchase(T player, String token, String fullToken, OrderHandler handler, int times) {
        this.player = player;
        this.token = token;
        this.fullToken = fullToken;
        this.handler = handler;
        this.times = times;
    }

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    @Override
    public void doException(Throwable ex) {
        exception(ex);
    }

    public void exception(Throwable ex) {
        ex.printStackTrace();
        handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error,1,"",0);
        log.error("IOS auth exception,user is {},order is {},times={}",player.getId(),1,times);
    }

    public void success(String body, int code) {
        try {
            log.info("ios auth is {}",body);
            if (code == 200) {
                JSONObject obj = JSON.parseObject(body);
                String status = obj.getString("status");

                //先正式服，后沙箱服
                if("21007".equals(status)){
                    if(times <= 1){
                        log.info(" verify status is 21007");
                        PurchaseManager.doIosMissOrderAuth(player,this.fullToken,handler,times + 1);
                        return;
                    }
                }

                if ("0".equals(status)) {
                    var receipt = obj.getJSONObject("receipt");
                    String productId = receipt.getString("product_id");

                    System.out.println(receipt.getString("bid"));
                    OrderInfo o = null;
                    if (!PurchaseManager.getPacketName(CommProperties.Os_Ios).equals(receipt.getString("bid"))) {
                        log.info("packetName is not same ");
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Token_Error,1,productId,0);
                    } else if ((o = handler.checkTransactionId(receipt.getString("transaction_id"))) == null) {
                        OrderInfo info = this.handler.getOrderFromDbByProduceId(player.getId(), productId);
                        if (info != null) {
                            info.setMissOrder(true);
                            info.setPurchaseData(body);
                            info.setPurchaseToken(this.fullToken);
                            int purchaseType = IosPurchase.calPurchaseType(times);
                            info.setPurchaseType(purchaseType);
                            handler.transActionSuccess(this.player, info, purchaseType);
                        } else {
                            //如果为空要特使判断是否同一设备其他号下过订单未验证，如果有不做处理下发给客户端
                            info = this.handler.getOrderByProductAndDeviceCode(player.getDeviceCode(), productId, player.getId());
                            if (info != null) {
                                handler.writeTransactionVerify(player, BaseMessageCode.NOT_CLEAR_ORDER, info.getOrderId(), info.getProductId(), 0);
                                log.info("订单丢失，但是同一设备其他号下过订单未验证 ,当前用户 {} , 订单持有者玩家是 {} ，订单号 {} , ", player.getId(), info.getUserId(), info.getOrderId());
                                return;
                            }
                            handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Not_Exist, 1, productId, 0);
                        }
                    } else {
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Already_Verify, o.getOrderId(), productId, o.getPurchaseType(), o.getSkuId());
                    }
                } else {
                    int codeErr = BaseMessageCode.Order_Token_Error;
                    if("21005".equals(status)){
                        codeErr = BaseMessageCode.ThirdPartyServiceError;
                    }
                    log.error("ios auth Token_Error,user is {} , status is {}", player.getId() , status);
                    handler.writeTransactionVerify(this.player, codeErr,1,"",0);
                }
            } else {
                handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error,1,"",0);
                log.error("ios error response is {},user is {},token is {}",code,this.player.getId(),this.token);
            }
        }catch(Exception e){
            log.error("ios auth exception,user is {}",player.getId());
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error,1,"",0);
            e.printStackTrace();
        }finally {
            player.removeCheckOrder(1);
        }
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}
