package com.kasumiSeq.core.purchase;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.kasumiSeq.conf.BaseMessageCode;
import com.kasumiSeq.conf.CommProperties;
import com.kasumiSeq.modules.HttpResult;
import com.kasumiSeq.modules.player.IGamePlayer;
import com.kasumiSeq.utils.tool.ThreadPool;
import com.kasumiSeq.core.Server;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;

/**
 * ios平台内购验证
 *
 * @param <T> 游戏玩家
 * @author Athena
 */

public class IosPurchase<T extends IGamePlayer> extends HttpResult {
    private T player;
    private OrderInfo info;
    private OrderHandler handler;
    private int times;
    private int retryTimes;

    private static Logger log = LoggerFactory.getLogger(IosPurchase.class);

    public IosPurchase(T player, OrderInfo info, OrderHandler handler, int times, int retryTimes) {
        this.player = player;
        this.info = info;
        this.handler = handler;
        this.times = times;
        this.retryTimes = retryTimes;
    }

    public static int calPurchaseType(int times) {
        if (!Server.instance().isDebug() && times > 1) {
            return CommProperties.OrderVerify_ProductTest_Success_Ios;
        }
        return 100;
    }

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    @Override
    public void doException(Throwable ex) {
        exception(ex);
    }

    public void exception(Throwable ex) {
        ex.printStackTrace();
        if (retryTimes < 3) {
            ThreadPool.SchedulePool.schedule(() -> PurchaseManager.doIosAuth(player, info, handler, times, ++retryTimes), 1000);
        } else {
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), "", 0);
            log.error("IOS auth exception,user is {},order is {},times = {}, retryTimes {}", player.getId(), info.getOrderId(), times, retryTimes);
        }
    }

    public void success(String body, int code) {
        try {
            log.info("ios auth is {}", body);
            if (code == 200) {
                JSONObject obj = JSON.parseObject(body);
                String status = obj.getString("status");

                //先正式服，后沙箱服
                if ("21007".equals(status)) {
                    if (times <= 1) {
                        log.info(" verify status is 21007");
                        PurchaseManager.doIosAuth(player, info, handler, times + 1, retryTimes);
                        return;
                    }
                }

                if ("0".equals(status)) {
                    var receipt = obj.getJSONObject("receipt");
                    String iosProductId = receipt.getString("product_id");

                    if (!PurchaseManager.getPacketName(CommProperties.Os_Ios).equals(receipt.getString("bid"))) {
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Token_Error, info.getOrderId(), info.getProductId(), 0);
                    } else if (!this.info.getProductId().equals(iosProductId)) {
                        log.info("Ios productId is not same");
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Token_Error, info.getOrderId(), info.getProductId(), 0);
                    } else if ((handler.checkTransactionId(receipt.getString("transaction_id"))) != null) {
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Already_Verify, info.getOrderId(), info.getProductId(), info.getPurchaseType(), info.getSkuId());
                    } else {
                        info.setPurchaseData(body);
                        int purchaseType = calPurchaseType(this.times);
                        info.setPurchaseType(purchaseType);
                        handler.transActionSuccess(this.player, this.info, purchaseType);
                    }
                } else {
                    int codeErr = BaseMessageCode.Order_Token_Error;
                    if("21005".equals(status)){
                        codeErr = BaseMessageCode.ThirdPartyServiceError;
                    }
                    log.error("ios auth Token_Error,user is {} , status is {}", player.getId() , status);
                    handler.writeTransactionVerify(this.player, codeErr, info.getOrderId(), info.getProductId(), 0);
                }
            } else {
                handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), "", 0);
                log.error("ios error response is {},user is {},token is {}", code, this.player.getId(), this.info.getPurchaseToken());
            }
        } catch (Exception e) {
            log.error("ios auth exception,user is {}", player.getId());
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, info.getOrderId(), "", 0);
            e.printStackTrace();
        }
    }

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}
