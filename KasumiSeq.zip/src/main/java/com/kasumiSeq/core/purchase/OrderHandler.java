package com.kasumiSeq.core.purchase;


import com.kasumiSeq.modules.player.IGamePlayer;

/**
 * 订单handler类
 * @author Athena
 * @param <T> 玩家
 */
public interface OrderHandler <T extends IGamePlayer>{
    /**
     * 插入一条订单
     * @param info
     * @return 插入结果
     */
    int insertOrder(OrderInfo info);

    /**
     * 写订单交易结果
     * @param player 玩家
     * @param result 结果
     * @param orderId 订单id
     * @param productId 商品id
     */
    void writeTransactionResult(T player, int result, long orderId, String productId);

    /**
     * 从数据库中获取一个订单
     * 订单都是先从redis获取,获取不到再到数据库
     * @param orderId 订单id
     * @return 订单
     */
    OrderInfo getOrderFromDb(long orderId);

    /**
     * 从数据库中获取一个订单
     * @param userId
     * @param produceId
     * @return
     */
    OrderInfo getOrderFromDbByProduceId(int userId, String produceId);

    /**
     * 发送订单验证结果
     * @param player 玩家
     * @param result 结果
     * @param orderId 订单id
     * @param productId 商品id
     * @param purchaseType 交易类型
     */
    void writeTransactionVerify(T player, int result, long orderId, String productId, int purchaseType, int... offerId);

    /**
     * 交易成功后的处理
     * @param player 玩家
     * @param info 订单
     * @param purchaseType 交易类型
     */
    void transActionSuccess(T player, OrderInfo info, int purchaseType);

    /**
     * 存Order,一般是存redis里面
     * @param info
     * @return
     */
    int saveOrder(OrderInfo info);

    /**
     * 取order,一般从redis里面取
     * @param orderId
     * @return
     */
    String getOrder(long orderId);

    /**
     * 验证这个transaction_id是否被验证过了
     */
    OrderInfo checkTransactionId(String transactionId);

    boolean checkDeviceIdMatch(T player , OrderInfo info);

    OrderInfo getOrderByProductAndDeviceCode(String deviceId , String productId , int userId);

}
