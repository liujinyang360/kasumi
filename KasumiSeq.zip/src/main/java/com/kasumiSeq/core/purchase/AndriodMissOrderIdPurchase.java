package com.kasumiSeq.core.purchase;

import com.alibaba.fastjson.JSON;
import com.kasumiSeq.conf.BaseMessageCode;
import com.kasumiSeq.modules.HttpResult;
import com.kasumiSeq.modules.player.IGamePlayer;
import com.kasumiSeq.utils.tool.ThreadPool;
import okhttp3.Call;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.util.HashMap;

/**
 * orderId 丢失
 */
public class AndriodMissOrderIdPurchase<T extends IGamePlayer> extends HttpResult {
    private T player;
    private String token;
    private String fullToken;
    private OrderHandler handler;
    private int times;

    private String productId;

    private static final Logger log = LoggerFactory.getLogger(AndriodMissOrderIdPurchase.class);

    public AndriodMissOrderIdPurchase(T player, String token, OrderHandler handler, int times, String productId) {
        this.player = player;
        this.token = token;
        this.handler = handler;
        this.times = times;
        this.productId = productId;
    }

    @Override
    public void doSuccess(HttpResponse<String> response) {
        success(response.body(), response.statusCode());
    }

    @Override
    public void doException(Throwable ex) {
        exception(ex);
    }

    public void exception(Throwable ex) {
        ex.printStackTrace();
        if (times < 3) {
            ThreadPool.SchedulePool.schedule(() -> PurchaseManager.doAndroidMissOrderAuth(player, token, handler, ++times , productId), 1000);
        } else {
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, 1, "", 0);
            log.error("miss google auth exception,user is {},order is {}, product is {}", player.getId(), 1,productId);
        }
    }

    public void success(String body, int code) {
        try {
            log.info("android miss order auth success, user is {}, response code is {}, google auth is {}", this.player.getId(), code, body);
            if (code == 200) {
                try {
                    HashMap map = JSON.parseObject(body, HashMap.class);

                    if ("0".equals(map.get("purchaseState").toString())) {
//                        info.setPurchaseData(body);
                        int purchaseType = 100;

                        String purchaseStr = map.get("purchaseType") != null ? map.get("purchaseType").toString() : null;
                        if (purchaseStr != null) {
                            try {
                                purchaseType = Integer.parseInt(purchaseStr);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }


                        OrderInfo o = null;
//                        this.info.setPurchaseType(purchaseType);
                        if ((o = handler.checkTransactionId(map.getOrDefault("orderId", "").toString())) == null) {
                            OrderInfo info = this.handler.getOrderFromDbByProduceId(player.getId(), productId);
                            if (info != null) {
                                info.setMissOrder(true);
                                info.setPurchaseData(body);
                                info.setPurchaseToken(this.token);
                                info.setPurchaseType(purchaseType);
                                handler.transActionSuccess(this.player, info, purchaseType);
                            } else {
                                //如果为空要特使判断是否同一设备其他号下过订单未验证，如果有不做处理下发给客户端
                                info = this.handler.getOrderByProductAndDeviceCode(player.getDeviceCode(), productId, player.getId());
                                if (info != null) {
                                    handler.writeTransactionVerify(player, BaseMessageCode.NOT_CLEAR_ORDER, info.getOrderId(), info.getProductId(), 0);
                                    log.info("订单丢失，但是同一设备其他号下过订单未验证 ,当前用户 {} , 订单持有者玩家是 {} ，订单号 {} , ", player.getId(), info.getUserId(), info.getOrderId());
                                    return;
                                }
                                handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Not_Exist, 1, productId, 0);
                            }
                        } else {
                            handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Already_Verify, o.getOrderId(), o.getProductId(), purchaseType, o.getSkuId());
                        }
                    } else {
                        handler.writeTransactionVerify(this.player, BaseMessageCode.Order_Token_Error, 1,"", 0);
                    }
                } catch (Exception e) {
                    handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, 1, "", 0);
                    e.printStackTrace();
                }
            } else if (code == 403) {
                log.error("google response 403, user is {}, cur index {}", this.player.getId(), 0);
                PurchaseManager.doAndroidMissOrderAuth(player, token, handler, ++times, productId);
            } else {
                int messageCode = BaseMessageCode.Server_Error;
                if(code == 400){
                    messageCode = BaseMessageCode.ORDER_VERIFY_CODE_400;
                }
                handler.writeTransactionVerify(this.player, messageCode, 1, "", 0);
                log.error("google response error, statusCode {},user is {}, token is {}", code, this.player.getId(), this.token);
            }
        } catch (Exception e) {
            log.error("google auth exception,user is {}", player.getId());
            handler.writeTransactionVerify(this.player, BaseMessageCode.Server_Error, 1, "", 0);
            e.printStackTrace();
        } finally {
            player.removeCheckOrder(1);
        }
    }

    /**
     *{
     *   "error": {
     *     "code": 400,
     *     "message": "Invalid Value",
     *     "errors": [
     *       {
     *         "message": "Invalid Value",
     *         "domain": "global",
     *         "reason": "invalid"
     *       }
     *     ]
     *   }
     * }
     *
     */

    @Override
    public void doResponse(@NotNull Call call, @NotNull Response response) throws IOException {
        success(response.body().string(), response.code());
    }

    @Override
    public void doFailure(@NotNull Call call, @NotNull IOException e) {
        exception(e);
    }
}
