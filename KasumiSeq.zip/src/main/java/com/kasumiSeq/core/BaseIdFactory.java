package com.kasumiSeq.core;

/**
 * id工厂类
 * @author Athena
 */
public class BaseIdFactory {
    /**服务器增量，预留1000的服务器ID**/
    public static final int ServerReserved = 1000;
    public static int machineId;
    public static void setMachineId(int mid){
        machineId = mid;
    }

    /**
     * 根据初始ID计算出相应的唯一ID
     * @return 一个唯一id
     */
    protected static synchronized long getServerUniqueId(long id){
        return id * ServerReserved + machineId;
    }

    /**
     * 根据初始ID计算出相应的唯一ID(自定义预留数值)
     * @return 一个唯一id
     */
    protected static synchronized long redefineServerUniqueID(long id, long serverReserved){
        return id * serverReserved + machineId;
    }
}
