/**
 * 服务器基类,定义所有服务器都需要的属性和方法
 * 如果服务器类型未在系统中定义,需要自己设置类型,并重写getServerName等相关方法
 */
package com.kasumiSeq.core;

import com.kasumiSeq.conf.CommConstants;
import com.kasumiSeq.io.packet.ReadPacket;
import com.kasumiSeq.utils.tool.Tools;
import com.kasumiSeq.core.redis.RedisController;
import com.samus.core.transfer.Pipeline;
import io.netty.buffer.ByteBuf;

//mvn idea:idea
public abstract class Server {
    //服务器实例,单例
    private static Server server;
    //服务器id,同类型服务器唯一
    protected int serverId;
    //机器id,全局唯一
    private int machineId;
    protected int tcpPort = 80;
    protected int websocketPort = 90;
    protected boolean isDebug;
    protected boolean useWebsocket = false;
    //topic
    protected String topic = "kasumi";

    protected String allTag = "all";
    protected int serverType = CommConstants.SERVER_TYPE_GAME;
    protected String tag = null;

    protected Pipeline pipeline = null;

    //redis操作实例
    protected RedisController redisController;
    //匹配服模式
    protected int matchPreemptModel = CommConstants.PreemptSingle;
    //单点服模式
    protected int singlePointPreemptModel = CommConstants.PreemptSingle;
    //服务器单例
    public static <S extends Server> void setInstance(S instance){
        server = instance;
    }

    public static <S extends Server> S instance(){
        return (S)server;
    }

    public Server(){

    }


    protected abstract void initPipeline();

    public abstract ReadPacket createPacket(int id, ByteBuf readBuf);

    public int getServerId() {
        return serverId;
    }

    public int getTcpPort() {
        return tcpPort;
    }

    public void setTcpPort(int tcpPort) {
        this.tcpPort = tcpPort;
    }

    public int getMachineId() {
        return machineId;
    }

    public int getWebsocketPort() {
        return websocketPort;
    }

    public void setWebsocketPort(int websocketPort) {
        this.websocketPort = websocketPort;
    }

    public boolean isUseWebsocket() {
        return useWebsocket;
    }

    public void setUseWebsocket(boolean useWebsocket) {
        this.useWebsocket = useWebsocket;
    }

    public void setMachineId(int machineId) {
        this.machineId = machineId;
        BaseIdFactory.setMachineId(machineId);
    }


    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getServerGroupName() {
        return Tools.getServerGroupName(this.serverType);
    }

    public String getTag() {
        if (tag == null) {
            tag = getServerGroupName() + serverId;
        }
        return tag;
    }

    public String getGroupTag(){
        return getServerGroupName();
    }

    /**
     * 全局广播tag
     * @return
     */
    public String getAllTag(){
        return this.allTag;
    }

    public void setAllTag(String tag){
        this.allTag = tag;
    }

    public String getName() {
        return getTag();
    }

    public boolean isDebug() {
        return isDebug;
    }

    public void setDebug(boolean debug) {
        isDebug = debug;
    }

    public int getServerType() {
        return serverType;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }


    public RedisController getRedisController() {
        return redisController;
    }

    public int getMatchPreemptModel() {
        return matchPreemptModel;
    }

    public int getSinglePointPreemptModel() {
        return singlePointPreemptModel;
    }

    public Pipeline pipeline(){
        return this.pipeline;
    }
}
